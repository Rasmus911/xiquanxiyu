import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { dataOf, errorMessage, http } from '../api'
import { assertCurrent, businessGeneration, onBusinessSessionClear } from '../business/state'
import { clearPendingOrderKey } from '../idempotency'
import { reportRange } from '../mobile-management'
import { clampOrderQuantities, switchVisitSelection } from '../order-selection'
import { useConnectivityStore } from './connectivity'
import { useSessionStore } from './session'
import type { MobileBootstrap, MobileCatalogItem, MobileManagementReport, MobileWristband } from '../types'
import type { MobileRefreshDomain } from '../realtime/events'

export const useBusinessStore = defineStore('mobile-business', () => {
  const wristbands = ref<MobileWristband[]>([])
  const catalog = ref<MobileCatalogItem[]>([])
  const report = ref<MobileManagementReport | null>(null)
  const reportDays = ref<1 | 7 | 30>(1)
  const inventory = ref<MobileCatalogItem[]>([])
  const loading = ref(false)
  const sending = ref(false)
  const inventorySaving = ref(false)
  const error = ref('')
  const selectedVisitId = ref('')
  const quantities = ref<Record<string, number>>({})
  let bootstrapOperation = 0; let reportOperation = 0; let inventoryOperation = 0
  let loadingOperation = 0
  const busyOperations = { order: 0, inventory: 0 }
  const businessBusy = computed(() => sending.value ? '正在提交点单' : inventorySaving.value ? '正在提交库存入库' : null)

  function beginBusinessOperation(kind: 'order' | 'inventory') {
    const generation = businessGeneration.capture()
    const owned = ++busyOperations[kind]
    const flag = kind === 'order' ? sending : inventorySaving
    flag.value = true
    return () => {
      if (businessGeneration.isCurrent(generation) && busyOperations[kind] === owned) flag.value = false
    }
  }

  async function refreshBootstrap(silent = false) {
    const generation = businessGeneration.capture()
    const owned = ++bootstrapOperation
    const loadingOwned = ++loadingOperation
    const current = () => businessGeneration.isCurrent(generation) && owned === bootstrapOperation
    if (!silent) loading.value = true
    try {
      const data = dataOf<MobileBootstrap>(await http.get('/mobile/bootstrap'))
      assertCurrent(generation)
      if (!current()) return data
      wristbands.value = data.wristbands
      catalog.value = data.catalog
      quantities.value = clampOrderQuantities(data.catalog, quantities.value)
      useSessionStore().setEmployee(data.employee)
      useConnectivityStore().markSynced()
      if (selectedVisitId.value && !data.wristbands.some((row) => row.visit_id === selectedVisitId.value)) {
        selectedVisitId.value = ''
        quantities.value = {}
        clearPendingOrderKey()
      }
      error.value = ''
      return data
    } catch (cause) {
      if (!current()) throw cause
      useConnectivityStore().apiReachable = false
      error.value = errorMessage(cause)
      throw cause
    } finally { if (businessGeneration.isCurrent(generation) && loadingOwned === loadingOperation) loading.value = false }
  }

  async function loadReport(days: 1 | 7 | 30, silent = false) {
    const generation = businessGeneration.capture()
    const owned = ++reportOperation
    const loadingOwned = ++loadingOperation
    const current = () => businessGeneration.isCurrent(generation) && owned === reportOperation
    if (!silent) loading.value = true
    reportDays.value = days
    try { const data = dataOf<MobileManagementReport>(await http.get('/mobile/management/report', { params: reportRange(days) })); assertCurrent(generation); if (!current()) return; report.value = data; useConnectivityStore().markSynced(); error.value = '' }
    catch (cause) { if (current()) { useConnectivityStore().apiReachable = false; error.value = errorMessage(cause) }; throw cause }
    finally { if (businessGeneration.isCurrent(generation) && loadingOwned === loadingOperation) loading.value = false }
  }

  async function loadInventory(silent = false) {
    const generation = businessGeneration.capture()
    const owned = ++inventoryOperation
    const loadingOwned = ++loadingOperation
    const current = () => businessGeneration.isCurrent(generation) && owned === inventoryOperation
    if (!silent) loading.value = true
    try { const data = dataOf<MobileCatalogItem[]>(await http.get('/mobile/management/inventory')); assertCurrent(generation); if (!current()) return; inventory.value = data; useConnectivityStore().markSynced(); error.value = '' }
    catch (cause) { if (current()) { useConnectivityStore().apiReachable = false; error.value = errorMessage(cause) }; throw cause }
    finally { if (businessGeneration.isCurrent(generation) && loadingOwned === loadingOperation) loading.value = false }
  }

  async function refreshDomains(domains: MobileRefreshDomain[], silent = true) {
    const tasks: Promise<unknown>[] = []
    if (domains.includes('orders')) tasks.push(refreshBootstrap(silent))
    if (domains.includes('reports') && report.value) tasks.push(loadReport(reportDays.value, silent))
    if (domains.includes('inventory') && inventory.value.length) tasks.push(loadInventory(silent))
    await Promise.allSettled(tasks)
  }

  function selectVisit(visitId: string) {
    const next = switchVisitSelection(selectedVisitId.value, visitId, quantities.value)
    selectedVisitId.value = next.visitId
    quantities.value = next.quantities
    if (next.changed) clearPendingOrderKey()
  }

  function reset() {
    busyOperations.order++; busyOperations.inventory++
    wristbands.value = []; catalog.value = []; report.value = null; inventory.value = []
    selectedVisitId.value = ''; quantities.value = {}; error.value = ''
    loading.value = false; sending.value = false; inventorySaving.value = false
  }
  onBusinessSessionClear(reset)

  return { beginBusinessOperation, businessBusy, catalog, error, inventory, inventorySaving, loading, loadInventory, loadReport, quantities, refreshBootstrap, refreshDomains, report, reportDays, reset, selectVisit, selectedVisitId, sending, wristbands }
})
