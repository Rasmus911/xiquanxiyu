<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { dataOf, errorMessage, http } from '../api'
import MobileState from '../components/common/MobileState.vue'
import MobileTopbar from '../components/navigation/MobileTopbar.vue'
import CatalogTabs from '../components/orders/CatalogTabs.vue'
import MobileCatalogPicker from '../components/orders/MobileCatalogPicker.vue'
import OrderSummaryBar from '../components/orders/OrderSummaryBar.vue'
import { clearPendingOrderKey, pendingOrderKey } from '../idempotency'
import { changeProductQuantity, selectionTotals, selectedOrderRows, toggleServiceQuantity } from '../order-selection'
import { useBusinessStore } from '../stores/business'
import { useConnectivityStore } from '../stores/connectivity'
import type { MobileCatalogItem } from '../types'
import { ref } from 'vue'
const route=useRoute();const router=useRouter();const business=useBusinessStore();const connectivity=useConnectivityStore();const kind=ref<'service'|'product'>('service');const message=ref('');const now=ref(Date.now());let timer=0
const visitId=computed(()=>String(route.params.visitId));const band=computed(()=>business.wristbands.find(row=>row.visit_id===visitId.value));const rows=computed(()=>selectedOrderRows(business.catalog,business.quantities));const totals=computed(()=>selectionTotals(rows.value));const kinds=computed(()=>totals.value.kinds);const units=computed(()=>totals.value.units);const amount=computed(()=>totals.value.amount);const elapsed=computed(()=>{if(!band.value)return'';const seconds=Math.max(0,Math.floor((now.value-new Date(band.value.opened_at).getTime())/1000));return`${String(Math.floor(seconds/3600)).padStart(2,'0')}:${String(Math.floor(seconds%3600/60)).padStart(2,'0')}`})
function select(item:MobileCatalogItem){if(item.kind==='service')business.quantities=toggleServiceQuantity(business.quantities,item.id);else business.quantities=changeProductQuantity(business.quantities,item,1)}function change(item:MobileCatalogItem,delta:number){business.quantities=changeProductQuantity(business.quantities,item,delta)}
async function submit(){
  if (!rows.value.length || !connectivity.canWrite || business.sending) return
  const isCurrent = guardBusinessOperation('submit')
  if (!isCurrent()) return
  const releaseBusy = business.beginBusinessOperation('order')
  message.value = ''
  try {
    if (!connectivity.lastSyncAt || Date.now() - connectivity.lastSyncAt > 30000) {
      await business.refreshBootstrap(true); if (!isCurrent()) return
      if (!business.wristbands.some(row => row.visit_id === visitId.value)) {
        message.value = '该手牌已结账或停用'
        await router.replace('/orders'); return
      }
    }
    const items = rows.value.map(row => ({ catalog_item_id: row.id, quantity: row.quantity }))
    const key = pendingOrderKey(visitId.value, items)
    dataOf(await http.post(`/mobile/visits/${visitId.value}/items`, { items }, { headers: { 'Idempotency-Key': key } }))
    if (!isCurrent()) return
    clearPendingOrderKey(); business.quantities = {}; message.value = '加单成功'
    await business.refreshBootstrap(true)
  } catch (cause) { if (isCurrent()) message.value = errorMessage(cause) }
  finally { releaseBusy() }
}
onMounted(()=>{business.selectVisit(visitId.value);timer=window.setInterval(()=>now.value=Date.now(),30000)});onBeforeUnmount(()=>window.clearInterval(timer))
</script>
<template><div><MobileTopbar :title="band?`${band.number} 号手牌`:'手牌点单'" :subtitle="band?`${band.bath_area==='male'?'男浴':'女浴'} · ${elapsed} · 当前消费 ¥${band.amount}`:''" back @back="router.replace('/orders')"/><main class="mobile-page order-page"><div v-if="message" class="notice">{{message}}</div><MobileState v-if="!band" kind="empty" title="该手牌已不在使用中" description="可能已经结账，请返回刷新"/><template v-else><CatalogTabs v-model="kind"/><MobileCatalogPicker :items="business.catalog" :quantities="business.quantities" :kind="kind" @select="select" @change="change"/><OrderSummaryBar :kinds="kinds" :units="units" :amount="amount" :sending="business.sending" :disabled="!units||!connectivity.canWrite||business.sending" @submit="submit"/></template></main></div></template>
<style scoped>.order-page{padding-bottom:150px}</style>
