export type MobileRouteName = 'download' | 'login' | 'orders' | 'visit-order' | 'reports' | 'inventory' | 'profile'
export type RouteAccessDecision = 'allow' | 'login' | 'orders' | 'forbidden'

interface AccessSession {
  capabilities?: {
    reports_view?: boolean
    inventory_manage?: boolean
    reports?: boolean
    inventory_add?: boolean
  }
}

export function routeAccess(routeName: MobileRouteName, session: AccessSession | null): RouteAccessDecision {
  if (routeName === 'download') return 'allow'
  if (routeName === 'login') return session ? 'orders' : 'allow'
  if (!session) return 'login'
  if (routeName === 'reports' && !(session.capabilities?.reports_view ?? session.capabilities?.reports)) return 'forbidden'
  if (routeName === 'inventory' && !(session.capabilities?.inventory_manage ?? session.capabilities?.inventory_add)) return 'forbidden'
  return 'allow'
}
