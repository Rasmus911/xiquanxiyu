import { createRouter, createWebHashHistory } from 'vue-router'
import { routeAccess, type MobileRouteName } from './access'
import { useSessionStore } from '../stores/session'
import MobileShell from '../layouts/MobileShell.vue'
import { businessState, canAccess } from '../business/state'
import { reconcileBusinessSession } from '../api'

const router = createRouter({ history: createWebHashHistory(), routes: [
  { path: '/download', name: 'download', component: () => import('../views/DownloadView.vue') },
  { path: '/login', name: 'login', component: () => import('../views/LoginView.vue') },
  { path: '/', component: MobileShell, children: [
    { path: '', redirect: '/orders' },
    { path: 'orders', name: 'orders', component: () => import('../views/OrdersView.vue') },
    { path: 'orders/:visitId', name: 'visit-order', component: () => import('../views/VisitOrderView.vue') },
    { path: 'reports', name: 'reports', component: () => import('../views/ReportsView.vue') },
    { path: 'inventory', name: 'inventory', component: () => import('../views/InventoryView.vue') },
    { path: 'profile', name: 'profile', component: () => import('../views/ProfileView.vue') },
  ] },
  { path: '/:pathMatch(.*)*', redirect: '/orders' },
] })

router.beforeEach(async (to) => {
  const session = useSessionStore()
  if (session.authenticated && !businessState.value && !['login', 'download'].includes(String(to.name))) await reconcileBusinessSession()
  if (session.authenticated && ['reports', 'inventory'].includes(String(to.name)) && !canAccess(to.name === 'reports' ? 'report:read' : 'inventory:read')) return { name: 'orders', query: { notice: '无权访问该功能' } }
  const accessSession = session.authenticated ? { capabilities: session.employee?.capabilities } : null
  const decision = routeAccess(to.name as MobileRouteName, accessSession)
  if (decision === 'login') return { name: 'login' }
  if (decision === 'orders') return { name: 'orders' }
  if (decision === 'forbidden') return { name: 'orders', query: { notice: '无权访问该功能' } }
  return true
})
export default router
