from datetime import datetime, timezone
from decimal import Decimal

from flask import Blueprint, request

from ..access_policy import emit_business_event
from ..audit_service import write_audit
from ..auth_service import current_employee, has_permission, require_permission
from ..extensions import db
from ..idempotency_service import (
    idempotency_lookup,
    idempotency_record_key,
    idempotency_store,
)
from ..models import CatalogItem, InventoryMovement, OrderItem, Visit, Wristband
from ..serializers import order_item_dict, visit_dict
from ..validation import decimal_value
from .errors import ApiError, success

bp = Blueprint("visits", __name__, url_prefix="/visits")


def _quantity(value) -> Decimal:
    return decimal_value(value, "数量", scale=3, positive=True)


def _load_visit(visit_id, lock=False):
    query = Visit.query.filter_by(id=visit_id)
    if lock:
        query = query.with_for_update()
    visit = query.first()
    if not visit:
        raise ApiError("账单不存在", 404, "NOT_FOUND")
    return visit


def _validate_catalog_quantity(catalog, quantity):
    if catalog.kind == "service" and quantity != quantity.to_integral_value():
        raise ApiError("服务数量必须为整数")


def _create_order_item(visit, catalog, quantity, employee, service_employee_id=None):
    total = decimal_value((Decimal(catalog.price) * quantity).quantize(Decimal("0.01")), "消费金额")
    item = OrderItem(
        visit_id=visit.id,
        catalog_item_id=catalog.id,
        kind=catalog.kind,
        name_snapshot=catalog.name,
        unit_price=catalog.price,
        quantity=quantity,
        total_amount=total,
        service_employee_id=service_employee_id or None,
        created_by_id=employee.id,
    )
    db.session.add(item)
    db.session.flush()
    if catalog.kind == "product" and catalog.stock_tracked:
        catalog.stock_quantity = Decimal(catalog.stock_quantity) - quantity
        catalog.version += 1
        db.session.add(
            InventoryMovement(
                catalog_item_id=catalog.id,
                movement_type="sale",
                quantity=-quantity,
                balance_after=catalog.stock_quantity,
                reference_type="order_item",
                reference_id=item.id,
                operator_id=employee.id,
                note=f"手牌消费：{catalog.name}",
            )
        )
    write_audit(
        "visit.item_add",
        "order_item",
        item.id,
        {"visit_id": visit.id, "item": order_item_dict(item)},
    )
    return item


@bp.get("/<visit_id>")
@require_permission("visit:read")
def get_visit(visit_id):
    visit = _load_visit(visit_id)
    linked_visits = [visit]
    if visit.party_id and visit.status in {"open", "settling"}:
        linked_visits = (
            Visit.query.filter(
                Visit.party_id == visit.party_id,
                Visit.status.in_(["open", "settling"]),
            )
            .order_by(Visit.opened_at)
            .all()
        )
    linked_payloads = []
    linked_total = Decimal("0.00")
    current_payload = None
    for linked_visit in linked_visits:
        wristband = db.session.get(Wristband, linked_visit.wristband_id)
        items = OrderItem.query.filter_by(visit_id=linked_visit.id).order_by(OrderItem.created_at).all()
        payload = visit_dict(linked_visit, wristband, items)
        linked_payloads.append(payload)
        linked_total += Decimal(payload["total_amount"])
        if linked_visit.id == visit.id:
            current_payload = dict(payload)
    current_payload = current_payload or dict(linked_payloads[0])
    current_payload["linked_visits"] = linked_payloads
    current_payload["linked_total_amount"] = str(linked_total.quantize(Decimal("0.01")))
    return success(current_payload)


@bp.post("/<visit_id>/items")
@require_permission("visit:write")
def add_item(visit_id):
    employee = current_employee()
    body = request.get_json(silent=True) or {}
    visit = _load_visit(visit_id, lock=True)
    if visit.status != "open":
        raise ApiError("当前账单不能加项", 409, "VISIT_NOT_OPEN")
    catalog = CatalogItem.query.with_for_update().filter_by(id=body.get("catalog_item_id"), is_active=True).first()
    if not catalog or catalog.kind not in {"service", "product"}:
        raise ApiError("消费项目不存在或已停用", 404, "ITEM_NOT_AVAILABLE")
    quantity = _quantity(body.get("quantity", 1))
    _validate_catalog_quantity(catalog, quantity)
    if catalog.kind == "product" and catalog.stock_tracked:
        if Decimal(catalog.stock_quantity) < quantity:
            raise ApiError("商品库存不足", 409, "INSUFFICIENT_STOCK")
    item = _create_order_item(
        visit,
        catalog,
        quantity,
        employee,
        body.get("service_employee_id"),
    )
    visit.version += 1
    db.session.commit()
    emit_business_event("visit.changed", {"visit_id": visit.id})
    emit_business_event("inventory.changed", {"catalog_item_id": catalog.id})
    return success(order_item_dict(item), "加单成功", 201)


@bp.post("/<visit_id>/items/batch")
@require_permission("visit:write")
def add_items_batch(visit_id):
    employee = current_employee()
    body = request.get_json(silent=True) or {}
    raw_key = str(request.headers.get("Idempotency-Key") or body.get("idempotency_key") or "").strip()
    if not raw_key:
        raise ApiError("缺少幂等请求编号", 400, "IDEMPOTENCY_REQUIRED")
    endpoint = f"visits:{visit_id}:items:batch"
    existing = idempotency_lookup(endpoint, employee.id, raw_key)
    if existing:
        return success(
            existing.response_body["data"],
            "已返回原加单结果",
            existing.response_status,
        )
    requested_items = body.get("items")
    if not isinstance(requested_items, list) or not requested_items:
        raise ApiError("请选择至少一个项目")
    if len(requested_items) > 50:
        raise ApiError("一次最多可添加 50 个项目")

    normalized = []
    for row in requested_items:
        if not isinstance(row, dict) or not row.get("catalog_item_id"):
            raise ApiError("加单项目格式错误")
        normalized.append(
            {
                "catalog_item_id": str(row["catalog_item_id"]),
                "quantity": _quantity(row.get("quantity", 1)),
                "service_employee_id": row.get("service_employee_id") or None,
            }
        )

    visit = _load_visit(visit_id, lock=True)
    if visit.status != "open":
        raise ApiError("当前账单不能加项", 409, "VISIT_NOT_OPEN")

    catalog_ids = sorted({row["catalog_item_id"] for row in normalized})
    catalogs = (
        CatalogItem.query.with_for_update()
        .filter(CatalogItem.id.in_(catalog_ids), CatalogItem.is_active.is_(True))
        .all()
    )
    catalog_by_id = {row.id: row for row in catalogs}
    if len(catalog_by_id) != len(catalog_ids):
        raise ApiError("部分消费项目不存在或已停用", 404, "ITEM_NOT_AVAILABLE")

    required_stock = {}
    for row in normalized:
        catalog = catalog_by_id[row["catalog_item_id"]]
        if catalog.kind not in {"service", "product"}:
            raise ApiError("消费项目不存在或已停用", 404, "ITEM_NOT_AVAILABLE")
        _validate_catalog_quantity(catalog, row["quantity"])
        if catalog.kind == "product" and catalog.stock_tracked:
            required_stock[catalog.id] = required_stock.get(catalog.id, Decimal("0")) + row["quantity"]
    for catalog_id, quantity in required_stock.items():
        if Decimal(catalog_by_id[catalog_id].stock_quantity) < quantity:
            raise ApiError(
                f"商品库存不足：{catalog_by_id[catalog_id].name}",
                409,
                "INSUFFICIENT_STOCK",
            )

    items = [
        _create_order_item(
            visit,
            catalog_by_id[row["catalog_item_id"]],
            row["quantity"],
            employee,
            row["service_employee_id"],
        )
        for row in normalized
    ]
    visit.version += 1
    payload = [order_item_dict(item) for item in items]
    idempotency_store(
        idempotency_record_key(endpoint, employee.id, raw_key),
        endpoint,
        201,
        {"data": payload},
    )
    db.session.commit()
    emit_business_event("visit.changed", {"visit_id": visit.id})
    if required_stock:
        emit_business_event("inventory.changed", {"reason": "batch_sale"})
    return success(payload, f"成功添加 {len(items)} 个项目", 201)


@bp.post("/<visit_id>/items/<item_id>/void")
@require_permission("visit:write")
def void_item(visit_id, item_id):
    employee = current_employee()
    body = request.get_json(silent=True) or {}
    raw_key = str(request.headers.get("Idempotency-Key") or body.get("idempotency_key") or "").strip()
    if not raw_key:
        raise ApiError("缺少幂等请求编号", 400, "IDEMPOTENCY_REQUIRED")
    endpoint = f"visits:{visit_id}:items:{item_id}:void"
    existing = idempotency_lookup(endpoint, employee.id, raw_key)
    if existing:
        return success(
            existing.response_body["data"],
            "已返回原撤销结果",
            existing.response_status,
        )
    reason = str(body.get("reason", "")).strip() or "前台直接撤销"
    visit = _load_visit(visit_id, lock=True)
    if visit.status != "open":
        raise ApiError("当前账单不能撤销项目", 409, "VISIT_NOT_OPEN")
    item = OrderItem.query.with_for_update().filter_by(id=item_id, visit_id=visit.id).first()
    if not item or item.status != "active":
        raise ApiError("项目不存在或已撤销", 409, "ITEM_NOT_ACTIVE")
    if item.kind in {"ticket", "compensation"} and not has_permission(employee, "checkout:refund"):
        raise ApiError("撤销门票或赔偿需要经理权限", 403, "FORBIDDEN")
    before = order_item_dict(item)
    item.status = "voided"
    item.void_reason = reason
    item.voided_by_id = employee.id
    item.voided_at = datetime.now(timezone.utc)
    item.version += 1
    if item.kind == "product" and item.catalog_item_id:
        catalog = CatalogItem.query.with_for_update().filter_by(id=item.catalog_item_id).first()
        if catalog and catalog.stock_tracked:
            catalog.stock_quantity = Decimal(catalog.stock_quantity) + Decimal(item.quantity)
            catalog.version += 1
            db.session.add(
                InventoryMovement(
                    catalog_item_id=catalog.id,
                    movement_type="void_return",
                    quantity=item.quantity,
                    balance_after=catalog.stock_quantity,
                    reference_type="order_item",
                    reference_id=item.id,
                    operator_id=employee.id,
                    note=reason,
                )
            )
    visit.version += 1
    write_audit(
        "visit.item_void",
        "order_item",
        item.id,
        {"visit_id": visit.id, "reason": reason, "before": before, "after": order_item_dict(item)},
    )
    payload = order_item_dict(item)
    idempotency_store(
        idempotency_record_key(endpoint, employee.id, raw_key),
        endpoint,
        200,
        {"data": payload},
    )
    db.session.commit()
    emit_business_event("visit.changed", {"visit_id": visit.id})
    emit_business_event("inventory.changed", {"reason": "void"})
    return success(payload, "项目已撤销")
