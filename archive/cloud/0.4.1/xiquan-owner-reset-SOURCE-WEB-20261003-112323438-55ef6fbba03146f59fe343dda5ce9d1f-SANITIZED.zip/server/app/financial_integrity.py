from decimal import Decimal

from .extensions import db
from .models import Member, MemberPass, OrderItem, PassLedger, Payment, Settlement, SettlementVisit, StoredValueLedger


def check_financial_integrity(period_id=None):
    """Reconcile one period. The caller must authorize any explicit archive scope."""
    if period_id is not None:
        from .business_period import archive_read

        with archive_read(period_id):
            return _check_financial_integrity()
    return _check_financial_integrity()


def _check_financial_integrity():
    """Reconcile mutable balances and settlement totals against append-only records."""
    issues = []
    issue_count = 0
    checked = 0

    def compare(kind, entity_id, actual, expected):
        nonlocal issue_count, checked
        checked += 1
        if Decimal(actual) != Decimal(expected):
            issue_count += 1
            if len(issues) < 100:
                issues.append({"kind": kind, "entity_id": entity_id, "actual": str(actual), "expected": str(expected)})

    for member, ledger_total in (
        db.session.query(Member, db.func.coalesce(db.func.sum(StoredValueLedger.amount), 0))
        .outerjoin(StoredValueLedger, StoredValueLedger.member_id == Member.id)
        .group_by(Member.id)
        .yield_per(500)
    ):
        compare("member_balance", member.id, member.balance, ledger_total)
    for member_pass, delta in (
        db.session.query(MemberPass, db.func.coalesce(db.func.sum(PassLedger.delta), 0))
        .outerjoin(PassLedger, PassLedger.member_pass_id == MemberPass.id)
        .group_by(MemberPass.id)
        .yield_per(500)
    ):
        compare("pass_balance", member_pass.id, member_pass.remaining_count, delta)
    payments = dict(
        db.session.query(Payment.settlement_id, db.func.sum(Payment.amount))
        .filter(Payment.kind == "payment")
        .group_by(Payment.settlement_id)
        .all()
    )
    refunds = dict(
        db.session.query(Payment.settlement_id, db.func.sum(Payment.amount))
        .filter(Payment.kind == "refund")
        .group_by(Payment.settlement_id)
        .all()
    )
    links = dict(
        db.session.query(SettlementVisit.settlement_id, db.func.sum(SettlementVisit.amount))
        .group_by(SettlementVisit.settlement_id)
        .all()
    )
    for settlement in Settlement.query.yield_per(500):
        compare("settlement_payment", settlement.id, settlement.paid_amount, payments.get(settlement.id, 0))
        compare("settlement_total", settlement.id, settlement.total_amount, links.get(settlement.id, 0))
        expected_refund = -Decimal(settlement.paid_amount) if settlement.status == "refunded" else Decimal(0)
        compare("settlement_refund", settlement.id, refunds.get(settlement.id, 0), expected_refund)
    for link, item_total in (
        db.session.query(SettlementVisit, db.func.coalesce(db.func.sum(OrderItem.total_amount), 0))
        .outerjoin(OrderItem, db.and_(OrderItem.visit_id == SettlementVisit.visit_id, OrderItem.status == "active"))
        .group_by(SettlementVisit.settlement_id, SettlementVisit.visit_id)
        .yield_per(500)
    ):
        compare("settled_order", link.visit_id, link.amount, item_total)
    return {"valid": issue_count == 0, "checked": checked, "issue_count": issue_count, "issues": issues}
