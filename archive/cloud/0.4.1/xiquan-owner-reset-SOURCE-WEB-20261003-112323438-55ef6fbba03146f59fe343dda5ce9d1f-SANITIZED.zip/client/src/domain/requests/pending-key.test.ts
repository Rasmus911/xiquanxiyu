import { beforeEach, describe, expect, it } from 'vitest'
import { clearPendingRequestKey, pendingRequestKey } from './pending-key'

describe('pending request key', () => {
  beforeEach(() => sessionStorage.clear())

  it('reuses the same key for an unchanged request until success', () => {
    const first = pendingRequestKey('visit:v1:add', 'v1|p1:2')
    expect(pendingRequestKey('visit:v1:add', 'v1|p1:2')).toBe(first)
    clearPendingRequestKey('visit:v1:add')
    expect(pendingRequestKey('visit:v1:add', 'v1|p1:2')).not.toBe(first)
  })

  it('rotates the key when the visit or quantities change', () => {
    const first = pendingRequestKey('visit:v1:add', 'v1|p1:1')
    expect(pendingRequestKey('visit:v1:add', 'v1|p1:2')).not.toBe(first)
  })
})
