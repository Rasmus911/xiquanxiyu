<script setup lang="ts">
import { computed, ref } from 'vue'
import type { CatalogItem } from '../../types'

const props = defineProps<{ items: CatalogItem[]; quantities: Record<string, number> }>()
const emit = defineEmits<{ select: [item: CatalogItem]; quantity: [item: CatalogItem, value: number] }>()
const activeKind = ref<'service' | 'product'>('service')
const keyword = ref('')
const categories = computed(() => [...new Set(props.items.filter((row) => row.kind === activeKind.value).map((row) => row.category))])
const category = ref('')
const visible = computed(() => props.items.filter((row) => {
  if (!row.is_active || row.kind !== activeKind.value) return false
  if (category.value && row.category !== category.value) return false
  return !keyword.value.trim() || row.name.includes(keyword.value.trim())
}))
function selected(itemId: string) { return props.quantities[itemId] || 0 }
</script>

<template>
  <div class="picker-toolbar">
    <el-radio-group v-model="activeKind" @change="category = ''"><el-radio-button value="service">服务</el-radio-button><el-radio-button value="product">商品</el-radio-button></el-radio-group>
    <el-input v-model="keyword" clearable placeholder="搜索项目" prefix-icon="Search" />
  </div>
  <div v-if="categories.length > 1" class="category-row"><button :class="{ active: !category }" @click="category = ''">全部</button><button v-for="name in categories" :key="name" :class="{ active: category === name }" @click="category = name">{{ name }}</button></div>
  <el-empty v-if="!visible.length" description="没有符合条件的可售项目" />
  <div class="catalog-grid">
    <article v-for="item in visible" :key="item.id" :class="{ selected: selected(item.id), disabled: item.stock_tracked && Number(item.stock_quantity) <= 0 }" @click="emit('select', item)">
      <span v-if="selected(item.id)" class="selection-mark"><el-icon><Check /></el-icon>{{ item.kind === 'product' ? `${selected(item.id)} 件` : '已选' }}</span>
      <strong>{{ item.name }}</strong><span>{{ item.category }}</span><b>¥{{ item.price }}</b><small v-if="item.stock_tracked">库存 {{ item.stock_quantity }}</small>
      <el-input-number v-if="item.kind === 'product'" :model-value="selected(item.id)" :min="0" :max="item.stock_tracked ? Math.max(0, Math.floor(Number(item.stock_quantity))) : 99" :precision="0" size="small" @click.stop @update:model-value="emit('quantity', item, Number($event || 0))" />
    </article>
  </div>
</template>

<style scoped>
.picker-toolbar { display: grid; grid-template-columns: auto minmax(150px, 230px); justify-content: space-between; gap: 10px; }
.category-row { display: flex; gap: 7px; margin: 12px 0; overflow-x: auto; }
.category-row button { padding: 6px 10px; color: var(--xq-text-2); cursor: pointer; border: 1px solid var(--xq-border); border-radius: 99px; background: white; white-space: nowrap; }
.category-row button.active { color: var(--xq-primary); border-color: var(--xq-primary); background: var(--xq-primary-soft); }
.catalog-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 11px; margin-top: 12px; }
article { position: relative; display: flex; flex-direction: column; gap: 5px; min-height: 112px; padding: 12px; cursor: pointer; border: 1px solid var(--xq-border); border-radius: var(--xq-radius-md); background: white; transition: .16s; }
article:hover { border-color: var(--xq-accent); background: #f3fcfa; }
article.selected { border: 2px solid var(--xq-accent); background: var(--xq-accent-soft); box-shadow: 0 0 0 3px rgba(15,159,143,.11); }
article.disabled { pointer-events: none; opacity: .46; }
article strong { color: var(--xq-text-1); font-size: 16px; } article span, article small { color: var(--xq-text-3); } article b { color: var(--xq-danger); font-size: 17px; }
.selection-mark { position: absolute; top: 7px; right: 7px; display: inline-flex; align-items: center; gap: 2px; padding: 2px 6px; color: white !important; border-radius: 99px; background: var(--xq-accent); font-size: 10px; }
.el-input-number { width: 100%; margin-top: auto; }
@media (max-width: 1100px) { .catalog-grid { grid-template-columns: repeat(2, 1fr); } }
</style>
