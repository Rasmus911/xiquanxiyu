const { app, Notification } = require('electron')
const { autoUpdater } = require('electron-updater')
const { decideDesktopUpdate, normalizeDesktopPolicy } = require('./update-policy.cjs')
const { derivePolicyUrl, deriveUpdateUrl } = require('./update-url.cjs')
const { installationDecision, normalizeBusyReason } = require('./updater-guard.cjs')

const CHECK_INTERVAL_MS = 6 * 60 * 60 * 1000
const INITIAL_CHECK_DELAY_MS = 15 * 1000

let windowProvider = () => null
let configuredUrl = ''
let configuredPolicyUrl = ''
let checking = false
let scheduled = false
let lastValidPolicy = null

let state = {
  status: app.isPackaged ? 'unconfigured' : 'disabled',
  decision: 'none',
  required: false,
  currentVersion: app.getVersion(),
  availableVersion: null,
  percent: 0,
  message: app.isPackaged ? '等待云端更新地址' : '开发模式不检查更新',
  releaseNotes: [],
  downloadUrl: '',
  businessBusyReason: null,
}

autoUpdater.autoDownload = true
autoUpdater.autoInstallOnAppQuit = true
autoUpdater.allowDowngrade = false
autoUpdater.allowPrerelease = false
autoUpdater.disableWebInstaller = true

function publicState() {
  return { ...state }
}

function broadcast(patch) {
  state = { ...state, ...patch }
  const win = windowProvider()
  if (win && !win.isDestroyed()) {
    win.webContents.send('updater:state', publicState())
  }
}

function configure(serverUrl) {
  if (!app.isPackaged) return false
  const nextUrl = deriveUpdateUrl(serverUrl)
  const nextPolicyUrl = derivePolicyUrl(serverUrl)
  if (!nextUrl || !nextPolicyUrl) {
    configuredUrl = ''
    configuredPolicyUrl = ''
    lastValidPolicy = null
    broadcast({
      status: 'unconfigured',
      message: '自动更新需要 HTTPS 云端地址',
      decision: 'none',
      required: false,
      availableVersion: null,
      percent: 0,
      releaseNotes: [],
      downloadUrl: '',
    })
    return false
  }
  if (configuredUrl !== nextUrl || configuredPolicyUrl !== nextPolicyUrl) {
    configuredUrl = nextUrl
    configuredPolicyUrl = nextPolicyUrl
    lastValidPolicy = null
    autoUpdater.setFeedURL({ provider: 'generic', url: nextUrl })
    broadcast({
      status: 'idle',
      message: '可以检查更新',
      decision: 'none',
      required: false,
      availableVersion: null,
      percent: 0,
      releaseNotes: [],
      downloadUrl: '',
    })
  }
  return true
}

function applyPolicy(policy) {
  const baseDecision = decideDesktopUpdate(state.currentVersion, policy)
  const decision = policy.required && baseDecision === 'optional' ? 'required' : baseDecision
  broadcast({
    decision,
    required: decision === 'required',
    availableVersion: decision === 'none' ? null : policy.latestVersion,
    releaseNotes: policy.releaseNotes,
    downloadUrl: policy.downloadUrl,
  })
  return decision
}

async function fetchDesktopPolicy() {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 10_000)
  timeout.unref?.()
  try {
    const response = await fetch(configuredPolicyUrl, {
      cache: 'no-store',
      headers: { Accept: 'application/json' },
      signal: controller.signal,
    })
    if (!response.ok) throw new Error(`版本策略请求失败（HTTP ${response.status}）`)
    const payload = await response.json()
    if (Number(payload?.schemaVersion) !== 1) throw new Error('版本策略格式不受支持')
    const policy = normalizeDesktopPolicy(payload?.desktop)
    if (!policy) throw new Error('桌面端版本策略无效')
    lastValidPolicy = policy
    return { policy, error: null }
  } catch (error) {
    return {
      policy: lastValidPolicy,
      error: error instanceof Error ? error.message : String(error),
    }
  } finally {
    clearTimeout(timeout)
  }
}

async function checkForUpdates() {
  if (!app.isPackaged) {
    broadcast({ status: 'disabled', message: '开发模式不检查更新' })
    return publicState()
  }
  if (!configuredUrl) {
    broadcast({ status: 'unconfigured', message: '请先配置 HTTPS 云端服务器地址' })
    return publicState()
  }
  if (checking || ['downloading', 'downloaded'].includes(state.status)) return publicState()

  checking = true
  broadcast({ status: 'checking', message: '正在检查更新', percent: 0 })
  try {
    const policyResult = await fetchDesktopPolicy()
    if (!policyResult.policy) {
      broadcast({
        status: 'error',
        message: policyResult.error || '暂时无法读取版本策略',
        decision: 'none',
        required: false,
      })
      return publicState()
    }

    const decision = applyPolicy(policyResult.policy)
    if (decision === 'none') {
      broadcast({
        status: 'not-available',
        message: policyResult.error ? `当前版本可继续使用；${policyResult.error}` : '当前已是最新版',
        percent: 0,
      })
      return publicState()
    }
    if (policyResult.error) {
      broadcast({ message: `使用上次有效版本策略；${policyResult.error}` })
    }
    await autoUpdater.checkForUpdates()
  } catch (error) {
    broadcast({
      status: 'error',
      message: error instanceof Error ? error.message : String(error),
    })
  } finally {
    checking = false
  }
  return publicState()
}

function installUpdate() {
  const result = installationDecision(state.status, state.businessBusyReason)
  if (!result.ok) return result
  setImmediate(() => autoUpdater.quitAndInstall(false, true))
  return { ok: true }
}

function setBusinessBusy(reason) {
  const businessBusyReason = normalizeBusyReason(reason)
  broadcast({ businessBusyReason })
  return publicState()
}

function start(serverUrl, provider) {
  windowProvider = provider || windowProvider
  configure(serverUrl)
  if (!app.isPackaged || scheduled) return
  scheduled = true

  const initialTimer = setTimeout(() => { void checkForUpdates() }, INITIAL_CHECK_DELAY_MS)
  initialTimer.unref?.()
  const interval = setInterval(() => { void checkForUpdates() }, CHECK_INTERVAL_MS)
  interval.unref?.()
}

function updateServerUrl(serverUrl) {
  const changed = configure(serverUrl)
  if (changed && !checking && state.status === 'idle') {
    const timer = setTimeout(() => { void checkForUpdates() }, 1500)
    timer.unref?.()
  }
  return publicState()
}

autoUpdater.on('checking-for-update', () => {
  broadcast({ status: 'checking', message: '正在检查更新', percent: 0 })
})

autoUpdater.on('update-available', (info) => {
  const decision = state.decision === 'none' ? 'optional' : state.decision
  broadcast({
    status: 'downloading',
    decision,
    required: decision === 'required',
    availableVersion: info.version,
    message: `发现 ${info.version}，正在后台下载`,
    percent: 0,
  })
})

autoUpdater.on('download-progress', (progress) => {
  const percent = Math.max(0, Math.min(100, Math.round(Number(progress.percent) || 0)))
  broadcast({ status: 'downloading', message: `新版下载中 ${percent}%`, percent })
})

autoUpdater.on('update-not-available', (info) => {
  broadcast({
    status: 'not-available',
    decision: 'none',
    required: false,
    availableVersion: info?.version || null,
    message: '当前已是最新版',
    percent: 0,
  })
})

autoUpdater.on('update-downloaded', (info) => {
  broadcast({
    status: 'downloaded',
    availableVersion: info.version,
    message: `新版 ${info.version} 已下载，点击重启安装`,
    percent: 100,
  })
  if (Notification.isSupported()) {
    new Notification({
      title: '溪泉洗浴管理系统有新版本',
      body: `版本 ${info.version} 已下载，退出软件时会自动安装。`,
    }).show()
  }
})

autoUpdater.on('error', (error) => {
  checking = false
  broadcast({
    status: 'error',
    message: error instanceof Error ? error.message : String(error),
  })
})

module.exports = {
  checkForUpdates,
  getState: publicState,
  installUpdate,
  setBusinessBusy,
  start,
  updateServerUrl,
}

