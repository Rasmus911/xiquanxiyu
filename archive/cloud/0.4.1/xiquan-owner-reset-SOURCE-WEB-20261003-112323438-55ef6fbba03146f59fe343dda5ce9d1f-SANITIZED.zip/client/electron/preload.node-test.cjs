const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const test = require('node:test')

test('sandboxed preload does not require local modules', () => {
  const source = fs.readFileSync(path.join(__dirname, 'preload.cjs'), 'utf8')

  assert.doesNotMatch(source, /require\s*\(\s*['"]\./)
  assert.match(source, /contextBridge\.exposeInMainWorld\(['"]xiquan['"]/)
  assert.match(source, /setBusinessBusy/)
})
