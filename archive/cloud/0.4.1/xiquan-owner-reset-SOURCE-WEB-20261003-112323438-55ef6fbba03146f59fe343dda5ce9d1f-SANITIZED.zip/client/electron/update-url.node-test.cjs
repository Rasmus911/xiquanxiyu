const test = require('node:test')
const assert = require('node:assert/strict')

const { derivePolicyUrl, deriveUpdateUrl } = require('./update-url.cjs')

test('derives updater feed and release policy from the HTTPS API URL', () => {
  const serverUrl = 'https://api.pqxqxy.xyz/api'
  assert.equal(deriveUpdateUrl(serverUrl), 'https://api.pqxqxy.xyz/updates/')
  assert.equal(derivePolicyUrl(serverUrl), 'https://api.pqxqxy.xyz/releases/client-policy.json')
})

test('rejects non-HTTPS, credentialed and non-api server URLs', () => {
  assert.equal(deriveUpdateUrl('http://api.pqxqxy.xyz/api'), null)
  assert.equal(derivePolicyUrl('https://user:pass@api.pqxqxy.xyz/api'), null)
  assert.equal(derivePolicyUrl('https://api.pqxqxy.xyz/v1'), null)
})
