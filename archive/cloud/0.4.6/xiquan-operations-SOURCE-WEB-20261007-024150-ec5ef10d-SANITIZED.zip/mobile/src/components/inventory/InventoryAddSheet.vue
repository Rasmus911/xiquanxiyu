<script setup lang="ts">
import { computed, reactive, watch } from 'vue'
import type { StockItem } from '../../types'
import { previewStockQuantity, stockConversionError } from '../../domain/inventory/quantity'
const props=defineProps<{item:StockItem|null;saving:boolean}>()
const emit=defineEmits<{close:[];save:[value:{quantity:string;input_unit:string;reason:string}]}>()
const form=reactive({quantity:'1',input_unit:'base',reason:''})
watch(()=>props.item,()=>{form.quantity='1';form.input_unit='base';form.reason=''})
const preview=computed(()=>previewStockQuantity(form.quantity,form.input_unit,props.item?.units_per_package || '1'))
const conversionError=computed(()=>stockConversionError(form.quantity,form.input_unit,props.item?.units_per_package || '1'))
function save(){if(!props.saving&&props.item&&!conversionError.value)emit('save',{...form})}
</script>
<template>
  <div v-if="item" class="sheet-mask" @click.self="!saving && $emit('close')"><section class="sheet">
    <h3>{{item.name}} 采购入库</h3><p>当前 {{item.stock_quantity}} {{item.base_unit}} · {{item.package_spec}}</p>
    <label>入库数量<input v-model="form.quantity" inputmode="decimal" :disabled="saving" /></label>
    <label>输入单位<select v-model="form.input_unit" :disabled="saving"><option value="base">{{item.base_unit}}</option><option v-if="item.package_unit" value="package">{{item.package_unit}}</option></select></label>
    <p>折算入库：{{preview}} {{item.base_unit}}</p>
    <p v-if="conversionError" role="alert">{{conversionError}}</p>
    <label>原因 / 单据号（选填）<input v-model="form.reason" :disabled="saving" /></label>
    <button class="primary-button" :disabled="saving||!!conversionError" @click="save">{{saving?'正在提交':'确认入库'}}</button>
    <button :disabled="saving" @click="$emit('close')">取消</button>
  </section></div>
</template>
<style scoped>.sheet-mask{position:fixed;z-index:70;inset:0;display:flex;align-items:end;background:rgba(10,20,35,.46)}.sheet{width:100%;max-height:85vh;overflow:auto;padding:18px;border-radius:24px 24px 0 0;background:white}.sheet label{display:grid;gap:6px;margin:12px 0}.sheet input,.sheet select,.sheet button{min-height:46px;padding:8px 12px;border:1px solid var(--m-border);border-radius:8px}.sheet button{width:100%;margin-top:8px}.primary-button{color:white;background:var(--m-primary)}</style>
