import { afterEach, beforeEach, expect, it, vi } from 'vitest'
import { flushPromises, mount } from '@vue/test-utils'
import { createMemoryHistory, createRouter } from 'vue-router'
import { createPinia } from 'pinia'
import ElementPlus, { ElMessage } from 'element-plus'
import {useRuntimeStore} from '../stores/runtime'
import VisitView from './VisitView.vue'
import { http } from '../api/http'
import { acceptBusinessState, clearBusinessSession } from '../business/state'
import { useConnectivityStore } from '../stores/connectivity'
import type { Visit } from '../types'

const visits = ['a', 'b', 'c'].map((id, index) => ({ id, version: index + 3, wristband_number: String(index + 1).padStart(3, '0'),
  wristband_id: id, status: 'open', opened_at: '2026-10-04T10:00:00Z', total_amount: '15.00', items: [] })) as Visit[]
const product = { id: 'soap', kind: 'product', category: '洗浴', name: '搓泥宝', price: '10.00', is_active: true,
  stock_tracked: true, stock_quantity: '10', sort_order: 10, low_stock_threshold: '1' }
const tickets = ['adult','child'].map((id,index) => ({ id,kind:'ticket',reference_code:`ticket.${id}`,
  name:index ? '儿童门票（一米以下）' : '门票',price:index ? '10.00' : '15.00',is_active:true }))
let finish: Map<string, () => void>
let posts: any[]
beforeEach(() => {
  clearBusinessSession()
  acceptBusinessState({ period_id: 'fixture', policy_version: 1, business_revision: 0, maintenance: false,
    owner_reset_allowed: false, capabilities: { visit_order: true }, ui_pages: ['wristbands'] }, ['visit:order'])
  finish = new Map(); posts = []
  http.defaults.adapter = config => {
    const response = (data: unknown) => ({ config, headers: {}, status: 200, statusText: '', data: { data } })
    if (config.method === 'post') { posts.push({ url: config.url, body: JSON.parse(config.data) }); return Promise.resolve(response([])) }
    if (config.method === 'patch') { posts.push({url:config.url,body:JSON.parse(config.data)}); return Promise.resolve(response(visits[0])) }
    if (config.url === '/catalog') return Promise.resolve(response([product,...tickets]))
    const id = String(config.url).split('/').at(-1)
    return new Promise(resolve => finish.set(id!, () => resolve(response({ ...visits.find(row => row.id === id), linked_visits: visits }))))
  }
})
afterEach(() => { clearBusinessSession(); ElMessage.closeAll(); delete window.xiquan; vi.restoreAllMocks() })
async function render() {
  const router = createRouter({ history: createMemoryHistory(), routes: [{ path: '/visits/:id', component: VisitView }] })
  await router.push('/visits/a'); await router.isReady()
  const pinia = createPinia()
  const wrapper = mount(VisitView, { global: { plugins: [pinia, router, ElementPlus] } })
  useConnectivityStore().setRealtimeStatus('connected')
  await flushPromises()
  return { wrapper, router }
}
it('A → B → C stays on C when responses finish C, B, A', async () => {
  const { wrapper, router } = await render()
  try {
    await router.push('/visits/b'); await flushPromises()
    await router.push('/visits/c'); await flushPromises()
    expect(finish.has('b')).toBe(true)
    finish.get('c')!(); await flushPromises()
    finish.get('b')!(); await flushPromises()
    finish.get('a')!(); await flushPromises()
    expect(wrapper.text()).toContain('003 号手牌')
    expect(wrapper.find('.party-tabs button.active').text()).toContain('003')
  } finally { wrapper.unmount() }
})
it('a delayed desktop busy handshake cannot redirect A submission into B', async () => {
  const { wrapper, router } = await render()
  try {
    finish.get('a')!(); await flushPromises()
    // Default mixed mode; use the picker event to exercise the real selection handlers.
    const picker = wrapper.findComponent({ name: 'CatalogPicker' })
    picker.vm.$emit('select', product); picker.vm.$emit('select', product); await flushPromises()
    let release!: () => void
    window.xiquan = { setBusinessBusy: vi.fn(reason => reason ? new Promise(resolve => { release = () => resolve({ businessBusyReason: reason } as any) }) : Promise.resolve({} as any)) } as any
    await wrapper.findAll('button').find(button => button.text() === '确认加单')!.trigger('click')
    await flushPromises()
    await router.push('/visits/b'); await flushPromises()
    release(); await flushPromises()
    expect(posts[0]).toMatchObject({ url: '/visits/a/items/batch', body: { version: 3, items: [{ catalog_item_id: 'soap', quantity: 2 }] } })
    finish.get('b')!(); await flushPromises()
    picker.vm.$emit('select', product); await flushPromises()
    await router.push('/visits/a'); await flushPromises(); finish.get('a')!(); await flushPromises()
    expect(wrapper.findComponent({ name: 'CatalogPicker' }).props('quantities')).toEqual({})
    await router.push('/visits/b'); await flushPromises(); finish.get('b')!(); await flushPromises()
    expect(wrapper.findComponent({ name: 'CatalogPicker' }).props('quantities')).toEqual({ soap: 1 })
  } finally { wrapper.unmount() }
})

it('quick-order submit is in the header and disabled without selection or connectivity', async () => {
  const { wrapper } = await render()
  try {
    finish.get('a')!(); await flushPromises()
    const button = wrapper.find('[data-testid="quick-order-header"] [data-testid="submit-order"]')
    expect(button.exists()).toBe(true)
    expect(button.attributes('disabled')).toBeDefined()
    wrapper.findComponent({ name: 'CatalogPicker' }).vm.$emit('select', product); await flushPromises()
    expect(button.attributes('disabled')).toBeUndefined()
    useConnectivityStore().setRealtimeStatus('disconnected'); await flushPromises()
    expect(button.attributes('disabled')).toBeDefined()
  } finally { wrapper.unmount() }
})

function enableTicketChange() {
  acceptBusinessState({period_id:'fixture',policy_version:1,business_revision:0,maintenance:false,
    owner_reset_allowed:false,capabilities:{visit_order:true,visit_manage:true},ui_pages:['wristbands']},['visit:order','visit:write'])
}
it('changing ticket submits the current visit version and server ticket ID, never a price', async () => {
  enableTicketChange()
  const {wrapper}=await render()
  try {
    finish.get('a')!(); await flushPromises()
    await wrapper.get('[data-testid="change-ticket"]').trigger('click'); await flushPromises()
    wrapper.findComponent({name:'AdmissionDialog'}).vm.$emit('confirm',{a:'child'})
    await flushPromises()
    expect(posts[0]).toMatchObject({url:'/visits/a/ticket',body:{ticket_catalog_item_id:'child',version:3}})
    expect(posts[0].body).not.toHaveProperty('price')
  } finally {wrapper.unmount()}
})
it('a linked visit switch cancels pending ticket choice instead of altering the next person', async () => {
  enableTicketChange()
  const {wrapper,router}=await render()
  try {
    finish.get('a')!(); await flushPromises()
    await wrapper.get('[data-testid="change-ticket"]').trigger('click'); await flushPromises()
    await router.push('/visits/b'); await flushPromises()
    expect(wrapper.findComponent({name:'AdmissionDialog'}).props('modelValue')).toBe(false)
    expect(posts).toEqual([])
  } finally {wrapper.unmount()}
})

it('an old ticket change cannot clear a newer desktop busy operation',async()=>{
  enableTicketChange()
  const {wrapper}=await render()
  try {
    finish.get('a')!();await flushPromises()
    let resolvePatch!:()=>void
    const previous=http.defaults.adapter as any
    http.defaults.adapter=config=>config.method==='patch'?new Promise(resolve=>{
      resolvePatch=()=>resolve({config,headers:{},status:200,statusText:'',data:{data:visits[0]}})
    }):previous(config)
    await wrapper.get('[data-testid="change-ticket"]').trigger('click')
    wrapper.findComponent({name:'AdmissionDialog'}).vm.$emit('confirm',{a:'child'})
    await flushPromises()
    const runtime=useRuntimeStore()
    await runtime.setBusinessBusy('正在处理另一笔交易')
    resolvePatch();await flushPromises()
    finish.get('a')!();await flushPromises()
    expect(runtime.businessBusyReason).toBe('正在处理另一笔交易')
  } finally {wrapper.unmount()}
})
