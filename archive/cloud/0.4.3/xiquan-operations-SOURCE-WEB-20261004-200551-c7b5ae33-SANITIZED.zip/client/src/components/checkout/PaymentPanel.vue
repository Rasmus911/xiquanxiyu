<script setup lang="ts">
interface PaymentInput { method: string; amount: number; reference: string }
defineProps<{ payments: PaymentInput[]; total: string; paid: string; balanced: boolean; disabled?: boolean }>()
defineEmits<{ add: []; remove: [index: number] }>()
</script>

<template>
  <section class="payment-panel">
    <div class="panel-title"><div><strong>2. 选择支付方式</strong><span>可拆分现金、微信、支付宝或会员储值</span></div><el-button link type="primary" :disabled="disabled" @click="$emit('add')">添加支付方式</el-button></div>
    <div v-for="(payment, index) in payments" :key="index" class="payment-row">
      <el-select v-model="payment.method" :disabled="disabled"><el-option label="现金" value="cash" /><el-option label="微信" value="wechat" /><el-option label="支付宝" value="alipay" /><el-option label="会员储值" value="balance" /></el-select>
      <el-input-number v-model="payment.amount" :min="0" :precision="2" :controls="false" :disabled="disabled" />
      <el-input v-model="payment.reference" placeholder="流水号（选填）" :disabled="disabled" />
      <el-button v-if="payments.length > 1" circle plain type="danger" :disabled="disabled" @click="$emit('remove', index)"><el-icon><Delete /></el-icon></el-button>
    </div>
    <div :class="['payment-summary', { balanced }]">
      <span>应收 <b>¥{{ total }}</b></span><span>已填 <b>¥{{ paid }}</b></span><strong>{{ balanced ? '金额已平' : '支付金额需等于应收' }}</strong>
    </div>
  </section>
</template>

<style scoped>
.payment-panel { display: grid; gap: 12px; }
.panel-title { display: flex; align-items: center; justify-content: space-between; }
.panel-title strong, .panel-title span { display: block; } .panel-title span { margin-top: 3px; color: var(--xq-text-3); font-size: 11px; }
.payment-row { display: grid; grid-template-columns: 120px 130px minmax(120px, 1fr) auto; gap: 8px; }
.payment-summary { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 11px 13px; color: var(--xq-warning); border-radius: 10px; background: #fff7e8; }
.payment-summary.balanced { color: #08796c; background: var(--xq-accent-soft); }
@media (max-width: 1100px) { .payment-row { grid-template-columns: 1fr 1fr; } }
</style>
