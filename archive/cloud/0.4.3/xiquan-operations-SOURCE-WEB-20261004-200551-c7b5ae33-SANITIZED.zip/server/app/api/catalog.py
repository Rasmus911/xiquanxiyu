from flask import Blueprint, request

from ..access_policy import emit_business_event
from ..audit_service import write_audit
from ..auth_service import current_employee, require_any_permission, require_permission
from ..extensions import db
from ..financial_lock import serialized_financial_write
from ..catalog_layout import catalog_layout, save_catalog_layout, touch_catalog_layout
from ..models import CatalogItem
from ..pricing_service import reprice_open_catalog_items
from ..package_service import validate_package_definition
from ..ordering_scope import can_sell_catalog, full_ordering
from ..serializers import catalog_dict
from ..validation import decimal_value
from .errors import ApiError, success

bp = Blueprint("catalog", __name__, url_prefix="/catalog")
VALID_KINDS = {"ticket", "service", "product", "compensation", "package"}
VALID_MOBILE_SCOPES = {"frontdesk", "scrub", "rest", "both"}


def _decimal(value, field):
    return decimal_value(value, field, scale=3 if field == "预警库存" else 2)


def _mobile_scope(value):
    scope = str(value or "frontdesk").strip()
    if scope not in VALID_MOBILE_SCOPES:
        raise ApiError("手机端销售范围无效")
    return scope


@bp.get("")
@require_any_permission('visit:read', 'mobile:order', 'catalog:read')
def list_catalog():
    employee = current_employee()
    query = CatalogItem.query
    if request.args.get("kind"):
        query = query.filter_by(kind=request.args["kind"])
    if request.args.get("active") == "true":
        query = query.filter_by(is_active=True)
    rows = query.order_by(CatalogItem.sort_order, CatalogItem.id).all()
    if employee.role == 'inventory':
        rows = [row for row in rows if row.kind == 'product']
    elif not full_ordering(employee):
        rows = [row for row in rows if can_sell_catalog(employee, row)]
    return success([catalog_dict(row) for row in rows])


@bp.post("")
@require_permission("catalog:write")
@serialized_financial_write
def create_item():
    body = request.get_json(silent=True) or {}
    kind = str(body.get("kind", "")).strip()
    name = str(body.get("name", "")).strip()
    if kind not in VALID_KINDS or not name:
        raise ApiError("项目类型或名称无效")
    if kind=='package': validate_package_definition(db.session,body.get('package_definition'))
    elif 'package_definition' in body: raise ApiError('只有套票可以设置包含定义',400,'INVALID_PACKAGE')
    row = CatalogItem(
        kind=kind,
        category=str(body.get("category", "默认")).strip() or "默认",
        name=name,
        mobile_scope=_mobile_scope(body.get("mobile_scope")),
        price=_decimal(body.get("price", 0), "价格"),
        stock_tracked=bool(body.get("stock_tracked", kind == "product")),
        low_stock_threshold=_decimal(body.get("low_stock_threshold", 0), "预警库存"),
        sort_order=int(body.get("sort_order", 0)),
        package_definition=body.get('package_definition') if kind=='package' else None,
    )
    db.session.add(row)
    db.session.flush()
    touch_catalog_layout(db.session)
    write_audit("catalog.create", "catalog_item", row.id, catalog_dict(row))
    db.session.commit()
    emit_business_event("catalog.changed", {"item_id": row.id})
    return success(catalog_dict(row), "项目创建成功", 201)


@bp.patch("/<item_id>")
@require_permission("catalog:write")
@serialized_financial_write
def update_item(item_id):
    row = CatalogItem.query.filter_by(id=item_id).with_for_update().first()
    if not row:
        raise ApiError("项目不存在", 404, "NOT_FOUND")
    body = request.get_json(silent=True) or {}
    before = catalog_dict(row)
    if 'package_definition' in body:
        if row.kind!='package': raise ApiError('只有套票可以设置包含定义',400,'INVALID_PACKAGE')
        validate_package_definition(db.session,body['package_definition'])
        row.package_definition=body['package_definition']
    if "name" in body:
        row.name = str(body["name"]).strip()
    if "category" in body:
        row.category = str(body["category"]).strip() or "默认"
    if "mobile_scope" in body:
        row.mobile_scope = _mobile_scope(body["mobile_scope"])
    if "price" in body:
        row.price = _decimal(body["price"], "价格")
    if "is_active" in body:
        row.is_active = bool(body["is_active"])
    if "stock_tracked" in body:
        row.stock_tracked = bool(body["stock_tracked"])
    if "low_stock_threshold" in body:
        row.low_stock_threshold = _decimal(body["low_stock_threshold"], "预警库存")
    if "sort_order" in body:
        row.sort_order = int(body["sort_order"])
    row.version += 1
    touch_catalog_layout(db.session)
    repriced = reprice_open_catalog_items(row,definition_changed='package_definition' in body) if {'price','package_definition'} & set(body) else {"item_count": 0, "visit_ids": []}
    write_audit(
        "catalog.update",
        "catalog_item",
        row.id,
        {"before": before, "after": catalog_dict(row), "repriced_open_bills": repriced},
    )
    db.session.commit()
    emit_business_event("catalog.changed", {"item_id": row.id})
    if repriced["visit_ids"]:
        emit_business_event("visit.changed", {"reason": "catalog_price_changed", **repriced})
    return success(catalog_dict(row))


@bp.get('/layout')
@require_permission('catalog:layout')
@serialized_financial_write
def read_layout():
    result = catalog_layout(db.session)
    db.session.commit()
    return success(result)


@bp.put('/layout')
@require_permission('catalog:layout')
@serialized_financial_write
def update_layout():
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict) or set(body) - {'revision', 'ids'}:
        raise ApiError('排列参数无效')
    result = save_catalog_layout(db.session, current_employee(), body.get('revision'), body.get('ids'))
    db.session.commit()
    emit_business_event('catalog.changed', {'reason': 'layout'})
    return success(result, '排列已同步')
