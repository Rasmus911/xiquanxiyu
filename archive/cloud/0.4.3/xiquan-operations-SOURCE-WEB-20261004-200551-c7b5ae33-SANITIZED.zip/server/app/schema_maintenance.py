from sqlalchemy import inspect, text

from .extensions import db


def upgrade_operations_schema(connection):
    """Structure only: no retirement, new catalog, stock adjustment or bill repricing."""
    def add(table, name, declaration):
        if name in {column['name'] for column in inspect(connection).get_columns(table)}:
            return False
        connection.exec_driver_sql(f'ALTER TABLE {table} ADD COLUMN {name} {declaration}')
        return True
    added_area = add('wristbands', 'bath_area', "VARCHAR(20) NOT NULL DEFAULT 'other'")
    add('wristbands', 'is_active', 'BOOLEAN NOT NULL DEFAULT TRUE')
    if added_area:
        # A derived new column must not increment the old business revision.
        suffix = ' ON wristbands' if connection.dialect.name == 'postgresql' else ''
        connection.exec_driver_sql('DROP TRIGGER IF EXISTS revision_wristbands_update' + suffix)
        from .serializers import wristband_area
        for id_, number in connection.execute(text('SELECT id,number FROM wristbands')).all():
            connection.execute(text('UPDATE wristbands SET bath_area=:area WHERE id=:id'),
                {'area': wristband_area(number), 'id': id_})
    add('catalog_items','reference_code','VARCHAR(80)')
    add('catalog_items','package_definition','JSON')
    connection.exec_driver_sql('CREATE UNIQUE INDEX IF NOT EXISTS uq_catalog_reference_code ON catalog_items (reference_code)')
    add('order_items','covered_quantity','NUMERIC(12,3) NOT NULL DEFAULT 0 CHECK (covered_quantity >= 0 AND covered_quantity <= quantity)')
    add('order_items','package_order_item_id','VARCHAR(36) REFERENCES order_items(id)')
    add('order_items','package_snapshot','JSON')
    from .database_guards import install_database_guards, install_period_guards
    from .business_barrier import install_barrier_guards
    install_database_guards(connection)
    install_period_guards(connection)
    install_barrier_guards(connection)


def upgrade_business_period_schema(connection):
    """Add attribution without touching an existing business value or removing evidence guards."""
    from .business_period import INITIAL_PERIOD_ID
    from .database_guards import install_database_guards, install_period_guards
    from .models import (
        AccessPolicyModel,
        BusinessPeriod,
        BusinessStateModel,
        PeriodMixin,
        ResetEventModel,
        ResetTaskModel,
        utcnow,
    )

    # sqlite3's legacy transaction mode otherwise auto-commits DDL statements.
    if connection.dialect.name == 'sqlite' and not connection.connection.driver_connection.in_transaction:
        connection.exec_driver_sql('BEGIN')
    for model in (BusinessPeriod, BusinessStateModel, AccessPolicyModel, ResetTaskModel, ResetEventModel):
        model.__table__.create(connection, checkfirst=True)
    if 'administrator_employee_ids' not in {
            column['name'] for column in inspect(connection).get_columns('access_policies')}:
        connection.exec_driver_sql("ALTER TABLE access_policies ADD COLUMN "
                                   "administrator_employee_ids JSON NOT NULL DEFAULT '[]'")
    if connection.execute(text('SELECT id FROM business_periods WHERE id=:id'),
                          {'id': INITIAL_PERIOD_ID}).first() is None:
        connection.execute(BusinessPeriod.__table__.insert().values(id=INITIAL_PERIOD_ID, created_at=utcnow()))
    models = [mapper.class_ for mapper in db.Model.registry.mappers if issubclass(mapper.class_, PeriodMixin)]
    for model in models:
        name = model.__tablename__
        if 'period_id' not in {column['name'] for column in inspect(connection).get_columns(name)}:
            connection.exec_driver_sql(f"ALTER TABLE {name} ADD COLUMN period_id VARCHAR(36) "
                                       f"NOT NULL DEFAULT '{INITIAL_PERIOD_ID}' REFERENCES business_periods(id)")
        connection.exec_driver_sql(f'CREATE INDEX IF NOT EXISTS ix_{name}_period_id ON {name} (period_id)')
    member_indexes = inspect(connection).get_indexes('members')
    if any(index['name'] == 'ix_members_phone' and index['unique'] for index in member_indexes):
        connection.exec_driver_sql('DROP INDEX ix_members_phone')
        connection.exec_driver_sql('CREATE INDEX ix_members_phone ON members (phone)')
    connection.exec_driver_sql('CREATE UNIQUE INDEX IF NOT EXISTS uq_members_period_phone '
                               'ON members (period_id, phone)')
    indexes = inspect(connection).get_indexes('visits')
    if any(index['name'] == 'uq_visits_active_wristband' and index['column_names'] == ['wristband_id']
           for index in indexes):
        connection.exec_driver_sql('DROP INDEX uq_visits_active_wristband')
    connection.exec_driver_sql('CREATE UNIQUE INDEX IF NOT EXISTS uq_visits_active_wristband '
                               "ON visits (period_id, wristband_id) WHERE status IN ('open', 'settling')")
    if connection.execute(text('SELECT id FROM business_state WHERE id=1')).first() is None:
        connection.execute(BusinessStateModel.__table__.insert().values(id=1, period_id=INITIAL_PERIOD_ID))
    install_database_guards(connection)
    install_period_guards(connection)
    # Portable SQLite upgrades share the same structural maintenance ownership
    # addition as Alembic. This never schedules/replays a reset or touches money.
    if 'maintenance_reset_id' not in {column['name'] for column in inspect(connection).get_columns('business_state')}:
        connection.exec_driver_sql('ALTER TABLE business_state ADD COLUMN maintenance_reset_id VARCHAR(36)')
    from .business_barrier import install_barrier_guards
    install_barrier_guards(connection)


def ensure_runtime_schema():
    """为直接运行 EXE 的现有 SQLite/PostgreSQL 数据库补充兼容字段。"""
    inspector = inspect(db.engine)
    if "visits" not in inspector.get_table_names():
        return
    audit_columns = {column["name"] for column in inspector.get_columns("audit_logs")}
    if "integrity_version" not in audit_columns:
        db.session.execute(text("ALTER TABLE audit_logs ADD COLUMN integrity_version INTEGER NOT NULL DEFAULT 1"))
    if "context" not in audit_columns:
        db.session.execute(text("ALTER TABLE audit_logs ADD COLUMN context JSON NOT NULL DEFAULT '{}'"))
    db.session.commit()
    from .database_guards import install_database_guards

    install_database_guards(db.session.connection())
    db.session.commit()
    columns = {column["name"] for column in inspector.get_columns("visits")}
    if "party_id" not in columns:
        db.session.connection().execute(text("ALTER TABLE visits ADD COLUMN party_id VARCHAR(36)"))
        db.session.commit()
    db.session.connection().execute(text("CREATE INDEX IF NOT EXISTS ix_visits_party_id ON visits (party_id)"))
    db.session.commit()

    inspector = inspect(db.engine)
    if "employees" in inspector.get_table_names():
        employee_columns = {column["name"] for column in inspector.get_columns("employees")}
        if "session_version" not in employee_columns:
            db.session.execute(text("ALTER TABLE employees ADD COLUMN session_version INTEGER NOT NULL DEFAULT 1"))
            db.session.commit()
        if "allowed_channels" not in employee_columns:
            db.session.execute(text("ALTER TABLE employees ADD COLUMN allowed_channels JSON NOT NULL DEFAULT '[]'"))
            db.session.commit()
        if "deleted_at" not in employee_columns:
            timestamp_type = 'TIMESTAMP WITH TIME ZONE' if db.engine.dialect.name == 'postgresql' else 'DATETIME'
            db.session.execute(text(f'ALTER TABLE employees ADD COLUMN deleted_at {timestamp_type}'))
            db.session.commit()
        if "mobile_full_access" not in employee_columns:
            db.session.execute(
                text("ALTER TABLE employees ADD COLUMN mobile_full_access BOOLEAN NOT NULL DEFAULT FALSE")
            )
            db.session.commit()

    inspector = inspect(db.engine)
    if "catalog_items" not in inspector.get_table_names():
        return
    catalog_columns = {column["name"] for column in inspector.get_columns("catalog_items")}
    if "mobile_scope" not in catalog_columns:
        db.session.execute(
            text("ALTER TABLE catalog_items ADD COLUMN mobile_scope VARCHAR(20) NOT NULL DEFAULT 'frontdesk'")
        )
        db.session.execute(
            text(
                "UPDATE catalog_items SET mobile_scope = 'scrub' WHERE category IN ('搓澡助浴', '组合项目', '洗浴用品')"
            )
        )
        db.session.execute(
            text(
                "UPDATE catalog_items SET mobile_scope = 'rest' "
                "WHERE category IN ('理疗按摩', '饮品', '承德特色饮品', '食品')"
            )
        )
        db.session.commit()

    db.session.commit()
    with db.engine.begin() as connection:
        upgrade_business_period_schema(connection)
        upgrade_operations_schema(connection)
    db.session.expire_all()
