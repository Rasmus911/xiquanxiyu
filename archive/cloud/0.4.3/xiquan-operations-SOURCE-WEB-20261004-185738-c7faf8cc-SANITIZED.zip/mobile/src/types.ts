export type MobileRole = 'admin' | 'male_scrubber' | 'female_scrubber' | 'floor_attendant' | 'inventory'

export interface MobileEmployee {
  id: string
  username: string
  display_name: string
  role: MobileRole
  role_label: string
  capabilities?: {
    orders_view?: boolean
    order_all?: boolean
    catalog_all?: boolean
    reports_view?: boolean
    inventory_manage?: boolean
    reports?: boolean
    inventory_add?: boolean
  }
}

export interface MobileWristband {
  number: string
  bath_area: 'male' | 'female'
  visit_id: string
  version?: number
  opened_at: string
  amount: string
  package_catalog_item_id?: string | null
}

export interface MobileCatalogItem {
  id: string
  kind: 'service' | 'product' | 'package'
  package_definition?: {schema:number;display_contents:string[];slots:Array<{catalog_item_ids:string[];quantity:string}>} | null
  category: string
  name: string
  mobile_scope: 'frontdesk' | 'scrub' | 'rest' | 'both'
  price: string
  stock_tracked: boolean
  stock_quantity: string
  low_stock_threshold: string
  sort_order: number
}

export interface MobileBootstrap {
  employee: MobileEmployee
  wristbands: MobileWristband[]
  catalog: MobileCatalogItem[]
}

export interface MobileReportSummary {
  settlement_count: number
  operating_revenue: string
  member_recharge: string
  stored_value_recharge?: string
  pass_card_sales?: string
  actual_cash_inflow: string
  stored_value_consumed: string
  cashflow_totals: Record<string, string>
}

export interface MobileReportItem {
  kind: string
  name: string
  quantity: string
  amount: string
}

export interface MobileTrendPoint {
  date: string
  revenue: string
  recharge: string
  cash_inflow: string
  settlement_count: number
}

export interface MobileManagementReport {
  summary: MobileReportSummary
  items: MobileReportItem[]
  trend: MobileTrendPoint[]
}

export interface DownloadConfig {
  version: string
  versionCode: number
  minimumVersionCode: number
  androidApkUrl: string
  sha256: string
  releaseNotes: string
}
