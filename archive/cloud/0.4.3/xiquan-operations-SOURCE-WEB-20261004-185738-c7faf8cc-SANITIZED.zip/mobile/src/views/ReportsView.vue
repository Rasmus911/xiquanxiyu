<script setup lang="ts">
import { onMounted, ref } from 'vue'
import MobileTopbar from '../components/navigation/MobileTopbar.vue'
import MobileState from '../components/common/MobileState.vue'
import MobileMetricGrid from '../components/reports/MobileMetricGrid.vue'
import MobileTrendChart from '../components/reports/MobileTrendChart.vue'
import { useBusinessStore } from '../stores/business'

const business = useBusinessStore()
const days = ref<1 | 7 | 30>(1)
const paymentNames: Record<string, string> = { cash: '现金', wechat: '微信', alipay: '支付宝', balance: '会员储值' }

async function load(value = days.value) {
  days.value = value
  await business.loadReport(value).catch(() => undefined)
}

onMounted(() => load())
</script>

<template>
  <div>
    <MobileTopbar title="经营报表" subtitle="数据由云端统一核算" />
    <main class="mobile-page">
      <div class="segment">
        <button v-for="item in ([1, 7, 30] as const)" :key="item" :class="{ active: days === item }" @click="load(item)">
          {{ item === 1 ? '今日' : `${item}天` }}
        </button>
      </div>
      <MobileState v-if="business.loading && !business.report" kind="loading" title="正在生成报表" />
      <MobileState v-else-if="business.error && !business.report" kind="error" title="报表读取失败" :description="business.error" @retry="load()" />
      <template v-else-if="business.report">
        <MobileMetricGrid :summary="business.report.summary" />
        <section class="mobile-card">
          <h3>资金流入趋势</h3>
          <MobileTrendChart :rows="business.report.trend" />
        </section>
        <section class="mobile-card">
          <h3>收款方式</h3>
          <div v-for="(value, method) in business.report.summary.cashflow_totals" :key="method" class="payment-row">
            <span>{{ paymentNames[method] || method }}</span><strong>¥{{ Number(value).toFixed(2) }}</strong>
          </div>
        </section>
        <section class="mobile-card">
          <h3>热销项目</h3>
          <div v-if="!business.report.items.length" class="empty-copy">当前范围暂无消费项目</div>
          <div v-for="(row, index) in [...business.report.items].sort((a, b) => Number(b.amount) - Number(a.amount)).slice(0, 6)" :key="`${row.kind}-${row.name}`" class="rank">
            <b>{{ index + 1 }}</b><span>{{ row.name }}<small>{{ row.quantity }} 份</small></span><strong>¥{{ row.amount }}</strong>
          </div>
        </section>
      </template>
    </main>
  </div>
</template>

<style scoped>.empty-copy{padding:24px 0;color:var(--m-text-3);text-align:center;font-size:12px}.payment-row{display:flex;align-items:center;justify-content:space-between;min-height:42px;border-bottom:1px solid var(--m-border)}.payment-row:last-child{border:0}.payment-row span{color:var(--m-text-2);font-size:12px}.payment-row strong{color:var(--m-text-1);font-size:13px}</style>
