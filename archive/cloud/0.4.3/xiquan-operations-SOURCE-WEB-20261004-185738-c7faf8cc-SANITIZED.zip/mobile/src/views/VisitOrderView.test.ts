// @vitest-environment jsdom
import {afterEach,beforeEach,expect,it,vi} from 'vitest'
import {createApp,h,nextTick} from 'vue'
import {createPinia,setActivePinia} from 'pinia'
import {createMemoryHistory,createRouter} from 'vue-router'
import {acceptBusinessState,clearBusinessSession} from '../business/state'
import {http} from '../api'
import {useBusinessStore} from '../stores/business'
import {useConnectivityStore} from '../stores/connectivity'
import VisitOrderView from './VisitOrderView.vue'

let destroy:()=>void
beforeEach(()=>{clearBusinessSession(); destroy=()=>{}; vi.spyOn(window,'confirm').mockReturnValue(true)})
afterEach(()=>{destroy(); clearBusinessSession(); vi.restoreAllMocks()})

async function render(){
  acceptBusinessState({period_id:'test',business_revision:1,policy_version:1,maintenance:false,owner_reset_allowed:false},['mobile:order','visit:package'])
  const pinia=createPinia(); setActivePinia(pinia)
  const business=useBusinessStore()
  business.wristbands=[{number:'001',visit_id:'a',version:3,bath_area:'male',amount:'45.00',
    opened_at:'2026-10-04T08:00:00Z',package_catalog_item_id:'packageA'}]
  business.catalog=[]
  useConnectivityStore().markSynced()
  const router=createRouter({history:createMemoryHistory(),routes:[{path:'/orders/:visitId',component:VisitOrderView}]})
  await router.push('/orders/a'); await router.isReady()
  const root=document.createElement('div');document.body.append(root)
  const app=createApp({render:()=>h(VisitOrderView)});app.use(pinia);app.use(router);app.mount(root)
  destroy=()=>{app.unmount();root.remove()}
  await nextTick()
  return {root,business,router}
}

it('mobile cancel sends the captured visit version and restores its server bill',async()=>{
  const requests:any[]=[]
  const {root,business}=await render()
  http.defaults.adapter=async config=>{
    if(config.method==='delete') requests.push({url:config.url,body:JSON.parse(config.data)})
    return {config,headers:{},status:200,statusText:'',data:{data:config.method==='delete'?{}:{
      employee:{id:'owner',username:'fixture',display_name:'隔离用户',role:'admin',role_label:'管理员'},catalog:[],
      wristbands:[{...business.wristbands[0],amount:'15.00',package_catalog_item_id:null}]}}}
  }
  const button=[...root.querySelectorAll('button')].find(node=>node.textContent?.includes('取消套票'))
  expect(button).toBeDefined()
  button!.click()
  await vi.waitFor(()=>expect(business.wristbands[0]?.amount).toBe('15.00'))
  expect(requests[0]).toMatchObject({url:'/mobile/visits/a/package',body:{version:3}})
  expect(requests[0].body.idempotency_key).toBeTruthy()
  expect(requests[0].body).not.toHaveProperty('amount')
})

it('declining cancellation cannot send a request or change the package',async()=>{
  vi.mocked(window.confirm).mockReturnValue(false)
  const {root,business}=await render();let writes=0
  http.defaults.adapter=async()=>{writes++;throw new Error('must not call API')}
  const button=[...root.querySelectorAll('button')].find(node=>node.textContent?.includes('取消套票'))
  expect(button).toBeDefined();button!.click();await nextTick()
  expect(writes).toBe(0)
  expect(business.wristbands[0]?.package_catalog_item_id).toBe('packageA')
})
