<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { dataOf, errorMessage, http } from '../api'
import InventoryAddSheet from '../components/inventory/InventoryAddSheet.vue'
import InventoryList from '../components/inventory/InventoryList.vue'
import MobileTopbar from '../components/navigation/MobileTopbar.vue'
import MobileState from '../components/common/MobileState.vue'
import { clearPendingOperationKey, pendingOperationKey } from '../idempotency'
import { useBusinessStore } from '../stores/business'
import type { MobileCatalogItem } from '../types'

const business = useBusinessStore()
const search = ref('')
const selected = ref<MobileCatalogItem | null>(null)
const message = ref('')
const rows = computed(() => business.inventory.filter((row) => (
  !search.value.trim() || `${row.name}${row.category}`.includes(search.value.trim())
)))
const total = computed(() => business.inventory.reduce((sum, row) => sum + Number(row.stock_quantity), 0))
const low = computed(() => business.inventory.filter((row) => Number(row.stock_quantity) <= Number(row.low_stock_threshold)).length)

async function load() {
  const isCurrent = guardBusinessOperation('load')
  if (!isCurrent()) return
 await business.loadInventory().catch(() => undefined); if (!isCurrent()) return; }

async function save(value: { quantity: number; note: string }) {
  if (business.inventorySaving) return
  const isCurrent = guardBusinessOperation('save')
  if (!isCurrent()) return

  if (!selected.value) return
  const scope = `inventory-${selected.value.id}`
  const key = pendingOperationKey(scope, `${selected.value.id}|${value.quantity}|${value.note.trim()}`)
  const releaseBusy = business.beginBusinessOperation('inventory')
  message.value = ''
  try {
    dataOf(await http.post('/mobile/management/inventory/add', {
      catalog_item_id: selected.value.id,
      quantity: value.quantity,
      note: value.note.trim(),
    }, { headers: { 'Idempotency-Key': key } })); if (!isCurrent()) return;
    clearPendingOperationKey(scope)
    selected.value = null
    message.value = '库存入库成功'
    await Promise.all([business.loadInventory(true), business.refreshBootstrap(true)]); if (!isCurrent()) return;
  } catch (cause) { if (!isCurrent()) return; 
    message.value = errorMessage(cause)
  } finally {
    releaseBusy()
  }
}

function handleBack(event: Event) {
  if (!selected.value) return
  event.preventDefault()
  selected.value = null
}

onMounted(() => {
  document.addEventListener('xiquan:back-request', handleBack)
  void load()
})
onBeforeUnmount(() => document.removeEventListener('xiquan:back-request', handleBack))
</script>

<template>
  <div>
    <MobileTopbar title="库存入库" subtitle="仅最高权限账号可用" />
    <main class="mobile-page">
      <div v-if="message" class="notice">{{ message }}</div>
      <div class="mini-metrics">
        <article><span>商品</span><strong>{{ business.inventory.length }}</strong></article>
        <article><span>总量</span><strong>{{ total.toFixed(0) }}</strong></article>
        <article><span>低库存</span><strong>{{ low }}</strong></article>
      </div>
      <input v-model="search" class="mobile-input" placeholder="搜索商品" />
      <MobileState v-if="business.loading && !business.inventory.length" kind="loading" title="正在读取库存" />
      <MobileState v-else-if="business.error && !business.inventory.length" kind="error" title="库存读取失败" :description="business.error" @retry="load" />
      <MobileState v-else-if="!rows.length" kind="empty" title="没有符合条件的商品" />
      <InventoryList v-else :rows="rows" @select="selected = $event" />
    </main>
    <InventoryAddSheet :item="selected" :saving="business.inventorySaving" @close="selected = null" @save="save" />
  </div>
</template>
