<script setup lang="ts">
import { canAccess, useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { dataOf, errorMessage, http } from '../api'
import MobileState from '../components/common/MobileState.vue'
import MobileTopbar from '../components/navigation/MobileTopbar.vue'
import CatalogTabs from '../components/orders/CatalogTabs.vue'
import MobileCatalogPicker from '../components/orders/MobileCatalogPicker.vue'
import OrderSummaryBar from '../components/orders/OrderSummaryBar.vue'
import { changeProductQuantity, selectionTotals, selectedOrderRows, toggleServiceQuantity } from '../order-selection'
import { togglePackageSelection } from '../order-package'
import { pendingOperationKey, clearPendingOperationKey } from '../idempotency'
import { useBusinessStore } from '../stores/business'
import { useConnectivityStore } from '../stores/connectivity'
import type { MobileCatalogItem } from '../types'
import { ref } from 'vue'
const layoutEditing = ref(false)
const route=useRoute();const router=useRouter();const business=useBusinessStore();const connectivity=useConnectivityStore();const kind=ref<'all'|'service'|'product'>('all');const message=ref('');const now=ref(Date.now());let timer=0
const visitId=computed(()=>String(route.params.visitId));const band=computed(()=>business.wristbands.find(row=>row.visit_id===visitId.value));const rows=computed(()=>selectedOrderRows(business.catalog,business.quantities));const totals=computed(()=>selectionTotals(rows.value));const kinds=computed(()=>totals.value.kinds);const units=computed(()=>totals.value.units);const amount=computed(()=>totals.value.amount);const elapsed=computed(()=>{if(!band.value)return'';const seconds=Math.max(0,Math.floor((now.value-new Date(band.value.opened_at).getTime())/1000));return`${String(Math.floor(seconds/3600)).padStart(2,'0')}:${String(Math.floor(seconds%3600/60)).padStart(2,'0')}`})
function select(item:MobileCatalogItem){
  if(item.kind==='package') {
    if(canAccess('visit:package')) business.quantities=togglePackageSelection(business.quantities,business.catalog,item.id)
  } else if(item.kind==='service')business.quantities=toggleServiceQuantity(business.quantities,item.id)
  else business.quantities=changeProductQuantity(business.quantities,item,1)
}
function change(item:MobileCatalogItem,delta:number){if(item.kind==='product')business.quantities=changeProductQuantity(business.quantities,item,delta)}
async function submit(){
  if (!rows.value.length || !connectivity.canWrite || business.sending || layoutEditing.value) return
  const isCurrent = guardBusinessOperation('submit')
  if (!isCurrent()) return
  let target: ReturnType<typeof business.prepareOrder>
  const chosenPackage=rows.value.find(row=>row.kind==='package')
  const replacing=!!(chosenPackage && band.value?.package_catalog_item_id && chosenPackage.id!==band.value.package_catalog_item_id)
  if(replacing && !window.confirm(`更换为${chosenPackage!.name}？当前手牌未结账的包含项目将重新计费。`)) return
  try { target = business.prepareOrder(visitId.value, band.value?.version,
    rows.value.map(row => ({ catalog_item_id: row.id, quantity: row.quantity })),replacing) }
  catch (cause) { message.value = errorMessage(cause); return }
  const releaseBusy = business.beginBusinessOperation('order')
  message.value = ''
  try {
    if (!connectivity.lastSyncAt || Date.now() - connectivity.lastSyncAt > 30000) {
      await business.refreshBootstrap(true); if (!isCurrent()) return
      if (!business.wristbands.some(row => row.visit_id === target.visitId)) {
        message.value = '该手牌已结账或停用'
        await router.replace('/orders'); return
      }
    }
    dataOf(await http.post(`/mobile/visits/${target.visitId}/items`, { items: target.items, version: target.version,
      ...(target.confirmReplace ? {confirm_replace:true} : {}) }, { headers: { 'Idempotency-Key': target.key } }))
    if (!isCurrent()) return
    business.completeOrder(target.visitId); if(visitId.value===target.visitId) message.value = '加单成功'
    await business.refreshBootstrap(true)
  } catch (cause) { if (isCurrent()) {
    business.rejectOrder(target.visitId, (cause as { response?: { status: number } })?.response?.status)
    if(visitId.value===target.visitId) message.value = errorMessage(cause)
  } }
  finally { releaseBusy() }
}

async function cancelPackage(){
  if(!band.value?.package_catalog_item_id || !canAccess('visit:package') || !connectivity.canWrite || business.sending || layoutEditing.value) return
  const target={id:visitId.value,version:band.value.version}
  if(!window.confirm('取消套票后，现有包含项目恢复单项收费，已售商品库存不变。确定取消吗？')) return
  const isCurrent=guardBusinessOperation('cancelPackage'); if(!isCurrent()) return
  const scope=`package-cancel:${target.id}`
  const key=pendingOperationKey(scope,String(target.version))
  const releaseBusy=business.beginBusinessOperation('order')
  try {
    dataOf(await http.delete(`/mobile/visits/${target.id}/package`,{data:{version:target.version,idempotency_key:key}}))
    if(!isCurrent()) return
    clearPendingOperationKey(scope)
    if(visitId.value===target.id) message.value='套票已取消'
    await business.refreshBootstrap(true)
  } catch(cause) {
    if(!isCurrent()) return
    const status=(cause as {response?:{status:number}}).response?.status
    if(status && status>=400 && status<500) clearPendingOperationKey(scope)
    if(visitId.value===target.id) message.value=errorMessage(cause)
  } finally {releaseBusy()}
}

watch(visitId, id => { business.selectVisit(id); message.value = '' }, { immediate: true })
onMounted(()=>{timer=window.setInterval(()=>now.value=Date.now(),30000)});onBeforeUnmount(()=>window.clearInterval(timer))
</script>
<template><div><MobileTopbar :title="band?`${band.number} 号手牌`:'手牌点单'" :subtitle="band?`${band.bath_area==='male'?'男浴':'女浴'} · ${elapsed} · 当前消费 ¥${band.amount}`:''" back @back="router.replace('/orders')"/><main class="mobile-page order-page"><div v-if="message" class="notice">{{message}}</div><MobileState v-if="!band" kind="empty" title="该手牌已不在使用中" description="可能已经结账，请返回刷新"/><template v-else><div class="quick-order-header" data-testid="quick-order-header"><strong>快速加单</strong><OrderSummaryBar compact :kinds="kinds" :units="units" :amount="amount" :sending="business.sending" :disabled="layoutEditing||!units||!connectivity.canWrite||business.sending" @submit="submit"/></div><div v-if="band.package_catalog_item_id" class="notice">当前已选套票 · 账单金额以服务器为准 <button v-if="canAccess('visit:package')" :disabled="business.sending||layoutEditing||!connectivity.canWrite" @click="cancelPackage">取消套票</button></div><CatalogTabs v-if="!layoutEditing" v-model="kind"/><MobileCatalogPicker :items="business.catalog" :quantities="business.quantities" :kind="kind" :can-arrange="canAccess('catalog:layout')&&!business.sending" @select="select" @change="change" @editing-change="layoutEditing=$event" @arranged="business.refreshBootstrap(true)"/></template></main></div></template>
<style scoped>.order-page{padding-bottom:90px}.quick-order-header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px}</style>
