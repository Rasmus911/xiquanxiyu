from decimal import Decimal

from flask import Blueprint, request

from ..access_policy import emit_business_event
from ..audit_service import write_audit
from ..auth_service import current_employee, require_permission
from ..extensions import db
from ..financial_lock import serialized_financial_write
from ..idempotency_service import financial_request_key, guard_financial_request
from ..models import CatalogItem, InventoryMovement
from ..serializers import catalog_dict, iso
from ..validation import decimal_value
from .errors import ApiError, success

bp = Blueprint("inventory", __name__, url_prefix="/inventory")


def movement_dict(row):
    return {
        "id": row.id,
        "catalog_item_id": row.catalog_item_id,
        "movement_type": row.movement_type,
        "quantity": str(row.quantity),
        "balance_after": str(row.balance_after),
        "reference_type": row.reference_type,
        "reference_id": row.reference_id,
        "operator_id": row.operator_id,
        "note": row.note,
        "created_at": iso(row.created_at),
    }


@bp.get("")
@require_permission("inventory:read")
def list_inventory():
    products = CatalogItem.query.filter_by(kind="product").order_by(CatalogItem.name).all()
    return success([catalog_dict(row) for row in products])


@bp.get("/movements")
@require_permission("inventory:read")
def list_movements():
    query = InventoryMovement.query
    if request.args.get("catalog_item_id"):
        query = query.filter_by(catalog_item_id=request.args["catalog_item_id"])
    rows = query.order_by(InventoryMovement.created_at.desc()).limit(500).all()
    return success([movement_dict(row) for row in rows])


@bp.post("/adjust")
@require_permission("inventory:write")
@serialized_financial_write
def adjust_inventory():
    employee = current_employee()
    body = request.get_json(silent=True) or {}
    key = request.headers.get("Idempotency-Key") or body.get("idempotency_key")
    movement, repeated = adjust_inventory_data(employee, body, key)
    return success(
        movement_dict(movement),
        "已返回原库存结果" if repeated else "库存更新成功",
        200,
    )


def adjust_inventory_data(employee, body, key):
    from .. import financial_lock
    financial_lock.serialize_financial_session(db.session)
    if key:
        key = financial_request_key('inventory:adjust', employee.id, key)
    existing = InventoryMovement.query.filter_by(idempotency_key=key).first() if key else None
    if key:
        guard_financial_request(
            "inventory:adjust", employee, key, body, existing, existing.operator_id if existing else None
        )
    if existing:
        return existing, True
    item = CatalogItem.query.with_for_update().filter_by(id=body.get("catalog_item_id"), kind="product").first()
    if not item:
        raise ApiError("商品不存在", 404, "NOT_FOUND")
    quantity = decimal_value(body.get("quantity"), "数量", scale=3, minimum=None)
    movement_type = str(body.get("movement_type", "adjustment"))
    if movement_type in {"opening", "purchase", "return"} and quantity <= 0:
        raise ApiError("入库数量必须大于 0")
    if movement_type in {"loss"} and quantity > 0:
        quantity = -quantity
    if quantity == 0:
        raise ApiError("调整数量不能为 0")
    before_balance = Decimal(item.stock_quantity)
    new_balance = decimal_value(before_balance + quantity, "库存余额", scale=3, minimum=None)
    if new_balance < 0:
        raise ApiError("库存不能小于 0", 409, "INSUFFICIENT_STOCK")
    note = str(body.get("note", "")).strip()
    if not note and movement_type == "purchase":
        note = "采购入库"
    if not note:
        raise ApiError("库存调整必须填写原因或单据号")
    item.stock_quantity = new_balance
    item.version += 1
    movement = InventoryMovement(
        catalog_item_id=item.id,
        movement_type=movement_type,
        quantity=quantity,
        balance_after=new_balance,
        operator_id=employee.id,
        note=note,
        idempotency_key=key or None,
    )
    db.session.add(movement)
    db.session.flush()
    write_audit(
        "inventory.adjust",
        "inventory_movement",
        movement.id,
        {
            "item": item.name,
            "quantity": str(quantity),
            "balance_after": str(new_balance),
            "balance_before": str(before_balance),
            "note": note,
        },
    )
    db.session.commit()
    emit_business_event("inventory.changed", {"catalog_item_id": item.id})
    return movement, False
