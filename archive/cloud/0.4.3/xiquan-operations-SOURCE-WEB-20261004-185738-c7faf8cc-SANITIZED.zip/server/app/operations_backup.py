"""Private evidence gate for maintenance. Restore execution is a separate CLI step."""
import hashlib
import json
import os
import re
import stat
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from flask import current_app
from sqlalchemy import inspect, select

from .models import AuditLog, BusinessStateModel


class BackupReceiptError(ValueError):
    pass


def snapshot_identity(connection):
    state = connection.execute(select(BusinessStateModel.__table__)).mappings().one()
    last = connection.execute(select(AuditLog.chain_index, AuditLog.current_hash)
        .order_by(AuditLog.chain_index.desc()).limit(1)).first()
    revision = 'metadata-create-all'
    if inspect(connection).has_table('alembic_version'):
        revision = connection.exec_driver_sql('SELECT version_num FROM alembic_version').scalar_one()
    return dict(db_name=connection.engine.url.database or ':memory:', alembic_revision=revision,
        business_period_id=state['period_id'], business_revision=state['business_revision'],
        audit_checkpoint=dict(chain_index=last[0] if last else 0, current_hash=last[1] if last else '0'*64))


def _check_windows_acl(path):
    # A literal path passed through a private child environment, never interpolated
    # into script source. Deny broad readers as well as writers of private dumps.
    script = """$ErrorActionPreference='Stop'
$acl=Get-Acl -LiteralPath $env:XIQUAN_RECEIPT_ACL_PATH
$sid=[System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$allowed=@($sid,'S-1-5-18','S-1-5-32-544')
$owner=$acl.GetOwner([System.Security.Principal.SecurityIdentifier]).Value
if ($owner -notin $allowed) { exit 2 }
$allowed+= 'S-1-3-4' # OWNER RIGHTS resolves only to the already verified owner.
foreach ($rule in $acl.Access) {
  if ($rule.AccessControlType -eq 'Allow' -and
      $rule.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]).Value -notin $allowed) { exit 3 }
}
"""
    env = os.environ.copy()
    env['XIQUAN_RECEIPT_ACL_PATH'] = str(path)
    # A Core PowerShell parent can export incompatible module manifests.
    env['PSModulePath'] = str(Path(env.get('SYSTEMROOT','C:\\Windows')) / 'System32' /
        'WindowsPowerShell' / 'v1.0' / 'Modules')
    result = subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],
        env=env, capture_output=True, timeout=20)
    if result.returncode:
        raise BackupReceiptError('Private storage ACL must allow only its owner, SYSTEM and administrators')


def private_path(path, *, directory=False):
    configured = current_app.config.get('RESET_PRIVATE_DIR')
    if not configured:
        raise BackupReceiptError('Private backup storage is not configured')
    root = Path(configured).absolute()
    target = Path(path).absolute()
    if '..' in root.parts or '..' in target.parts:
        raise BackupReceiptError('Parent traversal is forbidden in private evidence paths')
    try:
        target.relative_to(root)
    except ValueError:
        raise BackupReceiptError('Backup evidence must remain inside private storage') from None
    # Check before resolve: resolving a symlink first would hide its provenance.
    for candidate in [*root.parents, root]:
        if candidate.is_symlink() or (hasattr(candidate, 'is_junction') and candidate.is_junction()):
            raise BackupReceiptError('Private storage cannot contain symlinks or junctions')
    for candidate in [root, *list(target.parents)[:len(target.relative_to(root).parts)-1], target]:
        if candidate.is_symlink() or (hasattr(candidate, 'is_junction') and candidate.is_junction()):
            raise BackupReceiptError('Private storage cannot contain symlinks or junctions')
        try:
            info = candidate.stat()
        except OSError:
            raise BackupReceiptError('Private backup evidence is missing') from None
        if os.name == 'nt':
            _check_windows_acl(candidate)
        elif info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) & 0o077:
            raise BackupReceiptError('Backup files require owner-only permissions')
    if (directory and not target.is_dir()) or (not directory and not target.is_file()):
        raise BackupReceiptError('Invalid private backup file type')
    if current_app.static_folder and target.resolve().is_relative_to(Path(current_app.static_folder).resolve()):
        raise BackupReceiptError('Backup evidence cannot be served publicly')
    return target


def file_digest(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        before = os.fstat(stream.fileno())
        for chunk in iter(lambda: stream.read(1024*1024), b''):
            digest.update(chunk)
        after = os.fstat(stream.fileno())
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise BackupReceiptError('Backup changed while being verified')
    return digest.hexdigest(), after.st_size


def validate_backup_receipt(connection, receipt_path: Path, expected_revision: str):
    path = private_path(receipt_path)
    try:
        if path.stat().st_size > 256*1024:
            raise ValueError
        data = json.loads(path.read_text(encoding='utf-8'))
        restore = data.get('restore', {})
        if (data.get('schema') != 1 or restore.get('status') != 'verified'
                or restore.get('pg_major') != 17 or not re.fullmatch('[0-9a-f]{64}', restore.get('checks_sha256',''))):
            raise ValueError
        checked = datetime.fromisoformat(restore['checked_at'])
        if checked.tzinfo is None or checked > datetime.now(timezone.utc):
            raise ValueError
        identity = snapshot_identity(connection)
        if identity['alembic_revision'] != expected_revision or any(data.get(key) != value for key,value in identity.items()):
            raise ValueError
        dump = private_path(data['dump_path'])
        digest, size = file_digest(dump)
        if size <= 0 or type(data['dump_size']) is not int or (digest,size) != (data['dump_sha256'],data['dump_size']):
            raise ValueError
    except (ValueError, TypeError, KeyError, OSError):
        raise BackupReceiptError('Backup receipt is unverified, changed or does not match the current database') from None
    return data
