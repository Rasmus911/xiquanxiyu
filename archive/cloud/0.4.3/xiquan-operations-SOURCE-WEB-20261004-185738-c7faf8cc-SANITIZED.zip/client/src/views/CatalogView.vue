<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { apiData, apiErrorMessage, http } from '../api/http'
import { subscribeRealtime } from '../realtime/events'
import AppPageHeader from '../components/app/AppPageHeader.vue'
import type { CatalogItem } from '../types'

const rows = ref<CatalogItem[]>([])
const drawerOpen = ref(false)
const keyword = ref('')
const kindFilter = ref('')
const statusFilter = ref('')
const editingId = ref('')
const form = reactive({ kind: 'service', category: '默认', name: '', mobile_scope: 'frontdesk', price: 0, stock_tracked: false, low_stock_threshold: 0, sort_order: 0, is_active: true })
let unsubscribeRealtime: (() => void) | undefined
const kindNames: Record<string, string> = { ticket: '门票', service: '服务', product: '商品', compensation: '赔偿' }
const mobileScopeNames: Record<string, string> = { frontdesk: '仅前台', scrub: '搓澡端', rest: '三层服务端', both: '全部手机端' }
const filteredRows = computed(() => rows.value.filter((row) => {
  if (kindFilter.value && row.kind !== kindFilter.value) return false
  if (statusFilter.value && String(row.is_active) !== statusFilter.value) return false
  const query = keyword.value.trim()
  return !query || row.name.includes(query) || row.category.includes(query)
}))

async function load() {
  const isCurrent = guardBusinessOperation('load')
  if (!isCurrent()) return

  try { const data = apiData<CatalogItem[]>(await http.get('/catalog')); if (!isCurrent()) return; rows.value = data } catch (error) { if (!isCurrent()) return;  ElMessage.error(apiErrorMessage(error)) }
}

function createNew() {
  editingId.value = ''
  Object.assign(form, { kind: 'service', category: '默认', name: '', mobile_scope: 'frontdesk', price: 0, stock_tracked: false, low_stock_threshold: 0, sort_order: 0, is_active: true })
  drawerOpen.value = true
}

function edit(row: CatalogItem) {
  editingId.value = row.id
  Object.assign(form, { ...row, price: Number(row.price), low_stock_threshold: Number(row.low_stock_threshold) })
  drawerOpen.value = true
}

async function save() {
  const isCurrent = guardBusinessOperation('save')
  if (!isCurrent()) return

  try {
    if (editingId.value) await http.patch(`/catalog/${editingId.value}`, form)
    else await http.post('/catalog', form); if (!isCurrent()) return;
    ElMessage.success('保存成功')
    drawerOpen.value = false
    await load(); if (!isCurrent()) return;
  } catch (error) { if (!isCurrent()) return;  ElMessage.error(apiErrorMessage(error)) }
}

onMounted(() => {
  load()
  unsubscribeRealtime = subscribeRealtime(['catalog', 'inventory'], () => load())
})
onBeforeUnmount(() => unsubscribeRealtime?.())
</script>

<template>
  <div class="page">
    <AppPageHeader title="服务与商品" description="价格修改不会影响历史账单；手机端只显示其岗位允许销售的项目。" eyebrow="CATALOG"><template #actions><el-button type="primary" @click="createNew">新增项目</el-button></template></AppPageHeader>
    <div class="catalog-filters"><el-input v-model="keyword" clearable prefix-icon="Search" placeholder="搜索名称或分类" /><el-select v-model="kindFilter" clearable placeholder="全部类型"><el-option v-for="(name, key) in kindNames" :key="key" :label="name" :value="key" /></el-select><el-select v-model="statusFilter" clearable placeholder="全部状态"><el-option label="启用" value="true" /><el-option label="停用" value="false" /></el-select></div>
    <el-card shadow="never"><el-table :data="filteredRows">
      <el-table-column label="类型" width="85"><template #default="scope"><el-tag>{{ kindNames[scope.row.kind] }}</el-tag></template></el-table-column>
      <el-table-column prop="category" label="分类" width="120" /><el-table-column prop="name" label="名称" min-width="180" />
      <el-table-column label="手机端权限" width="130"><template #default="scope"><el-tag type="info">{{ mobileScopeNames[scope.row.mobile_scope] }}</el-tag></template></el-table-column>
      <el-table-column prop="price" label="售价" width="110"><template #default="scope">¥{{ scope.row.price }}</template></el-table-column>
      <el-table-column label="库存" width="130"><template #default="scope">{{ scope.row.stock_tracked ? scope.row.stock_quantity : '不计库存' }}</template></el-table-column>
      <el-table-column label="状态" width="90"><template #default="scope"><el-tag :type="scope.row.is_active ? 'success' : 'info'">{{ scope.row.is_active ? '启用' : '停用' }}</el-tag></template></el-table-column>
      <el-table-column label="操作" width="90"><template #default="scope"><el-button link type="primary" @click="edit(scope.row)">编辑</el-button></template></el-table-column>
    </el-table></el-card>
    <el-drawer v-model="drawerOpen" :title="editingId ? '编辑项目' : '新增项目'" size="520px">
      <el-form label-position="top">
        <el-row :gutter="12"><el-col :span="12"><el-form-item label="类型"><el-select v-model="form.kind" :disabled="Boolean(editingId)" class="full-width"><el-option v-for="(name, key) in kindNames" :key="key" :label="name" :value="key" /></el-select></el-form-item></el-col><el-col :span="12"><el-form-item label="分类"><el-input v-model="form.category" /></el-form-item></el-col></el-row>
        <el-form-item label="名称"><el-input v-model="form.name" /></el-form-item>
        <el-form-item label="手机端销售范围"><el-select v-model="form.mobile_scope" class="full-width"><el-option v-for="(name, key) in mobileScopeNames" :key="key" :label="name" :value="key" /></el-select><div class="muted" style="margin-top: 6px">门票、赔偿等请选择“仅前台”；搓澡与三层人员只会看到各自允许的项目。</div></el-form-item>
        <el-row :gutter="12"><el-col :span="12"><el-form-item label="售价"><el-input-number v-model="form.price" :min="0" :precision="2" class="full-width" /></el-form-item></el-col><el-col :span="12"><el-form-item label="排序"><el-input-number v-model="form.sort_order" class="full-width" /></el-form-item></el-col></el-row>
        <el-form-item v-if="form.kind === 'product'" label="库存设置"><el-switch v-model="form.stock_tracked" active-text="跟踪库存" /><el-input-number v-if="form.stock_tracked" v-model="form.low_stock_threshold" :min="0" placeholder="最低库存" style="margin-left: 15px" /></el-form-item>
        <el-form-item v-if="editingId" label="状态"><el-switch v-model="form.is_active" active-text="启用" inactive-text="停用" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="drawerOpen = false">取消</el-button><el-button type="primary" @click="save">保存</el-button></template>
    </el-drawer>
  </div>
</template>
<style scoped>.catalog-filters{display:flex;gap:9px;margin-bottom:14px}.catalog-filters .el-input{max-width:280px}.catalog-filters .el-select{width:150px}</style>
