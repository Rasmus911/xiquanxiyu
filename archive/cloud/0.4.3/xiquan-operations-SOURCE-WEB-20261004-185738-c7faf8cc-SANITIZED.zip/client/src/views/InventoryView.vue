<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { apiData, apiErrorMessage, http } from '../api/http'
import AppPageHeader from '../components/app/AppPageHeader.vue'
import { clearPendingRequestKey, pendingRequestKey } from '../domain/requests/pending-key'
import { subscribeRealtime } from '../realtime/events'
import type { CatalogItem } from '../types'
import { formatBusinessTime } from '../format/business-time'

const products = ref<CatalogItem[]>([])
const movements = ref<Array<Record<string, string>>>([])
const drawerOpen = ref(false)
const saving = ref(false)
const keyword = ref('')
const category = ref('')
const form = reactive({ catalog_item_id: '', movement_type: 'purchase', quantity: 1, note: '' })
let unsubscribeRealtime: (() => void) | undefined

const categories = computed(() => [...new Set(products.value.map((row) => row.category))])
const filtered = computed(() => products.value.filter((row) => {
  if (category.value && row.category !== category.value) return false
  return !keyword.value.trim() || row.name.includes(keyword.value.trim())
}))
const summary = computed(() => ({
  products: products.value.length,
  quantity: products.value.reduce((sum, row) => sum + Number(row.stock_quantity || 0), 0),
  low: products.value.filter((row) => Number(row.stock_quantity) <= Number(row.low_stock_threshold)).length,
}))
const movementNames: Record<string, string> = { purchase: '采购入库', opening: '期初库存', return: '退货入库', loss: '报损', adjustment: '盘点调整', sale: '销售出库', void_return: '撤销返库' }

async function load(silent = false) {
  const isCurrent = guardBusinessOperation('load')
  if (!isCurrent()) return

  try {
    const [inventoryResponse, movementsResponse] = await Promise.all([http.get('/inventory'), http.get('/inventory/movements')]); if (!isCurrent()) return;
    products.value = apiData<CatalogItem[]>(inventoryResponse)
    movements.value = apiData<Array<Record<string, string>>>(movementsResponse)
  } catch (error) { if (!isCurrent()) return;  if (!silent) ElMessage.error(apiErrorMessage(error)) }
}

function adjust(row?: CatalogItem) {
  Object.assign(form, { catalog_item_id: row?.id || '', movement_type: 'purchase', quantity: 1, note: '' })
  drawerOpen.value = true
}

async function save() {
  const isCurrent = guardBusinessOperation('save')
  if (!isCurrent()) return

  if (!form.catalog_item_id) return ElMessage.warning('请选择商品')
  if (['loss', 'adjustment', 'opening', 'return'].includes(form.movement_type) && !form.note.trim()) return ElMessage.warning('该操作必须填写原因或单据号')
  const scope = `inventory:${form.catalog_item_id}:adjust`
  const fingerprint = `${form.catalog_item_id}|${form.movement_type}|${form.quantity}|${form.note.trim()}`
  const key = pendingRequestKey(scope, fingerprint)
  saving.value = true
  try {
    await http.post('/inventory/adjust', { ...form, idempotency_key: key }, { headers: { 'Idempotency-Key': key } }); if (!isCurrent()) return;
    clearPendingRequestKey(scope)
    ElMessage.success('库存更新成功')
    drawerOpen.value = false
    await load(); if (!isCurrent()) return;
  } catch (error) { if (!isCurrent()) return;  ElMessage.error(apiErrorMessage(error)) } finally { if (!isCurrent()) return;  saving.value = false }
}

onMounted(() => {
  load()
  unsubscribeRealtime = subscribeRealtime(['inventory', 'catalog'], () => load(true))
})
onBeforeUnmount(() => unsubscribeRealtime?.())
</script>

<template>
  <div class="page inventory-page">
    <AppPageHeader title="库存管理" description="商品销售自动扣减；采购入库只需数量，报损和盘点必须填写原因。" eyebrow="INVENTORY"><template #actions><el-button type="primary" @click="adjust()"><el-icon><Plus /></el-icon>采购入库 / 调整</el-button></template></AppPageHeader>
    <section class="inventory-summary"><article><span>库存商品</span><strong>{{ summary.products }}</strong><small>种</small></article><article><span>库存总量</span><strong>{{ summary.quantity.toFixed(0) }}</strong><small>件</small></article><article :class="{ warning: summary.low }"><span>低库存</span><strong>{{ summary.low }}</strong><small>种需要关注</small></article></section>
    <div class="inventory-toolbar"><el-input v-model="keyword" clearable prefix-icon="Search" placeholder="搜索商品" /><el-select v-model="category" clearable placeholder="全部分类"><el-option v-for="name in categories" :key="name" :label="name" :value="name" /></el-select></div>
    <el-row :gutter="18">
      <el-col :span="15"><el-card shadow="never"><template #header><strong>当前库存</strong></template><el-table :data="filtered"><el-table-column prop="name" label="商品" min-width="140" /><el-table-column prop="category" label="分类" /><el-table-column label="库存"><template #default="scope"><strong>{{ scope.row.stock_quantity }}</strong></template></el-table-column><el-table-column label="状态"><template #default="scope"><el-tag :type="Number(scope.row.stock_quantity) <= Number(scope.row.low_stock_threshold) ? 'danger' : 'success'">{{ Number(scope.row.stock_quantity) <= Number(scope.row.low_stock_threshold) ? '库存偏低' : '充足' }}</el-tag></template></el-table-column><el-table-column label="操作" width="80"><template #default="scope"><el-button link type="primary" @click="adjust(scope.row)">调整</el-button></template></el-table-column></el-table></el-card></el-col>
      <el-col :span="9"><el-card shadow="never"><template #header><strong>最近库存流水</strong></template><el-timeline class="movement-list"><el-timeline-item v-for="row in movements.slice(0, 16)" :key="row.id" :timestamp="formatBusinessTime(row.created_at)"><div class="movement"><strong>{{ movementNames[row.movement_type] || row.movement_type }}</strong><b :class="Number(row.quantity) >= 0 ? 'in' : 'out'">{{ Number(row.quantity) >= 0 ? '+' : '' }}{{ row.quantity }}</b><span>结存 {{ row.balance_after }} · {{ row.note }}</span></div></el-timeline-item></el-timeline><el-empty v-if="!movements.length" description="暂无库存流水" /></el-card></el-col>
    </el-row>
    <el-drawer v-model="drawerOpen" title="库存入库 / 调整" size="480px"><el-form label-position="top"><el-form-item label="商品"><el-select v-model="form.catalog_item_id" filterable class="full-width"><el-option v-for="row in products" :key="row.id" :label="`${row.name}（当前 ${row.stock_quantity}）`" :value="row.id" /></el-select></el-form-item><el-form-item label="操作类型"><el-select v-model="form.movement_type" class="full-width"><el-option label="采购入库" value="purchase" /><el-option label="期初库存" value="opening" /><el-option label="退货入库" value="return" /><el-option label="报损" value="loss" /><el-option label="盘点调整" value="adjustment" /></el-select></el-form-item><el-form-item label="变动数量"><el-input-number v-model="form.quantity" :precision="3" class="full-width" /></el-form-item><el-form-item :label="form.movement_type === 'purchase' ? '原因 / 单据号（选填）' : '原因 / 单据号（必填）'"><el-input v-model="form.note" :placeholder="form.movement_type === 'purchase' ? '留空将记录为“采购入库”' : '请填写可追溯原因'" /></el-form-item></el-form><template #footer><el-button @click="drawerOpen = false">取消</el-button><el-button type="primary" :loading="saving" @click="save">确认更新</el-button></template></el-drawer>
  </div>
</template>

<style scoped>
.inventory-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:13px;margin-bottom:16px}.inventory-summary article{padding:15px 18px;border:1px solid var(--xq-border);border-radius:var(--xq-radius-md);background:white;box-shadow:var(--xq-shadow-card)}.inventory-summary span,.inventory-summary strong,.inventory-summary small{display:block}.inventory-summary span{color:var(--xq-text-3);font-size:11px}.inventory-summary strong{margin-top:4px;color:var(--xq-text-1);font-size:27px}.inventory-summary small{color:var(--xq-text-3)}.inventory-summary .warning strong{color:var(--xq-danger)}.inventory-toolbar{display:flex;gap:9px;margin-bottom:14px}.inventory-toolbar .el-input{max-width:260px}.inventory-toolbar .el-select{width:170px}.movement-list{max-height:620px;overflow:auto}.movement{display:grid;grid-template-columns:1fr auto;gap:3px 8px}.movement span{grid-column:1/-1;color:var(--xq-text-3);font-size:10px}.movement b.in{color:var(--xq-accent)}.movement b.out{color:var(--xq-danger)}
</style>
