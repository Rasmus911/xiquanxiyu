<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { onBeforeRouteLeave, useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { apiData, apiErrorMessage, http } from '../api/http'
import AppPageHeader from '../components/app/AppPageHeader.vue'
import PaymentPanel from '../components/checkout/PaymentPanel.vue'
import VisitSelector from '../components/checkout/VisitSelector.vue'
import { checkoutFingerprint, checkoutRequestKey, clearCheckoutRequest } from '../domain/checkout/checkout-request'
import { initialCheckoutSelection, toggleCheckoutVisit } from '../domain/checkout/selection'
import { subscribeRealtime } from '../realtime/events'
import { useAuthStore } from '../stores/auth'
import { useConnectivityStore } from '../stores/connectivity'
import { useRuntimeStore } from '../stores/runtime'
import type { Member } from '../types'

interface Preview { visits: Array<{ visit_id: string; wristband_number: string; amount: string }>; total_amount: string; auto_included_linked_visits?: number; checkout_scope?: 'party' | 'selected' }
interface PaymentInput { method: string; amount: number; reference: string }

const route = useRoute()
const router = useRouter()
const auth = useAuthStore()
const runtime = useRuntimeStore()
const connectivity = useConnectivityStore()
const preview = ref<Preview | null>(null)
const availableVisits = ref<Preview['visits']>([])
const selectedVisitIds = ref<string[]>([])
const loading = ref(false)
const payments = reactive<PaymentInput[]>([{ method: 'cash', amount: 0, reference: '' }])
const memberId = ref('')
const memberPhone = ref('')
const selectedMember = ref<Member | null>(null)
const entryVisitIds = computed(() => String(route.query.visits || '').split(',').filter(Boolean))
const checkoutScope = computed<'party' | 'selected'>(() => route.query.scope === 'selected' ? 'selected' : 'party')
const isIndividualCheckout = computed(() => selectedVisitIds.value.length < availableVisits.value.length)
const paid = computed(() => payments.reduce((sum, row) => sum + Number(row.amount || 0), 0).toFixed(2))
const balanced = computed(() => Number(paid.value) === Number(preview.value?.total_amount || 0))
let refreshTimer: number | undefined
let unsubscribeRealtime: (() => void) | undefined

async function load(silent = false) {
  const isCurrent = guardBusinessOperation('load')
  if (!isCurrent()) return

  if (!selectedVisitIds.value.length) return
  try {
    const previousTotal = preview.value?.total_amount
    const nextPreview = apiData<Preview>(await http.post('/checkout/preview', {
      visit_ids: selectedVisitIds.value,
      checkout_scope: 'selected',
    })); if (!isCurrent()) return;
    const canAutoBalance = payments.length === 1 && (!previousTotal || Number(payments[0].amount) === Number(previousTotal))
    preview.value = nextPreview
    if (canAutoBalance) payments[0].amount = Number(nextPreview.total_amount)
  } catch (error) { if (!isCurrent()) return; 
    if (!silent) ElMessage.error(apiErrorMessage(error))
  }
}

async function initialize() {
  const isCurrent = guardBusinessOperation('initialize')
  if (!isCurrent()) return

  resetMember()
  try {
    const discovery = apiData<Preview>(await http.post('/checkout/preview', {
      visit_ids: entryVisitIds.value,
      checkout_scope: 'party',
    })); if (!isCurrent()) return;
    availableVisits.value = discovery.visits
    selectedVisitIds.value = initialCheckoutSelection(
      discovery.visits,
      entryVisitIds.value[0] || '',
      checkoutScope.value,
    )
    await load(); if (!isCurrent()) return;
  } catch (error) { if (!isCurrent()) return; 
    ElMessage.error(apiErrorMessage(error))
  }
}

async function toggleVisit(visitId: string) {
  const isCurrent = guardBusinessOperation('toggleVisit')
  if (!isCurrent()) return

  const next = toggleCheckoutVisit(selectedVisitIds.value, visitId)
  if (next === selectedVisitIds.value) return ElMessage.warning('至少保留一个手牌进行结账')
  selectedVisitIds.value = next
  await load(); if (!isCurrent()) return;
}

function addPayment() {
  payments.push({ method: 'wechat', amount: 0, reference: '' })
}

function removePayment(index: number) {
  payments.splice(index, 1)
}

function resetMember() {
  memberPhone.value = ''
  selectedMember.value = null
  memberId.value = ''
}

async function findMember() {
  const isCurrent = guardBusinessOperation('findMember')
  if (!isCurrent()) return

  selectedMember.value = null
  memberId.value = ''
  const normalizedPhone = memberPhone.value.replace(/\D/g, '')
  if (!/^1\d{10}$/.test(normalizedPhone)) return ElMessage.warning('请输入完整的 11 位会员手机号')
  try {
    const data = apiData<Member>(await http.get('/members/lookup', { params: { phone: normalizedPhone } })); if (!isCurrent()) return; selectedMember.value = data
    memberId.value = selectedMember.value?.id || ''
  } catch (error) { if (!isCurrent()) return; 
    ElMessage.error(apiErrorMessage(error))
  }
}

watch(memberPhone, () => {
  if (selectedMember.value?.phone.replace(/\D/g, '') !== memberPhone.value.replace(/\D/g, '')) {
    selectedMember.value = null
    memberId.value = ''
  }
})

watch(() => payments.map((row) => row.method), (methods) => {
  if (!methods.includes('balance')) {
    memberPhone.value = ''
    selectedMember.value = null
    memberId.value = ''
  }
}, { deep: true })

async function complete() {
  const isCurrent = guardBusinessOperation('complete')
  if (!isCurrent()) return

  if (!balanced.value) return ElMessage.warning('支付合计必须等于应收金额')
  if (payments.some((row) => row.method === 'balance') && !selectedMember.value) {
    return ElMessage.warning('请重新输入完整手机号并查询储值卡会员')
  }
  loading.value = true
  const releaseBusy = await runtime.setBusinessBusy('正在确认收款')
  if (!isCurrent()) { await releaseBusy(); return }
  const key = checkoutRequestKey(checkoutFingerprint(selectedVisitIds.value, payments, memberId.value))
  try {
    const settlement = apiData<{ id: string; number: string }>(await http.post('/checkout', {
      visit_ids: selectedVisitIds.value,
      checkout_scope: 'selected',
      member_id: memberId.value || null,
      payments,
      idempotency_key: key,
    }, { headers: { 'Idempotency-Key': key } })); if (!isCurrent()) return;
    clearCheckoutRequest()
    ElMessage.success(`结账成功：${settlement.number}`)
    const receipt = apiData<Record<string, unknown>>(await http.get(`/checkout/${settlement.id}/receipt`)); if (!isCurrent()) return;
    const printerName = auth.terminal?.printer_name || localStorage.getItem('xiquan_printer_name') || undefined
    const result = window.xiquan
      ? await window.xiquan.printReceipt(receipt, printerName)
      : { success: false, error: '浏览器模式不支持静默打印' }; if (!isCurrent()) return;
    await http.post(`/checkout/${settlement.id}/print-result`, result); if (!isCurrent()) return;
    if (!result.success) {
      ElMessage.warning(`结账已成功，小票待补打：${result.error}`)
      await router.replace('/print-jobs'); if (!isCurrent()) return;
    } else {
      await router.replace('/'); if (!isCurrent()) return;
    }
  } catch (error) { if (!isCurrent()) return; 
    const code = typeof error === 'object' && error && 'code' in error ? String(error.code) : ''
    if (code === 'ECONNABORTED' || code === 'ETIMEDOUT') {
      ElMessage.warning('正在确认服务器结果，请勿更改金额；可使用同一内容重试。')
    } else {
      ElMessage.error(apiErrorMessage(error))
    }
  } finally {
    if (isCurrent()) loading.value = false
    await releaseBusy()
  }
}

onMounted(() => {
  initialize()
  unsubscribeRealtime = subscribeRealtime(['visits', 'wristbands', 'members'], () => load(true))
  refreshTimer = window.setInterval(() => {
    if (!connectivity.isOnline && document.visibilityState === 'visible') load(true)
  }, 30_000)
})

onBeforeRouteLeave(() => resetMember())

onBeforeUnmount(() => {
  unsubscribeRealtime?.()
  if (refreshTimer) window.clearInterval(refreshTimer)
})
</script>

<template>
  <div class="page checkout-page">
    <AppPageHeader :title="isIndividualCheckout ? '选择手牌结账' : '统一结账'" description="先确认本次结账手牌，再填写支付方式；收款成功与打印小票相互独立。" eyebrow="CHECKOUT" />
    <el-card shadow="never" class="checkout-card">
      <section class="checkout-step">
        <div class="step-title"><div><strong>1. 选择本次结账手牌</strong><span>未选中的联动手牌会继续使用，不受本次结账影响</span></div><b>应收 ¥{{ preview?.total_amount || '0.00' }}</b></div>
        <VisitSelector :visits="availableVisits" :selected-ids="selectedVisitIds" @toggle="toggleVisit" />
        <el-alert v-if="isIndividualCheckout" type="warning" :closable="false" show-icon title="本次只结所选手牌；结账后，其余联动手牌仍可继续消费。" />
      </section>
      <el-divider />
      <PaymentPanel :payments="payments" :total="preview?.total_amount || '0.00'" :paid="paid" :balanced="balanced" :disabled="loading" @add="addPayment" @remove="removePayment" />
      <div v-if="payments.some((x) => x.method === 'balance')" class="member-lookup">
        <strong>会员储值验证</strong>
        <div class="toolbar"><el-input v-model="memberPhone" maxlength="11" placeholder="每次请输入完整的 11 位手机号" @keyup.enter="findMember" /><el-button @click="findMember">查询会员</el-button></div>
        <el-alert v-if="selectedMember" type="success" :closable="false" :title="`${selectedMember.name || selectedMember.phone}，余额 ¥${selectedMember.balance}`" />
      </div>
      <el-divider />
      <section class="submit-step"><div><strong>3. 确认收款</strong><span>收款完成后即视为结账成功；打印失败请到“小票补打”处理。</span></div><el-button type="success" size="large" :loading="loading" :disabled="!balanced || !selectedVisitIds.length" @click="complete">确认收款 ¥{{ preview?.total_amount || '0.00' }}</el-button></section>
    </el-card>
  </div>
</template>

<style scoped>
.checkout-page { max-width: 1040px; margin: 0 auto; }
.checkout-card { border-radius: var(--xq-radius-lg); }
.checkout-step { display: grid; gap: 14px; }
.step-title, .submit-step { display: flex; align-items: center; justify-content: space-between; gap: 20px; }
.step-title strong, .step-title span, .submit-step strong, .submit-step span { display: block; }
.step-title span, .submit-step span { margin-top: 4px; color: var(--xq-text-3); font-size: 11px; }
.step-title > b { color: var(--xq-danger); font-size: 23px; }
.member-lookup { display: grid; gap: 9px; margin-top: 16px; padding: 14px; border: 1px solid #cfe0ff; border-radius: 11px; background: #f6f9ff; }
.member-lookup .toolbar { justify-content: flex-start; }
.member-lookup .el-input { max-width: 330px; }
</style>
