import { afterEach, beforeEach, expect, it } from 'vitest'
import { effectScope } from 'vue'
import { http } from '../api/http'
import { clearBusinessSession } from '../business/state'
import { useVisitOrdering } from './useVisitOrdering'

const scope = effectScope()
beforeEach(() => clearBusinessSession())
afterEach(() => clearBusinessSession())

it('out of order detail requests cannot overwrite the current selection', async () => {
  const finish = new Map<string, () => void>()
  http.defaults.adapter = config => new Promise(resolve => finish.set(String(config.url), () => resolve({
    config, headers: {}, status: 200, statusText: '', data: { data: { id: String(config.url).split('/').at(-1), version: 1 } },
  })))
  const ordering = scope.run(() => useVisitOrdering())!
  const a = ordering.load('a'); const b = ordering.load('b'); const c = ordering.load('c')
  finish.get('/visits/c')!(); await c
  finish.get('/visits/b')!(); await b
  finish.get('/visits/a')!(); await a
  expect(ordering.currentVisit.value?.id).toBe('c')
  expect(ordering.loading.value).toBe(false)
})
it('uncertain retries preserve the original version, UUID, quantities and key', async () => {
  const requests: any[] = []; let fail = true
  http.defaults.adapter = async config => {
    requests.push({ url: config.url, body: JSON.parse(config.data), key: config.headers['Idempotency-Key'] })
    if (fail) throw new Error('network unavailable')
    return { config, headers: {}, status: 201, statusText: '', data: { data: [] } }
  }
  const ordering = scope.run(() => useVisitOrdering())!
  ordering.drafts.replace('a', { soap: 2 })
  await expect(ordering.submitSnapshot(ordering.drafts.capture('a', 3))).rejects.toThrow()
  ordering.drafts.replace('b', { water: 4 })
  fail = false
  await ordering.submitSnapshot(ordering.drafts.capture('a', 8))
  expect(requests[1]).toEqual(requests[0])
  expect(requests[1].body.version).toBe(3)
  expect(ordering.drafts.read('b')).toEqual({ water: 4 })
})
it('old submission success does not clear a new session draft', async () => {
  let finish!: () => void
  http.defaults.adapter = config => new Promise(resolve => { finish = () => resolve({ config,
    headers: {}, status: 201, statusText: '', data: { data: [] } }) })
  const ordering = scope.run(() => useVisitOrdering())!
  ordering.drafts.replace('a', { soap: 2 })
  const pending = ordering.submitSnapshot(ordering.drafts.capture('a', 1)).catch(() => undefined)
  clearBusinessSession(); ordering.drafts.replace('a', { water: 5 })
  finish(); await pending
  expect(ordering.drafts.read('a')).toEqual({ water: 5 })
})

it('uncertain package replacement retains the confirmed immutable payload', async () => {
  const requests: any[]=[]; let fail=true
  http.defaults.adapter=async config=>{
    requests.push({url:config.url,body:JSON.parse(config.data),key:config.headers['Idempotency-Key']})
    if(fail) throw new Error('lost reply')
    return {config,headers:{},status:201,statusText:'',data:{data:[]}}
  }
  const ordering=scope.run(()=>useVisitOrdering())!
  ordering.drafts.replace('a',{packageB:1,water:2})
  const target=Object.freeze({...ordering.drafts.capture('a',3),confirmReplace:true})
  await expect(ordering.submitSnapshot(target)).rejects.toThrow()
  fail=false
  await ordering.submitSnapshot({...target,visitVersion:8})
  expect(requests[1]).toEqual(requests[0])
  expect(requests[0].body.confirm_replace).toBe(true)
  expect(requests[0].body).not.toHaveProperty('price')
})
