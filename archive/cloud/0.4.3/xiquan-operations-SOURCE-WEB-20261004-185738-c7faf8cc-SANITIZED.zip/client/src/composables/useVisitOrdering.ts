import { ref } from 'vue'
import { apiData, apiErrorMessage, http } from '../api/http'
import { assertCurrent, businessGeneration, onBusinessSessionClear } from '../business/state'
import { createVisitLoadGate } from '../domain/orders/load-gate'
import { VisitDraftBook, type SubmissionSnapshot } from '../domain/orders/visit-drafts'
import { orderFingerprint } from '../domain/orders/selection'
import { clearPendingRequestKey, pendingRequestKey } from '../domain/requests/pending-key'
import type { Visit } from '../types'

const pending = new Map<string, { target: SubmissionSnapshot; key: string; fingerprint: string }>()
onBusinessSessionClear(() => pending.clear())
export function useVisitOrdering() {
  const currentVisit = ref<Visit | null>(null)
  const loading = ref(false)
  const error = ref('')
  const gate = createVisitLoadGate()
  const drafts = new VisitDraftBook()
  onBusinessSessionClear(() => {
    gate.reset(); drafts.clear(); pending.clear(); currentVisit.value = null; loading.value = false; error.value = ''
  })
  async function load(id: string) {
    const generation = businessGeneration.capture()
    const ticket = gate.begin(id)
    const current = () => businessGeneration.isCurrent(generation) && gate.current(ticket)
    loading.value = true; error.value = ''
    try {
      const result = apiData<Visit>(await http.get(`/visits/${id}`))
      if (current()) currentVisit.value = result
    } catch (cause) {
      if (current()) error.value = apiErrorMessage(cause)
    } finally { if (current()) loading.value = false }
  }
  async function submitSnapshot(target: SubmissionSnapshot) {
    const generation = businessGeneration.capture()
    const scope = `visit:${target.visitId}:batch-add`
    const fingerprint = orderFingerprint(target.visitId, target.quantities) + '|replace:' + !!target.confirmReplace
    const previous = pending.get(target.visitId)
    if (previous && previous.fingerprint !== fingerprint) throw new Error('上一笔加单尚未确认，请先重试原选择')
    const request = previous || { target, fingerprint,
      key: pendingRequestKey(scope, `${target.visitVersion}|${fingerprint}`) }
    pending.set(target.visitId, request)
    try {
      await http.post(`/visits/${request.target.visitId}/items/batch`, {
        version: request.target.visitVersion,
        items: Object.entries(request.target.quantities).map(([catalog_item_id, quantity]) => ({ catalog_item_id, quantity })),
        idempotency_key: request.key,
        ...(request.target.confirmReplace ? {confirm_replace:true} : {}),
      }, { headers: { 'Idempotency-Key': request.key } })
      assertCurrent(generation)
      pending.delete(target.visitId); clearPendingRequestKey(scope)
    } catch (cause) {
      assertCurrent(generation)
      const status = (cause as { response?: { status: number } })?.response?.status
      // Definitive rejection permits editing. A lost response must retain its original payload.
      if (status && status >= 400 && status < 500) { pending.delete(target.visitId); clearPendingRequestKey(scope) }
      throw cause
    }
  }
  return { currentVisit, loading, error, drafts, load, submitSnapshot }
}
