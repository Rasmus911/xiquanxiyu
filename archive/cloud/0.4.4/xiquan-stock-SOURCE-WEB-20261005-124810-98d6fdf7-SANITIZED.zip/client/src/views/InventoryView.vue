<script setup lang="ts">
import { canCapability, useBusinessGuard } from '../business/state'
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { apiData, apiErrorMessage, http } from '../api/http'
import AppPageHeader from '../components/app/AppPageHeader.vue'
import { clearPendingRequestKey, pendingRequestKey } from '../domain/requests/pending-key'
import { previewStockQuantity } from '../domain/inventory/quantity'
import { pendingStockWrite } from '../domain/inventory/pending-write'
import { subscribeRealtime } from '../realtime/events'
import type { StockItem, StockMovement, StockUsage } from '../types'
import { formatBusinessTime } from '../format/business-time'
const guardBusinessOperation = useBusinessGuard()
const products=ref<StockItem[]>([]),movements=ref<StockMovement[]>([]),usage=ref<StockUsage[]>([])
const drawerOpen=ref(false),masterOpen=ref(false),editingId=ref(''),editingVersion=ref(0),saving=ref(false)
const keyword=ref(''),category=ref(''),includeInactive=ref(false),historyId=ref('')
const form=reactive({stock_item_id:'',version:0,movement_type:'purchase',quantity:'1',input_unit:'base',reason:''})
const masterForm=reactive({name:'',category:'默认',base_unit:'',package_unit:'',units_per_package:'1',package_spec:'',low_stock_threshold:'0',opening_quantity:'0',opening_unit:'base'})
let unsubscribeRealtime:(()=>void)|undefined
const pending = pendingStockWrite
const categories=computed(()=>[...new Set(products.value.map(row=>row.category))])
const filtered=computed(()=>products.value.filter(row=>(!category.value||row.category===category.value)&&(!keyword.value.trim()||row.name.includes(keyword.value.trim()))))
const summary=computed(()=>{
  const active=products.value.filter(row=>row.is_active),units:Record<string,number>={}
  for(const row of active)units[row.base_unit]=(units[row.base_unit]||0)+Number(row.stock_quantity)
  return {products:active.length,units,low:active.filter(row=>Number(row.stock_quantity)<=Number(row.low_stock_threshold)).length}
})
const selectedStock=computed(()=>products.value.find(row=>row.id===form.stock_item_id))
const openingPreview=computed(()=>previewStockQuantity(masterForm.opening_quantity,masterForm.opening_unit,masterForm.units_per_package,{zero:true}))
const adjustPreview=computed(()=>previewStockQuantity(form.quantity,form.input_unit,selectedStock.value?.units_per_package||'1',{signed:form.movement_type==='adjust'}))
const quantityRule='最多三位小数，绝对值须小于 1000000000，换算结果也须符合此规则'
const masterValidation=computed(()=>{
  if(previewStockQuantity(masterForm.units_per_package,'base','1')==='—')return `每包装数量须大于零，${quantityRule}`
  if(previewStockQuantity(masterForm.low_stock_threshold,'base','1',{zero:true})==='—')return `预警数量须为非负数，${quantityRule}`
  if(!editingId.value&&openingPreview.value==='—')return `期初数量须为非负数，${quantityRule}`
  if(!editingId.value&&masterForm.opening_unit==='package'&&!masterForm.package_unit.trim())return '请填写包装单位，或改用基本单位'
  return ''
})
const adjustValidation=computed(()=>{
  if(adjustPreview.value==='—')return `变动数量须为有效非零数（仅盘点允许负数），${quantityRule}`
  if(form.input_unit==='package'&&selectedStock.value&&!selectedStock.value.package_unit)return '该库存没有包装单位，请使用基本单位'
  return ''
})
const movementNames:Record<string,string>={purchase:'采购入库',opening:'期初库存',return:'退货入库',loss:'报损',adjust:'盘点调整（增减量）',sale:'销售出库',void_return:'撤销返库'}
async function load(silent=false){
  const current=guardBusinessOperation('load');if(!current())return
  try{
    const [stock,history,used]=await Promise.all([http.get('/inventory/stock-items',{params:{include_inactive:includeInactive.value}}),http.get('/inventory/stock-movements',{params:historyId.value?{stock_item_id:historyId.value}:{}}),http.get('/inventory/usage')])
    if(!current())return
    products.value=apiData<StockItem[]>(stock);movements.value=apiData<StockMovement[]>(history);usage.value=apiData<StockUsage[]>(used)
  }catch(error){if(current()&&!silent)ElMessage.error(apiErrorMessage(error))}
}
function createNew(){
  if(!canCapability('inventory_write')||saving.value)return
  editingId.value='';editingVersion.value=0
  Object.assign(masterForm,{name:'',category:'默认',base_unit:'',package_unit:'',units_per_package:'1',package_spec:'',low_stock_threshold:'0',opening_quantity:'0',opening_unit:'base'})
  masterOpen.value=true
}
function edit(row:StockItem){
  if(!canCapability('inventory_write')||saving.value)return
  editingId.value=row.id;editingVersion.value=row.version
  Object.assign(masterForm,{name:row.name,category:row.category,base_unit:row.base_unit,package_unit:row.package_unit,units_per_package:row.units_per_package,package_spec:row.package_spec,low_stock_threshold:row.low_stock_threshold,opening_quantity:'0',opening_unit:'base'})
  masterOpen.value=true
}
function adjust(row?:StockItem){
  if(!canCapability('inventory_write')||saving.value)return
  Object.assign(form,{stock_item_id:row?.id||'',version:row?.version||0,movement_type:'purchase',quantity:'1',input_unit:'base',reason:''});drawerOpen.value=true
}
watch(()=>form.stock_item_id,id=>{form.version=products.value.find(row=>row.id===id)?.version||0;form.input_unit='base'})
watch([includeInactive,historyId],()=>load())
async function write(scope:string,method:'post'|'patch'|'delete',url:string,body:Record<string,unknown>){
  if(!canCapability('inventory_write')||saving.value)return false
  const current=guardBusinessOperation('save');if(!current())return false
  const {version,...intent}=body,fingerprint=JSON.stringify(intent)
  if(pending.value&&(pending.value.scope!==scope||pending.value.fingerprint!==fingerprint)){ElMessage.warning('上一笔库存操作尚未确认，请先重试原操作');return false}
  const request=pending.value||{scope,fingerprint,body:{...body},key:pendingRequestKey(scope,JSON.stringify(body)),method,url}
  pending.value=request;saving.value=true
  try{
    await http.request({method:request.method,url:request.url,data:request.body,headers:{'Idempotency-Key':request.key}})
    if(!current())return false
    clearPendingRequestKey(scope,request.key);pending.value=undefined;ElMessage.success('库存更新成功');return true
  }catch(error){
    if(!current())return false
    const status=(error as {response?:{status:number}}).response?.status
    if(status&&status>=400&&status<500){clearPendingRequestKey(scope,request.key);pending.value=undefined}
    ElMessage.error(apiErrorMessage(error));return false
  }finally{if(current())saving.value=false}
}
async function retryPending(){
  const request=pending.value
  if(request&&await write(request.scope,request.method,request.url,request.body)){masterOpen.value=false;drawerOpen.value=false;await load()}
}
async function saveMaster(){
  if(!masterForm.name.trim()||!masterForm.base_unit.trim())return ElMessage.warning('请填写库存名称和基本单位')
  if(masterValidation.value)return ElMessage.warning(masterValidation.value)
  const {opening_quantity,opening_unit,...fields}=masterForm
  const body=editingId.value?{...fields,version:editingVersion.value}:{...fields,opening_unit,...(openingPreview.value!=='0.000'?{opening_quantity}:{})}
  if(await write(`stock:${editingId.value||'new'}:master`,editingId.value?'patch':'post',`/inventory/stock-items${editingId.value?'/'+editingId.value:''}`,body)){masterOpen.value=false;await load()}
}
async function save(){
  if(!selectedStock.value)return ElMessage.warning('请选择库存项目')
  if(!form.reason.trim())return ElMessage.warning('请填写调整原因或单据号')
  if(adjustValidation.value)return ElMessage.warning(adjustValidation.value)
  if(await write(`stock:${form.stock_item_id}:adjust`,'post','/inventory/stock-adjust',{...form,reason:form.reason.trim()})){drawerOpen.value=false;await load()}
}
async function archive(row:StockItem){
  if(!canCapability('inventory_write')||saving.value)return
  const current=guardBusinessOperation('archive'),body={version:row.version,confirm_writeoff:Number(row.stock_quantity)>0}
  try{await ElMessageBox.confirm(body.confirm_writeoff?`归档 ${row.name} 将报损剩余 ${row.stock_quantity} ${row.base_unit}，并保留流水。确定归档？`:`确定归档 ${row.name}？历史流水将保留。`,'归档库存',{type:'warning',confirmButtonText:'确认归档',cancelButtonText:'取消'})}catch{return}
  if(!current())return
  if(await write(`stock:${row.id}:archive`,'delete',`/inventory/stock-items/${row.id}`,body))await load()
}
onMounted(()=>{load();unsubscribeRealtime=subscribeRealtime(['inventory','catalog'],()=>load(true))})
onBeforeUnmount(()=>unsubscribeRealtime?.())
</script>
<template>
  <div class="page inventory-page">
    <AppPageHeader title="库存管理" description="库存独立管理；整箱入库换算为基本单位，下单逐行选择实际耗材。" eyebrow="INVENTORY"><template #actions><el-button v-if="canCapability('inventory_write') && pending" data-testid="stock-retry" :loading="saving" type="warning" @click="retryPending">重试待确认库存操作</el-button><el-button v-if="canCapability('inventory_write')" data-testid="stock-new" type="primary" @click="createNew">新增库存</el-button><el-button v-if="canCapability('inventory_write')" @click="adjust()">采购入库 / 调整</el-button></template></AppPageHeader>
    <section class="inventory-summary"><article><span>库存项目</span><strong>{{summary.products}}</strong><small>种</small></article><article><span>按基本单位结存</span><strong v-for="(quantity,unit) in summary.units" :key="unit">{{quantity.toFixed(3)}} {{unit}}</strong><small>不同单位分别统计</small></article><article :class="{warning:summary.low}"><span>低库存</span><strong>{{summary.low}}</strong><small>种需要关注</small></article></section>
    <div class="inventory-toolbar"><el-input v-model="keyword" clearable placeholder="搜索库存项目"/><el-select v-model="category" clearable placeholder="全部分类"><el-option v-for="name in categories" :key="name" :label="name" :value="name"/></el-select><el-checkbox v-if="canCapability('inventory_write')" v-model="includeInactive">包含已归档</el-checkbox></div>
    <el-row :gutter="18"><el-col :span="15"><el-card shadow="never"><template #header><strong>当前库存</strong></template><el-table :data="filtered">
      <el-table-column prop="name" label="库存项目" min-width="140"/><el-table-column prop="category" label="分类"/>
      <el-table-column label="结存 / 基本单位"><template #default="scope"><strong>{{scope.row.stock_quantity}} {{scope.row.base_unit}}</strong><small v-if="scope.row.legacy_catalog_item_id"> · 原销售单位</small></template></el-table-column>
      <el-table-column label="包装"><template #default="scope">{{scope.row.package_unit?`1 ${scope.row.package_unit} = ${scope.row.units_per_package} ${scope.row.base_unit}`:'—'}}<div class="muted">{{scope.row.package_spec}}</div></template></el-table-column>
      <el-table-column label="状态"><template #default="scope"><el-tag :type="!scope.row.is_active?'info':Number(scope.row.stock_quantity)<=Number(scope.row.low_stock_threshold)?'danger':'success'">{{!scope.row.is_active?'已归档':Number(scope.row.stock_quantity)<=Number(scope.row.low_stock_threshold)?'库存偏低':'充足'}}</el-tag></template></el-table-column>
      <el-table-column label="操作" width="170"><template #default="scope"><el-button link @click="historyId=scope.row.id">流水</el-button><template v-if="canCapability('inventory_write')&&scope.row.is_active"><el-button data-testid="stock-adjust" link type="primary" @click="adjust(scope.row)">入库</el-button><el-button data-testid="stock-edit" link type="primary" @click="edit(scope.row)">编辑</el-button><el-button data-testid="stock-archive" link type="danger" @click="archive(scope.row)">归档</el-button></template></template></el-table-column>
    </el-table></el-card><el-card shadow="never" style="margin-top:16px"><template #header><strong>各销售项目最常用耗材（并列保留）</strong></template><el-table :data="usage.filter(row=>row.is_most_used)"><el-table-column prop="catalog_name" label="销售项目"/><el-table-column prop="stock_name" label="耗材"/><el-table-column prop="usage_count" label="使用次数"/><el-table-column label="耗用总量"><template #default="scope">{{scope.row.total_quantity}} {{scope.row.base_unit}}</template></el-table-column></el-table></el-card></el-col>
      <el-col :span="9"><el-card shadow="never"><template #header><strong>库存流水</strong><el-button v-if="historyId" link @click="historyId=''">全部流水</el-button></template><el-timeline class="movement-list"><el-timeline-item v-for="row in movements" :key="row.id" :timestamp="formatBusinessTime(row.created_at)"><div class="movement"><strong>{{products.find(master=>master.id===row.stock_item_id)?.name||row.stock_item_id}} · {{movementNames[row.movement_type]||row.movement_type}}</strong><b>{{Number(row.quantity)>=0?'+':''}}{{row.quantity}} {{row.base_unit}}</b><span>结存 {{row.balance_after}} {{row.base_unit}} · {{row.reason}} · 输入 {{row.input_quantity}} {{row.input_unit==='package'?row.package_unit:row.base_unit}} × {{row.conversion_factor}}</span></div></el-timeline-item></el-timeline><el-empty v-if="!movements.length" description="暂无库存流水"/></el-card></el-col></el-row>
    <el-drawer v-model="masterOpen" :title="editingId?'编辑库存':'新增独立库存'" size="520px"><el-alert v-if="masterValidation" data-testid="stock-validation" :title="masterValidation" type="warning" :closable="false"/><el-form label-position="top"><el-form-item label="库存名称"><el-input v-model="masterForm.name"/></el-form-item><el-form-item label="分类"><el-input v-model="masterForm.category"/></el-form-item><el-form-item label="基本单位（已有流水后不能更改）"><el-input v-model="masterForm.base_unit" placeholder="袋、瓶等实际消耗单位"/></el-form-item><el-form-item label="包装单位"><el-input v-model="masterForm.package_unit" placeholder="箱、包（选填）"/></el-form-item><el-form-item label="每包装包含基本单位数量"><el-input v-model="masterForm.units_per_package" inputmode="decimal"/></el-form-item><el-form-item label="包装规格"><el-input v-model="masterForm.package_spec" placeholder="例如 1*200"/></el-form-item><el-form-item label="低库存预警（基本单位）"><el-input v-model="masterForm.low_stock_threshold" inputmode="decimal"/></el-form-item><template v-if="!editingId"><el-form-item label="期初数量（零表示只建库存项目）"><el-input v-model="masterForm.opening_quantity" inputmode="decimal"/></el-form-item><el-form-item label="期初输入单位"><el-select v-model="masterForm.opening_unit"><el-option :label="masterForm.base_unit||'基本单位'" value="base"/><el-option v-if="masterForm.package_unit" :label="masterForm.package_unit" value="package"/></el-select></el-form-item><p data-testid="opening-preview">换算结存 {{openingPreview}} {{masterForm.base_unit}}</p></template></el-form><template #footer><el-button @click="masterOpen=false">取消</el-button><el-button data-testid="stock-save" type="primary" :loading="saving" @click="saveMaster">保存库存</el-button></template></el-drawer>
    <el-drawer v-model="drawerOpen" title="库存入库 / 调整" size="480px"><el-alert v-if="adjustValidation" data-testid="adjust-validation" :title="adjustValidation" type="warning" :closable="false"/><el-form label-position="top"><el-form-item label="库存项目"><el-select v-model="form.stock_item_id" filterable class="full-width"><el-option v-for="row in products.filter(row=>row.is_active)" :key="row.id" :label="`${row.name}（${row.stock_quantity} ${row.base_unit}）`" :value="row.id"/></el-select></el-form-item><el-form-item label="操作类型"><el-select v-model="form.movement_type"><el-option v-for="kind in ['purchase','opening','return','loss','adjust']" :key="kind" :label="movementNames[kind]" :value="kind"/></el-select></el-form-item><el-form-item label="变动数量（盘点为有符号增减量）"><el-input v-model="form.quantity" inputmode="decimal"/></el-form-item><el-form-item label="输入单位"><el-select v-model="form.input_unit"><el-option :label="selectedStock?.base_unit||'基本单位'" value="base"/><el-option v-if="selectedStock?.package_unit" :label="selectedStock.package_unit" value="package"/></el-select></el-form-item><p data-testid="adjust-preview">换算变动 {{adjustPreview==='—'?'—':form.movement_type==='loss'?'-'+adjustPreview:adjustPreview}} {{selectedStock?.base_unit}}</p><el-form-item label="原因 / 单据号（必填）"><el-input v-model="form.reason"/></el-form-item></el-form><template #footer><el-button @click="drawerOpen=false">取消</el-button><el-button data-testid="adjust-save" type="primary" :loading="saving" @click="save">确认更新</el-button></template></el-drawer>
  </div>
</template>
<style scoped>
.inventory-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:13px;margin-bottom:16px}.inventory-summary article{padding:15px 18px;border:1px solid var(--xq-border);border-radius:var(--xq-radius-md);background:white;box-shadow:var(--xq-shadow-card)}.inventory-summary span,.inventory-summary strong,.inventory-summary small{display:block}.inventory-summary span{color:var(--xq-text-3);font-size:11px}.inventory-summary strong{margin-top:4px;color:var(--xq-text-1);font-size:24px}.inventory-summary small{color:var(--xq-text-3)}.inventory-summary .warning strong{color:var(--xq-danger)}.inventory-toolbar{display:flex;align-items:center;gap:9px;margin-bottom:14px}.inventory-toolbar .el-input{max-width:260px}.inventory-toolbar .el-select{width:170px}.movement-list{max-height:620px;overflow:auto}.movement{display:grid;grid-template-columns:1fr auto;gap:3px 8px}.movement span{grid-column:1/-1;color:var(--xq-text-3);font-size:10px}
</style>
