from sqlalchemy import inspect, text

from .extensions import db


def ensure_runtime_schema():
    """为直接运行 EXE 的现有 SQLite/PostgreSQL 数据库补充兼容字段。"""
    inspector = inspect(db.engine)
    if "visits" not in inspector.get_table_names():
        return
    columns = {column["name"] for column in inspector.get_columns("visits")}
    if "party_id" not in columns:
        db.session.execute(text("ALTER TABLE visits ADD COLUMN party_id VARCHAR(36)"))
        db.session.commit()
    db.session.execute(text("CREATE INDEX IF NOT EXISTS ix_visits_party_id ON visits (party_id)"))
    db.session.commit()

    inspector = inspect(db.engine)
    if "employees" in inspector.get_table_names():
        employee_columns = {column["name"] for column in inspector.get_columns("employees")}
        if "session_version" not in employee_columns:
            db.session.execute(
                text("ALTER TABLE employees ADD COLUMN session_version INTEGER NOT NULL DEFAULT 1")
            )
            db.session.commit()

    inspector = inspect(db.engine)
    if "catalog_items" not in inspector.get_table_names():
        return
    catalog_columns = {column["name"] for column in inspector.get_columns("catalog_items")}
    if "mobile_scope" not in catalog_columns:
        db.session.execute(
            text("ALTER TABLE catalog_items ADD COLUMN mobile_scope VARCHAR(20) NOT NULL DEFAULT 'frontdesk'")
        )
        db.session.execute(
            text(
                "UPDATE catalog_items SET mobile_scope = 'scrub' "
                "WHERE category IN ('搓澡助浴', '组合项目', '洗浴用品')"
            )
        )
        db.session.execute(
            text(
                "UPDATE catalog_items SET mobile_scope = 'rest' "
                "WHERE category IN ('理疗按摩', '饮品', '承德特色饮品', '食品')"
            )
        )
        db.session.commit()
