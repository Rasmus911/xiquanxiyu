import hashlib
from decimal import Decimal

from flask import Blueprint, request

from ..audit_service import write_audit
from ..auth_service import current_employee, require_permission
from ..extensions import db, socketio
from ..models import CatalogItem, IdempotencyRecord, OrderItem, Visit, Wristband
from ..serializers import catalog_dict, iso, order_item_dict, wristband_area
from .errors import ApiError, success
from .visits import _create_order_item, _load_visit, _quantity, _validate_catalog_quantity

bp = Blueprint("mobile", __name__, url_prefix="/mobile")

ROLE_POLICIES = {
    "admin": {
        "label": "系统管理员",
        "bath_areas": {"male", "female"},
        "catalog_scopes": {"frontdesk", "scrub", "rest", "both"},
    },
    "male_scrubber": {
        "label": "男浴搓澡师",
        "bath_areas": {"male"},
        "catalog_scopes": {"scrub", "both"},
    },
    "female_scrubber": {
        "label": "女浴搓澡师",
        "bath_areas": {"female"},
        "catalog_scopes": {"scrub", "both"},
    },
    "floor_attendant": {
        "label": "三层服务员",
        "bath_areas": {"male", "female"},
        "catalog_scopes": {"rest", "both"},
    },
}


def _policy(employee):
    policy = ROLE_POLICIES.get(employee.role)
    if not policy:
        raise ApiError("该账号不能登录手机点单端", 403, "MOBILE_ROLE_REQUIRED")
    return policy


def _active_visit_amounts(visit_ids):
    amounts = {visit_id: Decimal("0.00") for visit_id in visit_ids}
    if not visit_ids:
        return amounts
    rows = OrderItem.query.filter(
        OrderItem.visit_id.in_(visit_ids),
        OrderItem.status == "active",
    ).all()
    for row in rows:
        amounts[row.visit_id] += Decimal(row.total_amount)
    return amounts


@bp.get("/bootstrap")
@require_permission("mobile:order")
def bootstrap():
    employee = current_employee()
    policy = _policy(employee)
    visits = Visit.query.filter_by(status="open").order_by(Visit.opened_at).all()
    wristband_ids = [visit.wristband_id for visit in visits]
    wristbands = (
        Wristband.query.filter(
            Wristband.id.in_(wristband_ids),
            Wristband.status == "in_use",
        ).all()
        if wristband_ids
        else []
    )
    wristband_by_id = {row.id: row for row in wristbands}
    allowed_visits = [
        visit
        for visit in visits
        if visit.wristband_id in wristband_by_id
        and wristband_area(wristband_by_id[visit.wristband_id].number) in policy["bath_areas"]
    ]
    amounts = _active_visit_amounts([visit.id for visit in allowed_visits])
    bands = [
        {
            "number": wristband_by_id[visit.wristband_id].number,
            "bath_area": wristband_area(wristband_by_id[visit.wristband_id].number),
            "visit_id": visit.id,
            "opened_at": iso(visit.opened_at),
            "amount": f"{amounts[visit.id]:.2f}",
        }
        for visit in allowed_visits
    ]
    bands.sort(key=lambda row: row["number"])

    catalog = (
        CatalogItem.query.filter(
            CatalogItem.is_active.is_(True),
            CatalogItem.kind.in_(["service", "product"]),
            CatalogItem.mobile_scope.in_(policy["catalog_scopes"]),
        )
        .order_by(CatalogItem.kind, CatalogItem.sort_order, CatalogItem.name)
        .all()
    )
    return success(
        {
            "employee": {
                "id": employee.id,
                "username": employee.username,
                "display_name": employee.display_name,
                "role": employee.role,
                "role_label": policy["label"],
            },
            "wristbands": bands,
            "catalog": [catalog_dict(row) for row in catalog],
        }
    )


@bp.post("/visits/<visit_id>/items")
@require_permission("mobile:order")
def create_order(visit_id):
    employee = current_employee()
    policy = _policy(employee)
    raw_key = str(request.headers.get("Idempotency-Key", "")).strip()
    if not raw_key:
        raise ApiError("缺少幂等请求编号", 400, "IDEMPOTENCY_REQUIRED")
    record_key = hashlib.sha256(
        f"mobile-order:{employee.id}:{visit_id}:{raw_key}".encode("utf-8")
    ).hexdigest()
    existing = db.session.get(IdempotencyRecord, record_key)
    if existing:
        return success(existing.response_body["items"], "已返回原点单结果")
    body = request.get_json(silent=True) or {}
    requested_items = body.get("items")
    if not isinstance(requested_items, list) or not requested_items:
        raise ApiError("请选择至少一个项目")
    if len(requested_items) > 50:
        raise ApiError("一次最多可添加 50 个项目")

    normalized = []
    for row in requested_items:
        if not isinstance(row, dict) or not row.get("catalog_item_id"):
            raise ApiError("点单项目格式错误")
        normalized.append(
            {
                "catalog_item_id": str(row["catalog_item_id"]),
                "quantity": _quantity(row.get("quantity", 1)),
            }
        )

    visit = _load_visit(visit_id, lock=True)
    if visit.status != "open":
        raise ApiError("当前手牌不能加项", 409, "VISIT_NOT_OPEN")
    wristband = Wristband.query.with_for_update().filter_by(id=visit.wristband_id).first()
    if not wristband or wristband.status != "in_use":
        raise ApiError("当前手牌未激活", 409, "WRISTBAND_NOT_ACTIVE")
    if wristband_area(wristband.number) not in policy["bath_areas"]:
        raise ApiError("不能给其他区域的手牌点单", 403, "WRISTBAND_AREA_FORBIDDEN")

    catalog_ids = sorted({row["catalog_item_id"] for row in normalized})
    catalogs = (
        CatalogItem.query.with_for_update()
        .filter(CatalogItem.id.in_(catalog_ids), CatalogItem.is_active.is_(True))
        .all()
    )
    catalog_by_id = {row.id: row for row in catalogs}
    if len(catalog_by_id) != len(catalog_ids):
        raise ApiError("部分项目不存在或已停用", 404, "ITEM_NOT_AVAILABLE")

    required_stock = {}
    for row in normalized:
        catalog = catalog_by_id[row["catalog_item_id"]]
        if catalog.kind not in {"service", "product"}:
            raise ApiError("该项目不能在手机端销售", 403, "CATALOG_FORBIDDEN")
        if catalog.mobile_scope not in policy["catalog_scopes"]:
            raise ApiError("该账号没有销售此项目的权限", 403, "CATALOG_FORBIDDEN")
        _validate_catalog_quantity(catalog, row["quantity"])
        if catalog.kind == "product" and catalog.stock_tracked:
            required_stock[catalog.id] = required_stock.get(catalog.id, Decimal("0")) + row["quantity"]
    for catalog_id, quantity in required_stock.items():
        catalog = catalog_by_id[catalog_id]
        if Decimal(catalog.stock_quantity) < quantity:
            raise ApiError(f"商品库存不足：{catalog.name}", 409, "INSUFFICIENT_STOCK")

    items = [
        _create_order_item(
            visit,
            catalog_by_id[row["catalog_item_id"]],
            row["quantity"],
            employee,
            employee.id if catalog_by_id[row["catalog_item_id"]].kind == "service" else None,
        )
        for row in normalized
    ]
    visit.version += 1
    payload = [order_item_dict(item) for item in items]
    write_audit(
        "mobile.order_create",
        "visit",
        visit.id,
        {
            "wristband_number": wristband.number,
            "role": employee.role,
            "items": payload,
        },
    )
    db.session.add(
        IdempotencyRecord(
            key=record_key,
            endpoint=f"/api/mobile/visits/{visit_id}/items",
            response_status=201,
            response_body={"items": payload},
        )
    )
    db.session.commit()
    socketio.emit("visit.changed", {"visit_id": visit.id, "source": "mobile"})
    if required_stock:
        socketio.emit("inventory.changed", {"reason": "mobile_sale"})
    return success(payload, f"手牌 {wristband.number} 点单成功", 201)
