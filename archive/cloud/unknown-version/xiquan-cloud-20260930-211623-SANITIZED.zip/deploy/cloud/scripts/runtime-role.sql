-- Run against the bathhouse database as its owner after the security migration.
-- This does not set or print a password. Set it with psql \password xiquan_app.
BEGIN;
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='xiquan_app') THEN
        IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='xiquan_app'
                   AND (rolsuper OR rolcreaterole OR rolcreatedb OR rolbypassrls)) THEN
            RAISE EXCEPTION 'Existing xiquan_app is privileged. Choose a dedicated runtime role.';
        END IF;
    ELSE
        CREATE ROLE xiquan_app NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS;
    END IF;
END $$;
GRANT USAGE ON SCHEMA public TO xiquan_app;
REVOKE CREATE ON SCHEMA public FROM PUBLIC, xiquan_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO xiquan_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO xiquan_app;
REVOKE UPDATE, DELETE, TRUNCATE ON audit_logs, payments, stored_value_ledgers,
    pass_ledgers, inventory_movements, settlement_visits, revoked_sessions,
    idempotency_records FROM xiquan_app;
REVOKE DELETE, TRUNCATE ON settlements FROM xiquan_app;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON alembic_version FROM xiquan_app;
COMMIT;
