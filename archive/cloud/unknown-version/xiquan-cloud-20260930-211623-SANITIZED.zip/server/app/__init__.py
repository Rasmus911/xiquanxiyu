import logging
import re
import uuid
from pathlib import Path

from flask import Flask, g, request
from flask_jwt_extended import decode_token
from flask_socketio import join_room
from sqlalchemy import text
from werkzeug.middleware.proxy_fix import ProxyFix

from .api import BLUEPRINTS
from .api.errors import register_error_handlers
from .config import Config
from .extensions import cors, db, jwt, migrate, socketio


def create_app(config_object=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object or Config)
    if app.config.get("PRODUCTION"):
        for key in ("SECRET_KEY", "JWT_SECRET_KEY"):
            value = str(app.config.get(key, ""))
            if len(value) < 32 or value.startswith("dev-only-"):
                raise RuntimeError(f"Production requires a strong {key} of at least 32 characters")
        if app.config.get("AUDIT_HMAC_KEY") and len(app.config["AUDIT_HMAC_KEY"]) < 32:
            raise RuntimeError("Production AUDIT_HMAC_KEY must contain at least 32 characters")
    if app.config.get("TRUST_PROXY_HEADERS"):
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)
    app.config["CORS_ORIGINS"] = list(dict.fromkeys([*app.config["CORS_ORIGINS"], "https://localhost"]))
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})
    socketio.init_app(
        app,
        cors_allowed_origins=app.config["CORS_ORIGINS"],
        async_mode=app.config.get("SOCKETIO_ASYNC_MODE"),
    )

    for blueprint in BLUEPRINTS:
        app.register_blueprint(blueprint, url_prefix=f"/api{blueprint.url_prefix or ''}")

    @app.before_request
    def attach_request_context():
        supplied = request.headers.get("X-Request-ID", "")
        g.request_id = supplied if re.fullmatch(r"[A-Za-z0-9._:-]{1,80}", supplied) else str(uuid.uuid4())
        if request.path.startswith("/api/") and request.is_json:
            body = request.get_json(silent=True)
            if body is not None and not isinstance(body, dict):
                from .api.errors import ApiError

                raise ApiError("请求内容必须是 JSON 对象", 400, "INVALID_BODY")

    from .audit_service import record_rejected_request

    app.after_request(record_rejected_request)

    @app.after_request
    def append_request_id(response):
        response.headers["X-Request-ID"] = getattr(g, "request_id", "")
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    @app.get("/api/health")
    def health():
        db.session.execute(text("SELECT 1"))
        return {
            "success": True,
            "message": "服务正常",
            "data": {"api": "ok", "database": "ok"},
            "request_id": g.request_id,
        }

    register_error_handlers(app)

    logging.basicConfig(
        level=logging.DEBUG if app.config.get("DEBUG") else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    @socketio.on("connect")
    def socket_connect(auth):
        token = (auth or {}).get("token")
        if not token:
            return False
        try:
            payload = decode_token(token)
            employee_id = payload.get("sub")
            terminal_id = payload.get("terminal_id")
            from .auth_service import session_expired
            from .models import Employee, RevokedSession, Terminal

            employee = db.session.get(Employee, employee_id)
            terminal = db.session.get(Terminal, terminal_id)
            session_version = int(payload.get("session_version", 0))
            if (
                not employee
                or not employee.is_active
                or employee.session_version != session_version
                or not terminal
                or not terminal.is_active
                or payload.get("type") != "access"
                or session_expired(payload)
                or (payload.get("session_id") and db.session.get(RevokedSession, payload["session_id"]))
            ):
                return False
            join_room("store:default")
            join_room(f"terminal:{terminal.id}")
        except Exception:
            return False

    with app.app_context():
        if app.config.get("AUTO_CREATE_DB"):
            db.create_all()
            from .schema_maintenance import ensure_runtime_schema
            from .seed import seed_defaults

            ensure_runtime_schema()
            seed_defaults()

    return app
