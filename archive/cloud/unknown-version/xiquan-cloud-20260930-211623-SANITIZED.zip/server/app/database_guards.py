APPEND_ONLY_TABLES = (
    "audit_logs",
    "payments",
    "stored_value_ledgers",
    "pass_ledgers",
    "inventory_movements",
    "settlement_visits",
    "revoked_sessions",
    "idempotency_records",
)


def install_database_guards(connection):
    dialect = connection.dialect.name
    if dialect == "sqlite":
        for table in APPEND_ONLY_TABLES:
            for operation in ("UPDATE", "DELETE"):
                connection.exec_driver_sql(f"""
                    CREATE TRIGGER IF NOT EXISTS protect_{table}_{operation.lower()}
                    BEFORE {operation} ON {table}
                    BEGIN SELECT RAISE(ABORT, 'immutable financial or audit record'); END
                """)
        for operation in ("UPDATE", "DELETE"):
            new_visit_guard = (
                "OR EXISTS (SELECT 1 FROM settlement_visits WHERE visit_id = NEW.visit_id)"
                if operation == "UPDATE"
                else ""
            )
            connection.exec_driver_sql(f"DROP TRIGGER IF EXISTS protect_settled_order_{operation.lower()}")
            connection.exec_driver_sql(f"""
                CREATE TRIGGER IF NOT EXISTS protect_settled_order_{operation.lower()}
                BEFORE {operation} ON order_items
                WHEN EXISTS (SELECT 1 FROM settlement_visits WHERE visit_id = OLD.visit_id)
                  {new_visit_guard}
                BEGIN SELECT RAISE(ABORT, 'settled order is immutable'); END
            """)
        connection.exec_driver_sql("""
            CREATE TRIGGER IF NOT EXISTS protect_settled_order_insert
            BEFORE INSERT ON order_items
            WHEN EXISTS (SELECT 1 FROM settlement_visits WHERE visit_id = NEW.visit_id)
            BEGIN SELECT RAISE(ABORT, 'settled order is immutable'); END
        """)
        connection.exec_driver_sql("""
            CREATE TRIGGER IF NOT EXISTS protect_settlement_update BEFORE UPDATE ON settlements
            WHEN OLD.id IS NOT NEW.id OR OLD.created_at IS NOT NEW.created_at
              OR OLD.shift_id IS NOT NEW.shift_id OR OLD.number IS NOT NEW.number
              OR OLD.total_amount IS NOT NEW.total_amount
              OR OLD.paid_amount IS NOT NEW.paid_amount OR OLD.created_by_id IS NOT NEW.created_by_id
              OR OLD.terminal_id IS NOT NEW.terminal_id OR OLD.member_id IS NOT NEW.member_id
              OR OLD.idempotency_key IS NOT NEW.idempotency_key OR OLD.completed_at IS NOT NEW.completed_at
              OR NOT (NEW.status = OLD.status OR (OLD.status = 'completed' AND NEW.status = 'refunded'))
            BEGIN SELECT RAISE(ABORT, 'settlement financial fields are immutable'); END
        """)
        connection.exec_driver_sql("""
            CREATE TRIGGER IF NOT EXISTS protect_settlement_delete BEFORE DELETE ON settlements
            BEGIN SELECT RAISE(ABORT, 'settlement is immutable'); END
        """)
    elif dialect == "postgresql":
        connection.exec_driver_sql("""
            CREATE OR REPLACE FUNCTION public.xiquan_append_only() RETURNS trigger LANGUAGE plpgsql
            SET search_path = pg_catalog, public, pg_temp AS $$
            BEGIN RAISE EXCEPTION 'immutable financial or audit record'; END; $$
        """)
        for table in (*APPEND_ONLY_TABLES, "settlements"):
            operations = "DELETE OR TRUNCATE" if table == "settlements" else "UPDATE OR DELETE OR TRUNCATE"
            connection.exec_driver_sql(f"DROP TRIGGER IF EXISTS xiquan_immutable ON {table}")
            connection.exec_driver_sql(f"""
                CREATE TRIGGER xiquan_immutable BEFORE {operations} ON {table}
                FOR EACH STATEMENT EXECUTE FUNCTION public.xiquan_append_only()
            """)
        connection.exec_driver_sql("""
            CREATE OR REPLACE FUNCTION public.xiquan_settled_order_guard() RETURNS trigger LANGUAGE plpgsql
            SET search_path = pg_catalog, public, pg_temp AS $$
            BEGIN
                IF TG_OP <> 'INSERT' AND EXISTS (
                    SELECT 1 FROM public.settlement_visits WHERE visit_id = OLD.visit_id
                ) THEN
                    RAISE EXCEPTION 'settled order is immutable';
                END IF;
                IF TG_OP <> 'DELETE' AND EXISTS (
                    SELECT 1 FROM public.settlement_visits WHERE visit_id = NEW.visit_id
                ) THEN
                    RAISE EXCEPTION 'settled order is immutable';
                END IF;
                IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
                RETURN NEW;
            END; $$
        """)
        connection.exec_driver_sql("DROP TRIGGER IF EXISTS xiquan_settled_order ON order_items")
        connection.exec_driver_sql("""
            CREATE TRIGGER xiquan_settled_order BEFORE INSERT OR UPDATE OR DELETE ON order_items
            FOR EACH ROW EXECUTE FUNCTION public.xiquan_settled_order_guard()
        """)
        connection.exec_driver_sql("""
            CREATE OR REPLACE FUNCTION public.xiquan_settlement_guard() RETURNS trigger LANGUAGE plpgsql
            SET search_path = pg_catalog, public, pg_temp AS $$
            BEGIN
                IF ROW(OLD.id, OLD.created_at, OLD.shift_id, OLD.number, OLD.total_amount,
                       OLD.paid_amount, OLD.created_by_id, OLD.terminal_id,
                       OLD.member_id, OLD.idempotency_key, OLD.completed_at)
                   IS DISTINCT FROM
                   ROW(NEW.id, NEW.created_at, NEW.shift_id, NEW.number, NEW.total_amount,
                       NEW.paid_amount, NEW.created_by_id, NEW.terminal_id,
                       NEW.member_id, NEW.idempotency_key, NEW.completed_at)
                   OR NOT (NEW.status = OLD.status OR (OLD.status = 'completed' AND NEW.status = 'refunded')) THEN
                    RAISE EXCEPTION 'settlement financial fields are immutable';
                END IF;
                RETURN NEW;
            END; $$
        """)
        connection.exec_driver_sql("DROP TRIGGER IF EXISTS xiquan_settlement_update ON settlements")
        connection.exec_driver_sql("""
            CREATE TRIGGER xiquan_settlement_update BEFORE UPDATE ON settlements
            FOR EACH ROW EXECUTE FUNCTION public.xiquan_settlement_guard()
        """)
        connection.exec_driver_sql("DROP TRIGGER IF EXISTS xiquan_no_truncate ON order_items")
        connection.exec_driver_sql("""
            CREATE TRIGGER xiquan_no_truncate BEFORE TRUNCATE ON order_items
            FOR EACH STATEMENT EXECUTE FUNCTION public.xiquan_append_only()
        """)


def remove_database_guards(connection):
    if connection.dialect.name == "sqlite":
        for table in APPEND_ONLY_TABLES:
            for operation in ("update", "delete"):
                connection.exec_driver_sql(f"DROP TRIGGER IF EXISTS protect_{table}_{operation}")
        for operation in ("insert", "update", "delete"):
            connection.exec_driver_sql(f"DROP TRIGGER IF EXISTS protect_settled_order_{operation}")
            connection.exec_driver_sql(f"DROP TRIGGER IF EXISTS protect_settlement_{operation}")
    elif connection.dialect.name == "postgresql":
        for table in (*APPEND_ONLY_TABLES, "settlements"):
            connection.exec_driver_sql(f"DROP TRIGGER IF EXISTS xiquan_immutable ON {table}")
        connection.exec_driver_sql("DROP TRIGGER IF EXISTS xiquan_settled_order ON order_items")
        connection.exec_driver_sql("DROP TRIGGER IF EXISTS xiquan_settlement_update ON settlements")
        connection.exec_driver_sql("DROP TRIGGER IF EXISTS xiquan_no_truncate ON order_items")
