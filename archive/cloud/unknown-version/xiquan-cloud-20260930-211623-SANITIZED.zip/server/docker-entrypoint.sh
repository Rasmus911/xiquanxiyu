#!/usr/bin/env sh
set -eu

if [ "${RUN_MIGRATIONS:-1}" = "1" ]; then
  echo "[xiquan] 正在执行数据库迁移..."
  flask --app run.py db upgrade
fi

if [ "${SEED_DEFAULTS:-1}" = "1" ]; then
  echo "[xiquan] 正在检查默认手牌、服务和商品数据..."
  python -c "from app import create_app; from app.seed import seed_defaults; application = create_app(); context = application.app_context(); context.push(); seed_defaults(); context.pop()"
fi

if [ -n "${RUNTIME_DATABASE_URL:-}" ]; then
  # Schema migration/seed uses the owner; normal API requests use a non-owner role.
  export DATABASE_URL="$RUNTIME_DATABASE_URL"
  python -c "from app import create_app; from app.extensions import db; from sqlalchemy import text; a=create_app(); c=a.app_context(); c.push(); r=db.session.execute(text('SELECT rolsuper FROM pg_roles WHERE rolname=current_user')).scalar(); assert r is False, 'Runtime DB role must not be superuser'; c.pop()"
  python -c "from app import create_app; from app.extensions import db; from sqlalchemy import text; a=create_app(); c=a.app_context(); c.push(); r=db.session.execute(text(\"SELECT count(*) FROM pg_tables WHERE schemaname='public' AND pg_has_role(current_user, tableowner, 'MEMBER')\")).scalar(); assert r == 0, 'Runtime DB role must not own or inherit ownership of application tables'; c.pop()"
fi

echo "[xiquan] 正在启动 API 服务..."
exec "$@"

