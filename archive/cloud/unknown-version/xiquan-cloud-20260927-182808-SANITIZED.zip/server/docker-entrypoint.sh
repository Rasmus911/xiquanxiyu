#!/usr/bin/env sh
set -eu

if [ "${RUN_MIGRATIONS:-1}" = "1" ]; then
  echo "[xiquan] 正在执行数据库迁移..."
  flask --app run.py db upgrade
fi

if [ "${SEED_DEFAULTS:-1}" = "1" ]; then
  echo "[xiquan] 正在检查默认手牌、服务和商品数据..."
  python -c "from app import create_app; from app.seed import seed_defaults; application = create_app(); context = application.app_context(); context.push(); seed_defaults(); context.pop()"
fi

echo "[xiquan] 正在启动 API 服务..."
exec "$@"

