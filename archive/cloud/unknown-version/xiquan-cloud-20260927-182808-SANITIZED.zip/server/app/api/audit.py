from flask import Blueprint, request

from ..audit_service import verify_audit_chain
from ..auth_service import require_permission
from ..extensions import db
from ..models import AuditLog, Employee, Terminal
from ..serializers import ACTION_LABELS, audit_dict
from .errors import success

bp = Blueprint("audit", __name__, url_prefix="/audit")


@bp.get("")
@require_permission("audit:read")
def list_audit():
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", 30)), 1), 100)
    query = AuditLog.query
    if request.args.get("action"):
        action_keyword = request.args["action"].strip()
        matching_actions = [code for code, label in ACTION_LABELS.items() if action_keyword in label]
        query = query.filter(
            db.or_(AuditLog.action.ilike(f"%{action_keyword}%"), AuditLog.action.in_(matching_actions))
        )
    if request.args.get("employee"):
        employee_keyword = request.args["employee"].strip()
        query = query.join(Employee, AuditLog.employee_id == Employee.id).filter(
            Employee.username.ilike(f"%{employee_keyword}%")
        )
    result = query.order_by(AuditLog.chain_index.desc()).paginate(page=page, per_page=page_size, error_out=False)
    employee_ids = {row.employee_id for row in result.items if row.employee_id}
    terminal_ids = {row.terminal_id for row in result.items if row.terminal_id}
    employees = (
        {row.id: row for row in Employee.query.filter(Employee.id.in_(employee_ids)).all()} if employee_ids else {}
    )
    terminals = (
        {row.id: row for row in Terminal.query.filter(Terminal.id.in_(terminal_ids)).all()} if terminal_ids else {}
    )
    return success(
        {
            "items": [
                audit_dict(row, employees.get(row.employee_id), terminals.get(row.terminal_id)) for row in result.items
            ],
            "total": result.total,
            "page": page,
            "page_size": page_size,
        }
    )


@bp.get("/verify")
@require_permission("audit:read")
def verify_chain():
    valid, broken_at = verify_audit_chain()
    return success({"valid": valid, "broken_at": broken_at})
