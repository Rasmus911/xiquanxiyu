import hmac
from datetime import datetime, timedelta, timezone

from flask import Blueprint, current_app, request
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
)

from ..audit_service import write_audit
from ..auth_service import current_employee, hash_password, verify_password
from ..extensions import db
from ..models import Employee, Terminal
from ..serializers import employee_dict, terminal_dict
from .errors import ApiError, success

bp = Blueprint("auth", __name__, url_prefix="/auth")


def _locked(employee: Employee) -> bool:
    if not employee.locked_until:
        return False
    locked_until = employee.locked_until
    if locked_until.tzinfo is None:
        locked_until = locked_until.replace(tzinfo=timezone.utc)
    return locked_until > datetime.now(timezone.utc)


@bp.post("/bootstrap")
def bootstrap():
    if Employee.query.count() > 0:
        raise ApiError("系统已经初始化", 409, "ALREADY_BOOTSTRAPPED")
    body = request.get_json(silent=True) or {}
    expected_token = str(current_app.config.get("BOOTSTRAP_TOKEN", ""))
    provided_token = str(body.get("bootstrap_token", ""))
    if expected_token and not hmac.compare_digest(provided_token, expected_token):
        raise ApiError("首次初始化口令错误", 403, "INVALID_BOOTSTRAP_TOKEN")
    username = str(body.get("username", "admin")).strip()
    display_name = str(body.get("display_name", "系统管理员")).strip()
    password = str(body.get("password", ""))
    if not username or not display_name:
        raise ApiError("用户名和姓名不能为空")

    employee = Employee(
        username=username,
        display_name=display_name,
        password_hash=hash_password(password),
        role="admin",
    )
    db.session.add(employee)
    db.session.flush()
    write_audit(
        "system.bootstrap",
        "employee",
        employee.id,
        {"username": username, "display_name": display_name},
        employee_id=employee.id,
    )
    db.session.commit()
    return success(employee_dict(employee), "初始化完成", 201)


@bp.post("/login")
def login():
    body = request.get_json(silent=True) or {}
    username = str(body.get("username", "")).strip()
    password = str(body.get("password", ""))
    terminal_code = str(body.get("terminal_code", "")).strip()
    employee = Employee.query.filter_by(username=username).first()
    if not employee or not employee.is_active:
        raise ApiError("用户名或密码错误", 401, "INVALID_CREDENTIALS")
    if _locked(employee):
        raise ApiError("账号已锁定，请稍后重试", 423, "ACCOUNT_LOCKED")
    if not verify_password(employee.password_hash, password):
        employee.failed_login_attempts += 1
        if employee.failed_login_attempts >= 5:
            employee.locked_until = datetime.now(timezone.utc) + timedelta(minutes=15)
            employee.failed_login_attempts = 0
        db.session.commit()
        raise ApiError("用户名或密码错误", 401, "INVALID_CREDENTIALS")

    terminal = Terminal.query.filter_by(code=terminal_code, is_active=True).first()
    if not terminal:
        raise ApiError("终端未注册或已停用", 403, "TERMINAL_INVALID")

    employee.failed_login_attempts = 0
    employee.locked_until = None
    employee.last_login_at = datetime.now(timezone.utc)
    terminal.last_seen_at = datetime.now(timezone.utc)
    claims = {
        "role": employee.role,
        "terminal_id": terminal.id,
        "session_version": employee.session_version,
    }
    access_token = create_access_token(identity=employee.id, additional_claims=claims)
    refresh_expires = timedelta(days=7) if terminal.code.startswith("MOBILE-") else None
    refresh_token = create_refresh_token(
        identity=employee.id,
        additional_claims=claims,
        expires_delta=refresh_expires,
    )
    write_audit(
        "auth.login",
        "employee",
        employee.id,
        {"terminal_code": terminal.code},
        employee_id=employee.id,
        terminal_id=terminal.id,
    )
    db.session.commit()
    return success(
        {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "employee": employee_dict(employee),
            "terminal": terminal_dict(terminal),
        },
        "登录成功",
    )


@bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    employee = current_employee()
    from flask_jwt_extended import get_jwt

    old_claims = get_jwt()
    claims = {
        "role": employee.role,
        "terminal_id": old_claims.get("terminal_id"),
        "session_version": employee.session_version,
    }
    return success({"access_token": create_access_token(identity=employee.id, additional_claims=claims)})


@bp.get("/me")
@jwt_required()
def me():
    employee = current_employee()
    return success(employee_dict(employee))


@bp.post("/logout")
@jwt_required()
def logout():
    employee = current_employee()
    write_audit("auth.logout", "employee", employee.id, {})
    db.session.commit()
    return success(message="已退出登录")
