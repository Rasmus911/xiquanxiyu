import logging
import uuid
from pathlib import Path

from flask import Flask, g, request
from flask_jwt_extended import decode_token
from flask_socketio import join_room
from sqlalchemy import text

from .api import BLUEPRINTS
from .api.errors import register_error_handlers
from .config import Config
from .extensions import cors, db, jwt, migrate, socketio


def create_app(config_object=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object or Config)
    app.config["CORS_ORIGINS"] = list(
        dict.fromkeys([*app.config["CORS_ORIGINS"], "https://localhost"])
    )
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)

    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": app.config["CORS_ORIGINS"]}})
    socketio.init_app(
        app,
        cors_allowed_origins=app.config["CORS_ORIGINS"],
        async_mode=app.config.get("SOCKETIO_ASYNC_MODE"),
    )

    for blueprint in BLUEPRINTS:
        app.register_blueprint(blueprint, url_prefix=f"/api{blueprint.url_prefix or ''}")

    @app.before_request
    def attach_request_context():
        g.request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())

    @app.after_request
    def append_request_id(response):
        response.headers["X-Request-ID"] = getattr(g, "request_id", "")
        return response

    @app.get("/api/health")
    def health():
        db.session.execute(text("SELECT 1"))
        return {
            "success": True,
            "message": "服务正常",
            "data": {"api": "ok", "database": "ok"},
            "request_id": g.request_id,
        }

    register_error_handlers(app)

    logging.basicConfig(
        level=logging.DEBUG if app.config.get("DEBUG") else logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    @socketio.on("connect")
    def socket_connect(auth):
        token = (auth or {}).get("token")
        if not token:
            return False
        try:
            payload = decode_token(token)
            employee_id = payload.get("sub")
            terminal_id = payload.get("terminal_id")
            from .models import Employee, Terminal

            employee = db.session.get(Employee, employee_id)
            terminal = db.session.get(Terminal, terminal_id)
            session_version = int(payload.get("session_version", 0))
            if (
                not employee
                or not employee.is_active
                or employee.session_version != session_version
                or not terminal
                or not terminal.is_active
            ):
                return False
            join_room("store:default")
            join_room(f"terminal:{terminal.id}")
        except Exception:
            return False

    with app.app_context():
        if app.config.get("AUTO_CREATE_DB"):
            db.create_all()
            from .schema_maintenance import ensure_runtime_schema
            from .seed import seed_defaults

            ensure_runtime_schema()
            seed_defaults()

    return app
