import hashlib
import json

from flask import g
from flask_jwt_extended import get_jwt

from .extensions import db
from .models import AuditLog


def _canonical_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def write_audit(
    action: str,
    entity_type: str,
    entity_id: str | None,
    details: dict,
    employee_id: str | None = None,
    terminal_id: str | None = None,
) -> AuditLog:
    claims = {}
    try:
        claims = get_jwt()
    except Exception:
        pass

    last = AuditLog.query.order_by(AuditLog.chain_index.desc()).with_for_update().first()
    chain_index = 1 if last is None else last.chain_index + 1
    prev_hash = "0" * 64 if last is None else last.current_hash
    payload = {
        "chain_index": chain_index,
        "employee_id": employee_id or claims.get("sub"),
        "terminal_id": terminal_id or claims.get("terminal_id"),
        "action": action,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "details": details,
        "request_id": getattr(g, "request_id", None),
        "prev_hash": prev_hash,
    }
    current_hash = hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()
    record = AuditLog(current_hash=current_hash, **payload)
    db.session.add(record)
    return record


def verify_audit_chain() -> tuple[bool, int | None]:
    previous_hash = "0" * 64
    expected_index = 1
    for item in AuditLog.query.order_by(AuditLog.chain_index.asc()).all():
        payload = {
            "chain_index": item.chain_index,
            "employee_id": item.employee_id,
            "terminal_id": item.terminal_id,
            "action": item.action,
            "entity_type": item.entity_type,
            "entity_id": item.entity_id,
            "details": item.details,
            "request_id": item.request_id,
            "prev_hash": item.prev_hash,
        }
        actual = hashlib.sha256(_canonical_json(payload).encode("utf-8")).hexdigest()
        if item.chain_index != expected_index or item.prev_hash != previous_hash or item.current_hash != actual:
            return False, item.chain_index
        previous_hash = item.current_hash
        expected_index += 1
    return True, None
