from datetime import datetime, timezone
from functools import wraps

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from flask_jwt_extended import get_jwt, get_jwt_identity, verify_jwt_in_request

from .api.errors import ApiError
from .extensions import db
from .models import Employee, Terminal

password_hasher = PasswordHasher()

ROLE_PERMISSIONS = {
    "male_scrubber": {"mobile:order"},
    "female_scrubber": {"mobile:order"},
    "floor_attendant": {"mobile:order"},
    "cashier": {
        "visit:read",
        "visit:write",
        "checkout:write",
        "member:read",
        "member:write",
        "print:write",
    },
    "inventory": {"inventory:read", "inventory:write", "catalog:read", "settings:read"},
    "manager": {
        "visit:read",
        "visit:write",
        "checkout:write",
        "checkout:refund",
        "member:read",
        "member:write",
        "inventory:read",
        "inventory:write",
        "catalog:read",
        "catalog:write",
        "report:read",
        "audit:read",
        "employee:read",
        "settings:read",
        "print:write",
    },
    "admin": {"*"},
}


def hash_password(password: str) -> str:
    if len(password) < 6:
        raise ApiError("密码至少需要 6 位", code="WEAK_PASSWORD")
    return password_hasher.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    try:
        return password_hasher.verify(password_hash, password)
    except VerifyMismatchError:
        return False


def current_employee() -> Employee:
    employee_id = get_jwt_identity()
    employee = db.session.get(Employee, employee_id)
    if not employee or not employee.is_active:
        raise ApiError("账号不可用，请重新登录", 401, "ACCOUNT_DISABLED")
    if employee.locked_until and employee.locked_until > datetime.now(timezone.utc):
        raise ApiError("账号已锁定", 423, "ACCOUNT_LOCKED")
    claims = get_jwt()
    if int(claims.get("session_version", 0)) != employee.session_version:
        raise ApiError("登录状态已失效，请重新登录", 401, "SESSION_REVOKED")
    terminal = db.session.get(Terminal, claims.get("terminal_id"))
    if not terminal or not terminal.is_active:
        raise ApiError("终端已停用，请联系管理员", 401, "TERMINAL_DISABLED")
    return employee


def has_permission(employee: Employee, permission: str) -> bool:
    permissions = ROLE_PERMISSIONS.get(employee.role, set())
    return "*" in permissions or permission in permissions


def require_permission(permission: str):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            verify_jwt_in_request()
            employee = current_employee()
            if not has_permission(employee, permission):
                raise ApiError("没有执行此操作的权限", 403, "FORBIDDEN")
            return fn(*args, **kwargs)

        return wrapper

    return decorator
