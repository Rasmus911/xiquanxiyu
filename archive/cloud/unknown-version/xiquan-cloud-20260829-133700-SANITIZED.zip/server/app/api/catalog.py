from decimal import Decimal, InvalidOperation

from flask import Blueprint, request

from ..audit_service import write_audit
from ..auth_service import require_permission
from ..extensions import db, socketio
from ..models import CatalogItem
from ..pricing_service import reprice_open_catalog_items
from ..serializers import catalog_dict
from .errors import ApiError, success

bp = Blueprint("catalog", __name__, url_prefix="/catalog")
VALID_KINDS = {"ticket", "service", "product", "compensation"}


def _decimal(value, field):
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError):
        raise ApiError(f"{field}格式不正确") from None
    if result < 0:
        raise ApiError(f"{field}不能为负数")
    return result


@bp.get("")
@require_permission("visit:read")
def list_catalog():
    query = CatalogItem.query
    if request.args.get("kind"):
        query = query.filter_by(kind=request.args["kind"])
    if request.args.get("active") == "true":
        query = query.filter_by(is_active=True)
    rows = query.order_by(CatalogItem.kind, CatalogItem.sort_order, CatalogItem.name).all()
    return success([catalog_dict(row) for row in rows])


@bp.post("")
@require_permission("catalog:write")
def create_item():
    body = request.get_json(silent=True) or {}
    kind = str(body.get("kind", "")).strip()
    name = str(body.get("name", "")).strip()
    if kind not in VALID_KINDS or not name:
        raise ApiError("项目类型或名称无效")
    row = CatalogItem(
        kind=kind,
        category=str(body.get("category", "默认")).strip() or "默认",
        name=name,
        price=_decimal(body.get("price", 0), "价格"),
        stock_tracked=bool(body.get("stock_tracked", kind == "product")),
        low_stock_threshold=_decimal(body.get("low_stock_threshold", 0), "预警库存"),
        sort_order=int(body.get("sort_order", 0)),
    )
    db.session.add(row)
    db.session.flush()
    write_audit("catalog.create", "catalog_item", row.id, catalog_dict(row))
    db.session.commit()
    socketio.emit("catalog.changed", {"item_id": row.id})
    return success(catalog_dict(row), "项目创建成功", 201)


@bp.patch("/<item_id>")
@require_permission("catalog:write")
def update_item(item_id):
    row = db.session.get(CatalogItem, item_id)
    if not row:
        raise ApiError("项目不存在", 404, "NOT_FOUND")
    body = request.get_json(silent=True) or {}
    before = catalog_dict(row)
    if "name" in body:
        row.name = str(body["name"]).strip()
    if "category" in body:
        row.category = str(body["category"]).strip() or "默认"
    if "price" in body:
        row.price = _decimal(body["price"], "价格")
    if "is_active" in body:
        row.is_active = bool(body["is_active"])
    if "stock_tracked" in body:
        row.stock_tracked = bool(body["stock_tracked"])
    if "low_stock_threshold" in body:
        row.low_stock_threshold = _decimal(body["low_stock_threshold"], "预警库存")
    if "sort_order" in body:
        row.sort_order = int(body["sort_order"])
    row.version += 1
    repriced = reprice_open_catalog_items(row) if "price" in body else {"item_count": 0, "visit_ids": []}
    write_audit(
        "catalog.update",
        "catalog_item",
        row.id,
        {"before": before, "after": catalog_dict(row), "repriced_open_bills": repriced},
    )
    db.session.commit()
    socketio.emit("catalog.changed", {"item_id": row.id})
    if repriced["visit_ids"]:
        socketio.emit("visit.changed", {"reason": "catalog_price_changed", **repriced})
    return success(catalog_dict(row))
