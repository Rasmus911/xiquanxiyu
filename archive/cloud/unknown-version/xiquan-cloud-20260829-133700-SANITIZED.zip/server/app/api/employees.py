from flask import Blueprint, request

from ..audit_service import write_audit
from ..auth_service import hash_password, require_permission
from ..extensions import db
from ..models import Employee
from ..serializers import employee_dict
from .errors import ApiError, success

bp = Blueprint("employees", __name__, url_prefix="/employees")
VALID_ROLES = {"cashier", "inventory", "manager", "admin"}


@bp.get("")
@require_permission("employee:read")
def list_employees():
    return success([employee_dict(row) for row in Employee.query.order_by(Employee.created_at).all()])


@bp.post("")
@require_permission("*")
def create_employee():
    body = request.get_json(silent=True) or {}
    username = str(body.get("username", "")).strip()
    display_name = str(body.get("display_name", "")).strip()
    role = str(body.get("role", "cashier"))
    if not username or not display_name:
        raise ApiError("用户名和姓名不能为空")
    if role not in VALID_ROLES:
        raise ApiError("角色无效")
    if Employee.query.filter_by(username=username).first():
        raise ApiError("用户名已存在", 409, "USERNAME_EXISTS")
    employee = Employee(
        username=username,
        display_name=display_name,
        role=role,
        password_hash=hash_password(str(body.get("password", ""))),
    )
    db.session.add(employee)
    db.session.flush()
    write_audit("employee.create", "employee", employee.id, employee_dict(employee))
    db.session.commit()
    return success(employee_dict(employee), "员工创建成功", 201)


@bp.patch("/<employee_id>")
@require_permission("*")
def update_employee(employee_id):
    employee = db.get_or_404(Employee, employee_id)
    body = request.get_json(silent=True) or {}
    before = employee_dict(employee)
    if "display_name" in body:
        employee.display_name = str(body["display_name"]).strip()
    if "role" in body:
        if body["role"] not in VALID_ROLES:
            raise ApiError("角色无效")
        employee.role = body["role"]
    if "is_active" in body:
        employee.is_active = bool(body["is_active"])
    if body.get("password"):
        employee.password_hash = hash_password(str(body["password"]))
    if body.get("unlock"):
        employee.failed_login_attempts = 0
        employee.locked_until = None
    write_audit(
        "employee.update",
        "employee",
        employee.id,
        {"before": before, "after": employee_dict(employee)},
    )
    db.session.commit()
    return success(employee_dict(employee))
