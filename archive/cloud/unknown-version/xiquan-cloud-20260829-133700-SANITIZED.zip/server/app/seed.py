from decimal import Decimal

from .extensions import db
from .models import CatalogItem, SystemSetting, Wristband

MALE_WRISTBAND_NUMBERS = tuple(str(number) for number in range(8001, 8061))
FEMALE_WRISTBAND_NUMBERS = tuple(str(number) for number in range(9001, 9061))
DEFAULT_WRISTBAND_NUMBERS = MALE_WRISTBAND_NUMBERS + FEMALE_WRISTBAND_NUMBERS

DEFAULT_SETTINGS = {
    "store_name": ("溪泉洗浴", "小票和系统显示的店名"),
    "lost_wristband_fee": ("20.00", "手牌挂失赔偿金额"),
    "allow_negative_stock": (False, "是否允许商品库存为负数"),
    "require_open_shift": (False, "已停用交接班流程"),
    "force_clear_password": ("00000000", "前台强制清空手牌的操作密码"),
}

# 参考承德地区常见大众洗浴消费习惯的初始项目，仅作为可编辑模板。
DEFAULT_CATALOG = (
    ("service", "搓澡助浴", "传统搓澡", "30.00", False, 10),
    ("service", "搓澡助浴", "牛奶浴", "38.00", False, 20),
    ("service", "搓澡助浴", "盐浴", "38.00", False, 30),
    ("service", "搓澡助浴", "芦荟浴", "38.00", False, 40),
    ("service", "搓澡助浴", "醋搓", "35.00", False, 50),
    ("service", "搓澡助浴", "蜂蜜浴", "48.00", False, 60),
    ("service", "组合项目", "二合一（搓澡+牛奶）", "58.00", False, 70),
    ("service", "组合项目", "三合一（搓澡+牛奶+盐）", "78.00", False, 80),
    ("service", "理疗按摩", "刮痧", "30.00", False, 90),
    ("service", "理疗按摩", "拔罐", "30.00", False, 100),
    ("service", "理疗按摩", "修脚", "30.00", False, 110),
    ("service", "理疗按摩", "足疗（60分钟）", "68.00", False, 120),
    ("service", "理疗按摩", "全身按摩（60分钟）", "128.00", False, 130),
    ("product", "洗浴用品", "一次性搓澡巾", "5.00", True, 210),
    ("product", "洗浴用品", "一次性毛巾", "8.00", True, 220),
    ("product", "洗浴用品", "牙刷牙膏套装", "3.00", True, 230),
    ("product", "洗浴用品", "香皂", "3.00", True, 240),
    ("product", "饮品", "矿泉水", "3.00", True, 310),
    ("product", "饮品", "可乐", "5.00", True, 320),
    ("product", "饮品", "雪碧", "5.00", True, 330),
    ("product", "饮品", "冰红茶", "5.00", True, 340),
    ("product", "饮品", "王老吉", "6.00", True, 350),
    ("product", "饮品", "红牛", "8.00", True, 360),
    ("product", "承德特色饮品", "承德杏仁露", "6.00", True, 370),
    ("product", "承德特色饮品", "山楂汁", "6.00", True, 380),
    ("product", "食品", "方便面", "6.00", True, 410),
    ("product", "食品", "火腿肠", "3.00", True, 420),
    ("product", "食品", "茶叶蛋", "2.00", True, 430),
)


def seed_defaults():
    for key, (value, description) in DEFAULT_SETTINGS.items():
        setting = SystemSetting.query.filter_by(key=key).first()
        if not setting:
            db.session.add(SystemSetting(key=key, value=value, description=description))
        elif key == "require_open_shift":
            setting.value = False
            setting.description = description

    existing_wristbands = {
        row.number for row in Wristband.query.filter(Wristband.number.in_(DEFAULT_WRISTBAND_NUMBERS)).all()
    }
    for number in DEFAULT_WRISTBAND_NUMBERS:
        if number not in existing_wristbands:
            db.session.add(Wristband(number=number))

    if not CatalogItem.query.filter_by(kind="ticket").first():
        db.session.add(
            CatalogItem(
                kind="ticket",
                category="门票",
                name="基础门票",
                price=Decimal("0.00"),
                sort_order=0,
            )
        )
    if not CatalogItem.query.filter_by(kind="compensation").first():
        db.session.add(
            CatalogItem(
                kind="compensation",
                category="赔偿",
                name="手牌挂失赔偿",
                price=Decimal("20.00"),
                sort_order=0,
            )
        )
    for kind, category, name, price, stock_tracked, sort_order in DEFAULT_CATALOG:
        if not CatalogItem.query.filter_by(kind=kind, name=name).first():
            db.session.add(
                CatalogItem(
                    kind=kind,
                    category=category,
                    name=name,
                    price=Decimal(price),
                    stock_tracked=stock_tracked,
                    stock_quantity=Decimal("10") if stock_tracked else Decimal("0"),
                    low_stock_threshold=Decimal("5") if stock_tracked else Decimal("0"),
                    sort_order=sort_order,
                )
            )
    db.session.commit()
