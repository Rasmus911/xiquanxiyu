from sqlalchemy import inspect, text

from .extensions import db


def ensure_runtime_schema():
    """为直接运行 EXE 的现有 SQLite/PostgreSQL 数据库补充兼容字段。"""
    inspector = inspect(db.engine)
    if "visits" not in inspector.get_table_names():
        return
    columns = {column["name"] for column in inspector.get_columns("visits")}
    if "party_id" not in columns:
        db.session.execute(text("ALTER TABLE visits ADD COLUMN party_id VARCHAR(36)"))
        db.session.commit()
    db.session.execute(text("CREATE INDEX IF NOT EXISTS ix_visits_party_id ON visits (party_id)"))
    db.session.commit()
