#!/usr/bin/env bash
set -Eeuo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "请使用 sudo bash scripts/bootstrap-ubuntu.sh 运行。" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y docker.io docker-compose-v2 unzip curl openssl ca-certificates cron
systemctl enable --now docker
systemctl enable --now cron

login_user="${SUDO_USER:-}"
if [ -n "$login_user" ] && [ "$login_user" != "root" ]; then
  usermod -aG docker "$login_user"
  echo "已把 $login_user 加入 docker 用户组；重新登录 SSH 后生效。"
fi

docker --version
docker compose version
echo "基础环境安装完成。阿里云安全组还需要单独放行 TCP 22、80、443。"
