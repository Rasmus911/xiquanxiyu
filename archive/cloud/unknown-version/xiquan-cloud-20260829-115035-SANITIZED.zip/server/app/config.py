import os
import sys
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[1]
ENV_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else BASE_DIR
load_dotenv(ENV_DIR / ".env")
DEFAULT_DATA_DIR = Path(
    os.getenv(
        "XIQUAN_DATA_DIR",
        str(Path.cwd() / "data" if getattr(sys, "frozen", False) else BASE_DIR / "instance"),
    )
).resolve()
DEFAULT_DATA_DIR.mkdir(parents=True, exist_ok=True)


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-secret-change-me-use-32-bytes")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-only-jwt-secret-change-me-use-32-bytes")
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", f"sqlite:///{DEFAULT_DATA_DIR / 'bathhouse.db'}")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_AS_ASCII = False
    CORS_ORIGINS = [
        item.strip()
        for item in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173,null").split(",")
        if item.strip()
    ]
    AUTO_CREATE_DB = os.getenv("AUTO_CREATE_DB", "1") == "1"
    SOCKETIO_ASYNC_MODE = os.getenv("SOCKETIO_ASYNC_MODE") or None
    JWT_ACCESS_TOKEN_EXPIRES = 60 * 60 * 8
    JWT_REFRESH_TOKEN_EXPIRES = 60 * 60 * 24 * 30


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite://"
    AUTO_CREATE_DB = False
    SOCKETIO_ASYNC_MODE = "threading"
    JWT_ACCESS_TOKEN_EXPIRES = 3600
