import hashlib

from .extensions import db
from .models import IdempotencyRecord


def idempotency_record_key(endpoint: str, actor_id: str, raw_key: str) -> str:
    value = f"{endpoint}:{actor_id}:{raw_key}".encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def idempotency_lookup(endpoint: str, actor_id: str, raw_key: str):
    key = idempotency_record_key(endpoint, actor_id, raw_key)
    return db.session.get(IdempotencyRecord, key)


def idempotency_store(
    key: str,
    endpoint: str,
    status: int,
    body: dict,
) -> IdempotencyRecord:
    record = IdempotencyRecord(
        key=key,
        endpoint=endpoint,
        response_status=status,
        response_body=body,
    )
    db.session.add(record)
    return record
