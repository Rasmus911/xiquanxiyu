[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('preflight','deploy','resume')][string]$Mode,
    [Parameter(Mandatory)][string]$BundlePath,
    [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{64}$')][string]$ExpectedSha256,
    [Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{40}$')][string]$SourceCommit,
    [string]$Stage,
    [string]$JobDirectory,
    [string]$EcsTarget = 'root@39.96.217.210',
    [switch]$StageOnly
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
function Get-DesktopDigest([string]$Path) {
    $stream=[IO.File]::OpenRead($Path); $sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $stream.Dispose(); $sha.Dispose() }
}
$root=Split-Path -Parent $PSScriptRoot
$bundle=(Resolve-Path -LiteralPath $BundlePath).Path
if((Get-DesktopDigest $bundle)-cne $ExpectedSha256){throw 'SOURCE SHA256 mismatch. No connection attempted.'}
if($EcsTarget-notmatch '^[A-Za-z0-9_-]+@[A-Za-z0-9.-]+$'){throw 'Invalid SSH target.'}
if($Mode-in @('deploy','resume') -and $Stage-notmatch '^/opt/xiquan-releases/desktop051-stage-[0-9a-f]{32}$'){throw 'Exact new-release stage required. Do not reuse an old stock/operations stage.'}
if($Mode-eq 'resume' -and $JobDirectory-notmatch '^/opt/xiquan-backups/desktop051-cutover-[0-9a-f]{32}$'){throw 'Exact new-release recovery job required.'}
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip=[IO.Compression.ZipFile]::OpenRead($bundle)
try{
    $entry=$zip.GetEntry('xiquan/source-manifest.json')
    if(-not $entry){throw 'SOURCE manifest missing.'}
    $reader=[IO.StreamReader]::new($entry.Open(),[Text.Encoding]::UTF8)
    try{$manifest=$reader.ReadToEnd()|ConvertFrom-Json}finally{$reader.Dispose()}
    if($manifest.source_commit-cne $SourceCommit){throw 'SOURCE commit mismatch.'}
    if($manifest.asset_source_commit-cne $SourceCommit -or $manifest.desktop_version-cne '0.5.1' -or
       $manifest.schema_head-cne '20261012_physical_membership' -or $manifest.android_version-cne '1.2.9' -or
       $manifest.android_version_code-ne 16 -or ($manifest.targets-join ',')-cne 'win10-x86,win10-x64,win11-x86,win11-x64'){
        throw 'Wrong physical membership SOURCE contract.'
    }
    $expected=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
    foreach($record in $manifest.files){
        $relative=[string]$record.file
        if($relative-match '(^/|\\|:|(^|/)\.\.(/|$)|(^|/)\.(env|git)(/|$))' -or -not $expected.Add('xiquan/'+$relative)){throw 'Unsafe or duplicate SOURCE record.'}
        if($relative-match '(^|/)\.env' -and $relative-notmatch '(^|/)\.env\.example$'){throw 'Private environment forbidden.'}
        if($relative-match '(^|/)(private|instance|data|node_modules|\.venv)(/|$)|\.(pem|key|jks|keystore|pfx|p12|backup|db|sqlite|sqlite3|dump|exe|apk)$' -or
           $relative-match '^deploy/cloud/(updates/|releases/|mobile/downloads/|nginx/active\.conf$)'){
            throw 'Private data, keys or published artifacts are forbidden in SOURCE.'
        }
        $item=$zip.GetEntry('xiquan/'+$relative)
        if(-not $item -or $item.Length-ne $record.size){throw 'SOURCE entry missing/size mismatch.'}
        $stream=$item.Open(); $sha=[Security.Cryptography.SHA256]::Create()
        try{$actual=([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','').ToLowerInvariant()}finally{$stream.Dispose();$sha.Dispose()}
        if($actual-cne $record.sha256){throw 'SOURCE entry hash mismatch.'}
    }
    [void]$expected.Add('xiquan/source-manifest.json')
    if($zip.GetEntry('xiquan/SOURCE-WEB-NOT-PRODUCTION.txt')){[void]$expected.Add('xiquan/SOURCE-WEB-NOT-PRODUCTION.txt')}
    foreach($item in $zip.Entries){if(-not $expected.Remove($item.FullName)){throw 'Unexpected or duplicate ZIP entry.'}}
    if($expected.Count){throw 'ZIP does not contain complete SOURCE.'}
    foreach($required in @('server/app/member_cards.py','server/app/member_payment.py','server/migrations/versions/20261012_physical_membership.py','client/package.json','mobile/version.json')){
        if(-not $zip.GetEntry('xiquan/'+$required)){throw 'Registration source missing.'}
    }
    $names=@('desktop_051_deploy.py','desktop_051_guard.py','desktop_051_pgproof.py','stock_deploy.py','stock_guard.py',
        'operations_backup_verify.py','operations_preflight.py','operations_deploy.py','operations_offline_build.py')
    $tools=@()
    foreach($name in $names){
        $file=Join-Path $root ('deploy\cloud\scripts\'+$name)
        $hash=Get-DesktopDigest $file
        $record=@($manifest.files|Where-Object{$_.file-ceq ('deploy/cloud/scripts/'+$name)})
        if($record.Count-ne 1 -or $record[0].sha256-cne $hash){throw ('Transport differs from exact SOURCE: '+$name)}
        $tools+=[pscustomobject]@{Name=$name;File=$file;Hash=$hash}
    }
}finally{$zip.Dispose()}
if($StageOnly){[pscustomobject]@{Mode=$Mode;SourceCommit=$SourceCommit;Sha256=$ExpectedSha256;CloudChanged=$false};return}
. (Join-Path $PSScriptRoot 'lib\desktop-051-transport.ps1')
function Invoke-DesktopSSH([string]$Command) {
    $result=Invoke-TokenNative -Executable 'ssh.exe' -Arguments @($options + @($EcsTarget,$Command)) -TimeoutSeconds 600 -Label 'DESKTOP051 SSH'
    if($result.ExitCode-ne 0){
        $result.Stdout -split "`r?`n" | ForEach-Object { Write-Host $_ }
        $result.Stderr -split "`r?`n" | Where-Object { $_ -match '^(DESKTOP051_STOPPED:|PRIVATE_DESKTOP_JOB=|FAILED_PHASE=)' } | ForEach-Object { Write-Host $_ }
        throw ('Cloud operation failed; preserve stage/job evidence. Exit: '+$result.ExitCode)
    }
    return @($result.Stdout -split "`r?`n" | Where-Object { $_ })
}
$options=@('-o','ConnectTimeout=20','-o','ServerAliveInterval=15','-o','ServerAliveCountMax=3')
$remote='/tmp/xiquan-desktop051-tools-'+[guid]::NewGuid().ToString('N')
Invoke-DesktopSSH ('umask 077 && mkdir -m 700 '+$remote) | Out-Host

$uploads=@($tools|ForEach-Object{[pscustomobject]@{File=$_.File;Hash=$_.Hash;Remote=$remote+'/'+$_.Name}})
if($Mode-in @('preflight','all')){$uploads+=[pscustomobject]@{File=$bundle;Hash=$ExpectedSha256;Remote=$remote+'/source.zip'}}
foreach($item in $uploads){
    Write-Host ('UPLOAD_AND_SHA256: '+(Split-Path -Leaf $item.File))
    $uploaded=Invoke-TokenNative -Executable 'scp.exe' -Arguments @($options + @('--',$item.File,($EcsTarget+':'+$item.Remote))) -TimeoutSeconds 300 -Label 'DESKTOP051 upload'
    if($uploaded.ExitCode-ne 0){throw 'Bounded upload failed; nothing deployed.'}

}
$hashes=Invoke-DesktopSSH ('sha256sum '+(($uploads|ForEach-Object{$_.Remote})-join ' '))

foreach($item in $uploads){
    $pattern='^'+[regex]::Escape($item.Hash)+'\s+\*?'+[regex]::Escape($item.Remote)+'$'
    if(@($hashes|Where-Object{$_-match $pattern}).Count-ne 1){throw 'Remote SHA mismatch; deployment not invoked.'}
}
if($Mode-in @('preflight','all')){
    $command='python3 '+$remote+'/desktop_051_deploy.py preflight --bundle '+$remote+'/source.zip --sha256 '+$ExpectedSha256+' --commit '+$SourceCommit
    $output=Invoke-DesktopSSH $command

    $output|ForEach-Object{Write-Host $_}
    $results=@($output|Where-Object{$_-match '^\s*\{'}|ForEach-Object{
        $candidate=$_|ConvertFrom-Json
        if($candidate.PSObject.Properties.Name-contains 'stage'){$candidate}
    })
    if($results.Count-ne 1 -or $results[0].source_commit-cne $SourceCommit -or $results[0].source_sha256-cne $ExpectedSha256 -or
        $results[0].stage-notmatch '^/opt/xiquan-releases/desktop051-stage-[0-9a-f]{32}$'){throw 'Preflight stage identity invalid.'}
    $Stage=$results[0].stage
    if($Mode-eq 'preflight'){$results[0];return}
}
$confirmation=Read-Host ('Pause writes for verified backup and additive physical membership migration. Existing data retained. Type UPDATE 0.5.1')
if($confirmation-cne 'UPDATE 0.5.1'){throw 'Update cancelled. Only private staging was created.'}
$action=$Mode; if($action-eq 'all'){$action='deploy'}
$command='python3 '+$remote+'/desktop_051_deploy.py '+$action+' --stage '+$Stage+' --commit '+$SourceCommit+' --sha256 '+$ExpectedSha256
if($action-eq 'resume'){$command+=' --job '+$JobDirectory}
$identityRoot=Join-Path $root 'private\desktop051-transports'
[void](New-Item -ItemType Directory -Force -Path $identityRoot)
$identityPath=Join-Path $identityRoot ('transport-'+[guid]::NewGuid().ToString('N')+'.json')
$operation=Invoke-Desktop051Operation -Executable 'ssh.exe' -Arguments @($options+@($EcsTarget,$command)) `
    -Stage $Stage -Job $JobDirectory -IdentityFile $identityPath -TimeoutSeconds 14430
if($operation.ExitCode-ne 0){throw ('Cutover stopped; exact identity retained: '+$identityPath+'; no automatic retry. Exit='+$operation.ExitCode)}
$deployed=@($operation.Stdout -split "`r?`n" | Where-Object { $_ })
$deployed | ForEach-Object { Write-Host $_ }
$reported=@($deployed|Where-Object { $_ -match '^PRIVATE_DESKTOP_JOB=/opt/xiquan-backups/desktop051-cutover-[0-9a-f]{32}$' })
if($reported.Count-eq 1){$JobDirectory=$reported[0].Substring('PRIVATE_DESKTOP_JOB='.Length)}
if($JobDirectory-notmatch '^/opt/xiquan-backups/desktop051-cutover-[0-9a-f]{32}$'){throw 'Deployment returned no exact completed job identity; do not publish.'}

Write-Host 'Cloud API/web updated. Signed Windows channels must be published separately; test login with existing accounts.'
[pscustomobject]@{Stage=$Stage;Job=$JobDirectory;SourceCommit=$SourceCommit;SourceSha256=$ExpectedSha256;CloudChanged=$true}
