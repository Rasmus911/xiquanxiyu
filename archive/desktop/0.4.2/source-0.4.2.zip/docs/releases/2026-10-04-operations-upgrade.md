# 2026-10-04 营业升级实施记录

状态：开发中。用户选择原目录内、当前会话逐项实现，不使用子代理；开发分支 `feat/operations-upgrade-20261004`。目前没有新安装包、没有上传，也没有改变ECS数据。

最新范围：桌面只构建Win11 64位，安卓仍交付；重点验收于在跃、李丽娜、于景辉已有绑定管理员手机登录/通道与管理权限。保留其他桌面历史包，不清云端业务数据。

## 源码安全基线

只把 `scripts/lib/source-security.cjs` 明确列出的源码、配置原型和测试加入Git。该文件的枚举器不遍历private、旧临时SSH脚本、生产配置或构建包；敏感内容报告只显示文件、行号和规则。

```powershell
Set-Location -LiteralPath 'F:\溪泉洗浴系统'
powershell.exe -NoProfile -ExecutionPolicy Bypass -File '.\scripts\prepare-source-baseline.ps1' -ValidateOnly
```

私钥、实际.env、Android keystore、数据库/备份/日志、下载和安装包不进Git。不创建远程仓库、不推送。scanner是辅助检查，不是全部安全保证。

## 验证记录

- 原手机端基线：21个测试文件、84项通过（2026-10-04本地测试）。
- 原后端基线229项通过；pytest缓存写权限警告1条，后续测试禁用cacheprovider，不删除用户缓存。
- 原桌面Vue82项、Electron/运行时68项通过。
- R1安全检查器已观察红测；8项绿测通过。白名单纳入必要的NSIS模板和Docker构建忽略文件。较早操作文档保留本地，不把未审阅旧命令示例纳入新Git基线。
- 首次源码基线发现原文件已有尾部空格、空白末行及CRLF差异；只在这次未修改业务源码的基线提交中排除这三类历史空白检查，保持原文件。之后新增业务改动使用正常差异检查。

后续权限、点单、资金、数据替换和发布均按[总计划](F:/溪泉洗浴系统/docs/superpowers/plans/2026-10-04-operations-upgrade.md)记录真实结果；云端步骤和用户隐藏签名输入尚未执行。
