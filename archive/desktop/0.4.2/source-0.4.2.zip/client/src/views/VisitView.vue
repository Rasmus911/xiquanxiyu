<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { apiData, apiErrorMessage, http } from '../api/http'
import AppPageHeader from '../components/app/AppPageHeader.vue'
import CatalogPicker from '../components/orders/CatalogPicker.vue'
import OrderCart from '../components/orders/OrderCart.vue'
import PartyTabs from '../components/orders/PartyTabs.vue'
import { orderFingerprint, setOrderQuantity, toggleOrderItem } from '../domain/orders/selection'
import { clearPendingRequestKey, pendingRequestKey } from '../domain/requests/pending-key'
import { subscribeRealtime } from '../realtime/events'
import { useConnectivityStore } from '../stores/connectivity'
import { useRuntimeStore } from '../stores/runtime'
import type { CatalogItem, Visit } from '../types'
import { formatBusinessTime } from '../format/business-time'

const route = useRoute()
const router = useRouter()
const connectivity = useConnectivityStore()
const runtime = useRuntimeStore()
const visit = ref<Visit | null>(null)
const catalog = ref<CatalogItem[]>([])
const loading = ref(false)
const adding = ref(false)
const selectedQuantities = ref<Record<string, number>>({})
let refreshTimer: number | undefined
let unsubscribeRealtime: (() => void) | undefined
let clockTimer: number | undefined
const clockNow = ref(Date.now())
const linkedVisits = computed(() => visit.value?.linked_visits?.length ? visit.value.linked_visits : (visit.value ? [visit.value] : []))
const linkedItems = computed(() => linkedVisits.value.flatMap((linkedVisit) =>
  linkedVisit.items.map((item) => ({ ...item, wristband_number: linkedVisit.wristband_number })),
))
const displayedTotal = computed(() => visit.value?.linked_total_amount || visit.value?.total_amount || '0.00')
const selectedKindCount = computed(() => Object.values(selectedQuantities.value).filter((quantity) => quantity > 0).length)
const selectedCount = computed(() => Object.values(selectedQuantities.value).reduce((total, quantity) => total + quantity, 0))

function elapsed(openedAt?: string) {
  if (!openedAt) return ''
  const seconds = Math.max(0, Math.floor((clockNow.value - new Date(openedAt).getTime()) / 1000))
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor(seconds % 3600 / 60)
  const remain = seconds % 60
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remain).padStart(2, '0')}`
}

async function load(silent = false) {
  const isCurrent = guardBusinessOperation('load')
  if (!isCurrent()) return

  if (!silent) loading.value = true
  try {
    const [visitRes, catalogRes] = await Promise.all([
      http.get(`/visits/${route.params.id}`),
      http.get('/catalog', { params: { active: true } }),
    ]); if (!isCurrent()) return;
    visit.value = apiData<Visit>(visitRes)
    catalog.value = apiData<CatalogItem[]>(catalogRes)
    const availableItems = new Map(catalog.value.filter((row) => row.is_active).map((row) => [row.id, row]))
    selectedQuantities.value = Object.fromEntries(
      Object.entries(selectedQuantities.value).flatMap(([id, quantity]) => {
        const item = availableItems.get(id)
        if (!item) return []
        const maximum = item.kind === 'service' ? 1 : (item.stock_tracked ? Math.max(0, Math.floor(Number(item.stock_quantity))) : 99)
        const nextQuantity = Math.min(Math.max(0, Math.floor(quantity)), maximum)
        return nextQuantity ? [[id, nextQuantity]] : []
      }),
    )
  } catch (error) { if (!isCurrent()) return; 
    if (!silent) ElMessage.error(apiErrorMessage(error))
  } finally { if (!isCurrent()) return; 
    loading.value = false
  }
}

function selectedQuantity(itemId: string) {
  return selectedQuantities.value[itemId] || 0
}

function setQuantity(item: CatalogItem, value: number | undefined) {
  const maximum = item.kind === 'service' ? 1 : (item.stock_tracked ? Math.max(0, Math.floor(Number(item.stock_quantity))) : 99)
  selectedQuantities.value = setOrderQuantity(selectedQuantities.value, item.id, Number(value || 0), maximum)
}

function selectItem(item: CatalogItem) {
  const maximum = item.kind === 'service' ? 1 : (item.stock_tracked ? Math.max(0, Math.floor(Number(item.stock_quantity))) : 99)
  selectedQuantities.value = toggleOrderItem(selectedQuantities.value, { id: item.id, kind: item.kind as 'service' | 'product', maximum })
}

function clearSelectedItems() {
  selectedQuantities.value = {}
}

async function addSelectedItems() {
  const isCurrent = guardBusinessOperation('addSelectedItems')
  if (!isCurrent()) return

  if (!selectedCount.value) return ElMessage.warning('请先选择要添加的项目')
  adding.value = true
  const releaseBusy = await runtime.setBusinessBusy('正在提交加单')
  if (!isCurrent()) { await releaseBusy(); return }
  const visitId = String(route.params.id)
  const scope = `visit:${visitId}:batch-add`
  const key = pendingRequestKey(scope, orderFingerprint(visitId, selectedQuantities.value))
  try {
    await http.post(`/visits/${visitId}/items/batch`, {
      items: Object.entries(selectedQuantities.value).map(([catalogItemId, quantity]) => ({ catalog_item_id: catalogItemId, quantity })),
      idempotency_key: key,
    }, { headers: { 'Idempotency-Key': key } }); if (!isCurrent()) return;
    clearPendingRequestKey(scope)
    ElMessage.success(`已添加 ${selectedKindCount.value} 种，共 ${selectedCount.value} 份`)
    clearSelectedItems()
    await load(); if (!isCurrent()) return;
  } catch (error) { if (!isCurrent()) return; 
    ElMessage.error(apiErrorMessage(error))
  } finally {
    if (isCurrent()) adding.value = false
    await releaseBusy()
  }
}

async function voidItem(itemId: string) {
  const isCurrent = guardBusinessOperation('voidItem')
  if (!isCurrent()) return

  try {
    await ElMessageBox.confirm('确定撤销这个消费项目吗？', '撤销消费项目', { type: 'warning', confirmButtonText: '确定撤销', cancelButtonText: '取消' }); if (!isCurrent()) return;
    const scope = `visit:${route.params.id}:void:${itemId}`
    const key = pendingRequestKey(scope, `${route.params.id}|${itemId}|void`)
    await http.post(`/visits/${route.params.id}/items/${itemId}/void`, { idempotency_key: key }, { headers: { 'Idempotency-Key': key } }); if (!isCurrent()) return;
    clearPendingRequestKey(scope)
    ElMessage.success('项目已撤销')
    await load(); if (!isCurrent()) return;
  } catch (error) { if (!isCurrent()) return; 
    if (error === 'cancel' || error === 'close') return
    ElMessage.error(apiErrorMessage(error))
  }
}

function checkout(scope: 'party' | 'selected' = 'party') {
  router.push({ path: '/checkout', query: { visits: String(route.params.id), scope, returnTo: router.currentRoute.value.fullPath } })
}

function selectPartyVisit(visitId: string) {
  void router.push({ path: `/visits/${visitId}`, query: { returnTo: String(route.query.returnTo || '/') } })
}

onMounted(() => {
  load()
  unsubscribeRealtime = subscribeRealtime(['visits', 'wristbands', 'catalog', 'inventory', 'checkout'], () => load(true))
  refreshTimer = window.setInterval(() => {
    if (!connectivity.isOnline && document.visibilityState === 'visible') load(true)
  }, 30_000)
  clockTimer = window.setInterval(() => { clockNow.value = Date.now() }, 1_000)
})

onBeforeUnmount(() => {
  unsubscribeRealtime?.()
  if (refreshTimer) window.clearInterval(refreshTimer)
  if (clockTimer) window.clearInterval(clockTimer)
})
</script>

<template>
  <div class="page" v-loading="loading">
    <AppPageHeader :title="`${visit?.wristband_number || '—'} 号手牌`" :description="`开单时间：${formatBusinessTime(visit?.opened_at)} · 已使用 ${elapsed(visit?.opened_at)}`" eyebrow="ACTIVE ORDER">
      <template #actions>
        <span class="bill-total">{{ linkedVisits.length > 1 ? '联动合计' : '合计' }} ¥{{ displayedTotal }}</span>
        <el-button v-if="linkedVisits.length > 1" type="success" plain size="large" @click="checkout('selected')">当前手牌单独结账（¥{{ visit?.total_amount }}）</el-button>
        <el-button type="success" size="large" @click="checkout('party')">{{ linkedVisits.length > 1 ? '联动整组结账' : '结账' }}</el-button>
      </template>
    </AppPageHeader>
    <PartyTabs :visits="linkedVisits" :current-id="visit?.id" :elapsed="elapsed" @select="selectPartyVisit" />
    <el-row :gutter="18">
      <el-col :span="14">
        <el-card shadow="never">
          <template #header><div><strong>快速加单</strong><div class="muted">服务单击选中；商品可连续点击或直接调整数量</div></div></template>
          <CatalogPicker :items="catalog" :quantities="selectedQuantities" @select="selectItem" @quantity="setQuantity" />
          <OrderCart :items="catalog" :quantities="selectedQuantities" :adding="adding" @clear="clearSelectedItems" @submit="addSelectedItems" />
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card shadow="never">
          <template #header><strong>{{ linkedVisits.length > 1 ? '联动消费明细' : '消费明细' }}</strong></template>
          <el-table :data="linkedItems" max-height="610">
            <el-table-column v-if="linkedVisits.length > 1" prop="wristband_number" label="手牌" width="76" />
            <el-table-column prop="name" label="项目" min-width="120">
              <template #default="scope"><span :class="{ voided: scope.row.status === 'voided' }">{{ scope.row.name }}</span><el-tag v-if="scope.row.status === 'voided'" size="small" type="info">已撤销</el-tag></template>
            </el-table-column>
            <el-table-column prop="quantity" label="数量" width="70" />
            <el-table-column prop="total_amount" label="金额" width="90"><template #default="scope">¥{{ scope.row.total_amount }}</template></el-table-column>
            <el-table-column label="操作" width="75"><template #default="scope"><el-button v-if="scope.row.status === 'active' && scope.row.wristband_number === visit?.wristband_number" link type="danger" @click="voidItem(scope.row.id)">撤销</el-button><span v-else-if="scope.row.status === 'active'" class="muted">切换手牌</span></template></el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.bill-total { align-self: center; color: var(--xq-danger); font-size: 22px; font-weight: 800; }
.voided { text-decoration: line-through; color: #a0a7b2; margin-right: 6px; }
</style>
