<script setup lang="ts">
import { useBusinessGuard } from '../business/state'
const guardBusinessOperation = useBusinessGuard()

import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { apiData, apiErrorMessage, http } from '../api/http'
import AppPageHeader from '../components/app/AppPageHeader.vue'
import { usePageRefresh } from '../composables/usePageRefresh'
import type { Employee } from '../types'
const rows = ref<Employee[]>([]); const drawerOpen = ref(false); const editingId = ref('')
const form = reactive({ username: '', display_name: '', password: '', role: 'cashier', is_active: true, unlock: false })
const roleNames: Record<string, string> = { male_scrubber: '男浴搓澡师', female_scrubber: '女浴搓澡师', floor_attendant: '三层服务员', cashier: '收银员', inventory: '库管', manager: '经理', admin: '系统管理员' }
async function load() {
  const isCurrent = guardBusinessOperation('load')
  if (!isCurrent()) return
 try { const data = apiData<Employee[]>(await http.get('/employees')); if (!isCurrent()) return; rows.value = data } catch (error) { if (!isCurrent()) return;  ElMessage.error(apiErrorMessage(error)) } }
function createNew() { editingId.value = ''; Object.assign(form, { username: '', display_name: '', password: '', role: 'cashier', is_active: true, unlock: false }); drawerOpen.value = true }
function edit(row: Employee) { editingId.value = row.id; Object.assign(form, { username: row.username, display_name: row.display_name, password: '', role: row.role, is_active: row.is_active, unlock: false }); drawerOpen.value = true }
async function save() {
  const isCurrent = guardBusinessOperation('save')
  if (!isCurrent()) return
 try { if (editingId.value) await http.patch(`/employees/${editingId.value}`, form); else await http.post('/employees', form); if (!isCurrent()) return; ElMessage.success('员工保存成功'); drawerOpen.value = false; await load(); if (!isCurrent()) return; } catch (error) { if (!isCurrent()) return;  ElMessage.error(apiErrorMessage(error)) } }
usePageRefresh(load)
onMounted(load)
</script>
<template><div class="page"><AppPageHeader title="员工账号" description="每人使用独立账号和密码；岗位决定可见页面和可执行操作。" eyebrow="EMPLOYEES"><template #actions><el-button type="primary" @click="createNew">新增员工</el-button></template></AppPageHeader><el-card shadow="never"><el-table :data="rows"><el-table-column prop="username" label="登录账号" /><el-table-column prop="display_name" label="员工姓名" /><el-table-column label="岗位角色"><template #default="scope">{{ roleNames[scope.row.role] }}</template></el-table-column><el-table-column label="手机端最高权限" width="150"><template #default="scope"><el-tag :type="scope.row.mobile_full_access ? 'warning' : 'info'">{{ scope.row.mobile_full_access ? '已授权' : '未授权' }}</el-tag></template></el-table-column><el-table-column label="状态"><template #default="scope"><el-tag :type="scope.row.is_active ? 'success' : 'info'">{{ scope.row.is_active ? '启用' : '停用' }}</el-tag></template></el-table-column><el-table-column label="操作"><template #default="scope"><el-button link type="primary" @click="edit(scope.row)">编辑</el-button></template></el-table-column></el-table></el-card><el-drawer v-model="drawerOpen" :title="editingId ? '编辑员工' : '新增员工'" size="480px"><el-alert type="info" :closable="false" title="手机端最高权限为服务器受控授权，此处仅展示，普通管理员账号不会自动获得。" style="margin-bottom:14px"/><el-form label-position="top"><el-form-item label="登录账号"><el-input v-model="form.username" :disabled="Boolean(editingId)" /></el-form-item><el-form-item label="员工姓名"><el-input v-model="form.display_name" /></el-form-item><el-form-item :label="editingId ? '新密码（留空不修改）' : '初始密码'"><el-input v-model="form.password" type="password" show-password /></el-form-item><el-form-item label="角色"><el-select v-model="form.role" class="full-width"><el-option v-for="(name, key) in roleNames" :key="key" :label="name" :value="key" /></el-select></el-form-item><el-form-item v-if="editingId"><el-switch v-model="form.is_active" active-text="启用账号" /><el-checkbox v-model="form.unlock" style="margin-left: 20px">解除登录锁定</el-checkbox></el-form-item></el-form><template #footer><el-button @click="drawerOpen = false">取消</el-button><el-button type="primary" @click="save">保存</el-button></template></el-drawer></div></template>
