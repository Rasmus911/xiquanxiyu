import os

import pytest

os.environ['PYTHON_DOTENV_DISABLED'] = '1'

from app import create_app
from app.config import TestConfig
from app.extensions import db
from app.seed import seed_defaults


@pytest.fixture()
def app():
    app = create_app(TestConfig)
    with app.app_context():
        db.create_all()
        seed_defaults()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def admin_session(client):
    terminal = client.post("/api/terminals/register", json={"code": "TEST-01", "name": "测试终端"})
    assert terminal.status_code == 201
    bootstrap = client.post(
        "/api/auth/bootstrap",
        json={"username": "admin", "display_name": "管理员", "password": "admin123"},
    )
    assert bootstrap.status_code == 201
    login = client.post(
        "/api/auth/login",
        json={"username": "admin", "password": "admin123", "terminal_code": "TEST-01"},
    )
    assert login.status_code == 200
    data = login.get_json()["data"]
    headers = {"Authorization": f"Bearer {data['access_token']}"}
    return {"headers": headers, "login": data}
