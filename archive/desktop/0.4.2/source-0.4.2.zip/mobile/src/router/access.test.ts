import { describe, expect, it } from 'vitest'
import { routeAccess } from './access'

const ownerSession = { capabilities: { reports_view: true, inventory_manage: true } }
const ordinarySession = { capabilities: { reports_view: false, inventory_manage: false } }

describe('mobile route access', () => {
  it('requires login for business routes', () => {
    expect(routeAccess('orders', null)).toBe('login')
  })

  it('allows only explicit owner capabilities on management routes', () => {
    expect(routeAccess('reports', ownerSession)).toBe('allow')
    expect(routeAccess('reports', ordinarySession)).toBe('forbidden')
    expect(routeAccess('inventory', ordinarySession)).toBe('forbidden')
  })

  it('redirects an authenticated user away from login', () => {
    expect(routeAccess('login', ownerSession)).toBe('orders')
  })
})
