// @vitest-environment jsdom
import { beforeEach, expect, test } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { http } from '../api'
import { businessGeneration, clearBusinessSession } from '../business/state'
import { useBusinessStore } from './business'
beforeEach(() => { clearBusinessSession(); setActivePinia(createPinia()) })
test.each(['resolve', 'reject'])('old bootstrap %s cannot refill data or finalize a newer load', async outcome => {
  const finishes: Array<() => void> = []
  http.defaults.adapter = config => new Promise((resolve, reject) => {
    const index = finishes.length
    finishes.push(() => outcome === 'reject' && index === 0 ? reject(new Error('old network failure')) : resolve({ config, headers: {}, status: 200, statusText: '', data: { data: { employee: { id: 'e1' }, catalog: [{ id: index ? 'new' : 'old' }], wristbands: [] } } }))
  })
  const store = useBusinessStore()
  const old = store.refreshBootstrap().catch(() => undefined)
  await Promise.resolve(); await Promise.resolve()
  clearBusinessSession()
  const generation = businessGeneration.capture()
  const current = store.refreshBootstrap()
  await Promise.resolve(); await Promise.resolve()
  finishes[0]!(); await old
  expect(businessGeneration.isCurrent(generation)).toBe(true)
  expect(store.loading).toBe(true)
  expect(store.error).toBe('')
  expect(store.catalog).toEqual([])
  finishes[1]!(); await current
  expect(store.catalog[0]?.id).toBe('new')
  expect(store.loading).toBe(false)
})
test('out-of-order bootstrap queries keep the latest catalog', async () => {
  const finishes: Array<() => void> = []
  http.defaults.adapter = config => new Promise(resolve => {
    const id = finishes.length ? 'new' : 'old'
    finishes.push(() => resolve({ config, headers: {}, status: 200, statusText: '', data: { data: { employee: { id: 'e1' }, catalog: [{ id }], wristbands: [] } } }))
  })
  const store = useBusinessStore()
  const old = store.refreshBootstrap(); await Promise.resolve(); await Promise.resolve()
  const latest = store.refreshBootstrap(); await Promise.resolve(); await Promise.resolve()
  finishes[1]!(); await latest
  finishes[0]!(); await old
  expect(store.catalog[0]?.id).toBe('new')
})
test('a newer silent bootstrap completes the loading indicator it supersedes', async () => {
  const finishes: Array<() => void> = []
  http.defaults.adapter = config => new Promise(resolve => finishes.push(() => resolve({ config, headers: {}, status: 200, statusText: '', data: { data: { employee: { id: 'e1' }, catalog: [], wristbands: [] } } })))
  const store = useBusinessStore()
  const old = store.refreshBootstrap(); const latest = store.refreshBootstrap(true)
  finishes[1]!(); await latest
  expect(store.loading).toBe(false)
  finishes[0]!(); await old
  expect(store.loading).toBe(false)
})
