import { expect, test } from 'vitest'
import { canFilterBathAreas, isAllowedMobileRole } from './mobile-role'

test('allows administrators to use mobile ordering', () => {
  expect(isAllowedMobileRole('admin')).toBe(true)
})

test('lets administrators filter both bath areas', () => {
  expect(canFilterBathAreas('admin')).toBe(true)
})

test('keeps unsupported desktop roles out of mobile ordering', () => {
  expect(isAllowedMobileRole('cashier')).toBe(false)
  expect(isAllowedMobileRole('manager')).toBe(false)
})
